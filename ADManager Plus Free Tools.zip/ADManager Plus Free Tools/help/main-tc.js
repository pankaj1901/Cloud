$(document).ready(function () {
    var url = window.location.href;
    var str = url.substring(0, url.indexOf("help")); //No I18N
    var pat = str + "help/"; //No I18N
    "use strict"; //No I18N
    $("#vMenu").html('<li class="book" data-id="a0"><a href="' + pat + 'techcrafters/techcraftersindex.html">Free Tools from ADManager Plus</a></li><li class="book" data-id="a1"><a href="' + pat + 'techcrafters/contact-us.html">Contact Us</a></li><li class="book" data-id="a2"><a href="' + pat + 'techcrafters/system-requirements.html">System Requirements</a></li><li class="book" data-id="a3"><a href="' + pat + 'techcrafters/how-to-start-the-tool.html">How to Start the Tool</a></li><li class="book" data-id="a4"><a href="' + pat + 'techcrafters/ad-query-tool.html">Active Directory Query Tool</a></li><li class="book" data-id="a5"><a href="' + pat + 'techcrafters/active-directory-csv-generator.html">CSV Generator Tool</a></li><li class="book" data-id="a9"><a href="' + pat + 'techcrafters/lastlogon-tool.html">Last Logon Finder Tool</a></li><li class="book" data-id="a10"><a href="' + pat + 'techcrafters/Password_Policy_Manager.html">Password Policy Manager</a></li><li class="book" data-id="a11"><a href="' + pat + 'techcrafters/empty-password-report.html">Empty Passwords Reports</a></li><li class="book" data-id="a12"><a href="' + pat + 'techcrafters/dc-monitoring-tool.html">Active Directory DC Monitoring Tool</a></li><li class="book" data-id="a13"><a href="' + pat + 'techcrafters/DMZAnalyzer.html">DMZ Port Analyzer Plus</a></li><li class="book" data-id="a6"><a href="' + pat + 'techcrafters/DnsReporter-tc.html">DNS Reporter Tool</a></li><li class="book" data-id="a14"><a href="' + pat + 'techcrafters/weak-password-users-report.html">Weak Passwords Reports</a></li><li class="book" data-id="a15"><a href="' + pat + 'techcrafters/manage-local-users-tc.html">Local Users Management Tool</a></li><li class="book" data-id="a7"><a href="' + pat + 'techcrafters/manage-view-ad-lds-users-groups.html">ADLDS Object Management</a></li><li class="book" data-id="a16"><a href="' + pat + 'techcrafters/Terminal-Session-Manager.html">Terminal Session Manager</a></li><li class="book" data-id="a17"><a href="' + pat + 'techcrafters/sharepoint-management-tool-tc.html">SharePoint Management Tool</a></li><li class="book" data-id="a18"><a href="' + pat + 'techcrafters/get-dcs.html">Get Domain and Domain Controllers</a></li><li class="book" data-id="a19"><a href="' + pat + 'techcrafters/get-duplicates.html">Get Duplicates</a></li><li class="book" data-id="a20"><a href="' + pat + 'techcrafters/replicationmanager-tc.html">Replication Manager Tool</a></li><li class="book" data-id="a8"><a href="' + pat + 'techcrafters/ServiceAccountManagement-tc.html">Service Account Management Tool</a></li><li class="book" data-id="a21"><a href="' + pat + 'techcrafters/pst-migration-tool.html">PST Migration Tool</a></li>');
    $("body").on('click', ".vertical-menu li.arrow a", function (event) {

        $(this).parent("li").toggleClass("in");
        localStorage.setItem("dataid", $(this).parent("li").attr("data-id")); //No I18N
    });

    $("body").on('click', ".vertical-menu li.book > a", function (event) {
        localStorage.setItem("dataid", $(this).parent("li").attr("data-id")); //No I18N
        event.stopImmediatePropagation();
    });


    if (localStorage.getItem("dataid") === null || localStorage.getItem("dataid") == "undefined") {
        //sidebar menu function
        var k = window.location.pathname;
        var n = k.lastIndexOf("/") + 1;
        var m = k.slice(n);
        var v = $(".vertical-menu li a");
        var anchr;
        $.each(v, function (index, item) {
                var temp = $(item).attr('href');
                if (temp.indexOf(m) != -1) {
                    anchr = item;
                    $(anchr).parents("li.arrow").addClass('in');
                }
            })
            //sidebar ends
    } else {
        var dataid = localStorage.getItem("dataid"); //No I18N
        $("li[data-id='" + dataid + "']").addClass('in');
        $("li[data-id='" + dataid + "']").parents("li.arrow").addClass('in');
    }


    //Clearing dataid in localstorage for sidemenu
    localStorage.setItem("dataid", ""); //No I18N

    var sn = $("a[href='" + url + "']").parent().prev("li").attr("data-id"); //no i18n
    var ns = $("li[data-id='" + sn + "'] a").attr("href");
    $(".navigation ul li:nth-child(2) a").attr("href", ns); //No i18n
    //alert($(ns).attr("href"));
});