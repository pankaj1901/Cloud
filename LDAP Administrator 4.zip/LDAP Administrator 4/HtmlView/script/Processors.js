/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

//
// Processors Manager 
//

Softerra.Class.ProcessorsMgr = (function () {

    // private:
    var _Processors = new ProcessorsImpl();

    function Initialization() {
        // reduction to the lower case
        var tmpObj = {};
        for (var elem in JSAttrTypeProcessors) {
            tmpObj[elem.toLowerCase()] = JSAttrTypeProcessors[elem];
        }
        JSAttrTypeProcessors = tmpObj;

        tmpObj = {};
        for (var elem in JSAttrProcessors) {
            tmpObj[elem.toLowerCase()] = JSAttrProcessors[elem];
        }
        JSAttrProcessors = tmpObj;

        tmpObj = null;
    }

    //
    // Processor bindings
    //
    var JSAttrTypeProcessors = {
        //String
        "{5B22BFDE-C42C-4139-8AFC-481ACDA03CCB}": _Processors.StringBaseProcessor,
        //OctetString
        "{22DE47D4-F7A5-4ef4-ABC4-4FBC499DF8C4}": undefined,
        //Boolean
        "{A66E2B19-BECB-42EF-B2DC-A189C4BEDA30}": _Processors.BooleanProcessor,
        //Integer
        "{A0F0AF29-A7F8-4C94-86C7-C936BAEDE1F2}": undefined,
        //UtcTime
        "{EB13DB86-AEAD-4B9B-9306-2C6DB10C86BD}": undefined,
        //LargeInteger
        "{39317608-79D9-4F29-A04F-C5A78797F71C}": undefined,
        //NtSecurityDescriptor
        "{7126FC2E-2393-4C06-9315-133BE3E3C674}": undefined,
        //UserOrGroupThatCanJoinComputerToDomain
        "{60161EE4-FB8A-4312-9DBC-641E7BA7BA25}": undefined,
        //DistinguishedName
        "{4977C925-B620-4A56-A105-78D1C46AC007}": _Processors.DNProcessor,
        //DistinguishedNameWithBinary
        "{11845F44-EA9C-4DAF-AC97-A90CD1301A2D}": undefined,
        //DistinguishedNameWithString
        "{D4A1304E-97BF-43CE-8B01-E013F73F1050}": undefined,
        //Member
        "{F3D442C7-C3A4-421C-826F-8366BF1793C3}": _Processors.MemberProcessor,
        //MemberOf
        "{0B908C35-50BA-4281-BA5D-2A0D55917F45}": _Processors.MemberOfProcessor,
        //UserPassword
        "{E7F1A482-A04C-4715-9840-BCEE11FA1BAE}": undefined,
        //UnicodePwd
        "{79B27E9D-0E82-4ae0-B6A6-A07F9BAF68B0}": undefined,
        //Email
        "{5E3DD645-CF20-42A6-ABEE-81486F7A4B64}": _Processors.MailProcessor,
        //URI
        "{EA6F6B02-94B7-486A-9DC7-C190BC045EA7}": _Processors.WebPageProcessor,
        //URL
        "{C4B0A315-A0FE-4E09-A80B-4E6EE876D0E5}": _Processors.WebPageProcessor,
        //AdsPath
        "{AB472C85-52FE-407F-98F9-2650FC157BBE}": undefined,
        //GeneralizedTime
        "{B8BDA085-BD28-4BF2-AD90-3F5AC49018FD}": undefined,
        //Timestamp
        "{4057D7F6-F5DC-471e-A82B-561C2D21CE78}": undefined,
        //JpegPhoto
        "{6153E80B-06D1-4D46-87DD-0B1D24CDE7B2}": _Processors.PhotoProcessor,
        //Audio
        "{215E1130-FD00-42BB-9852-ED0D8A678AA4}": undefined,
        //SslCertificate
        "{7D5D4309-932A-48B1-B762-0804F8BA8697}": _Processors.CertificateProcessor,
        //SecurityIdentifier
        "{9E07108E-055A-4366-9AC5-7601B5B35231}": undefined,
        //Guid
        "{76D22F68-0DBD-40FE-B4EE-3572D7CF42A6}": _Processors.StringBaseProcessor,
        //Crl
        "{4A4E4C48-D73C-415B-A2CB-E77062750654}": undefined,
        //GroupType
        "{A4571B10-1F4C-491A-B58F-DD8D6338D6B3}": undefined,
        //SearchFlags
        "{212D9086-7406-4B73-8420-CFDAB5E51FA7}": undefined,
        //InstanceType
        "{E77D21FC-BE94-4A90-82CB-5EE1341B706B}": undefined,
        //SystemFlags
        "{B1691DF6-FAFD-46AB-B136-A2B17A687855}": undefined,
        //UserAccountControl
        "{DCF07D79-836B-4EEB-90F1-296497CF720E}": _Processors.UserAccountControlProcessor,
        //SamAccountType
        "{869B44A7-FC16-45C2-A812-F4E1BB239362}": undefined,
        //ObjectClassCategory
        "{72294D6E-3D19-454B-A85B-61B3ACDAC988}": undefined,
        //Interval
        "{DF35AF04-7CCB-483e-94D8-DBD3248F377F}": undefined,
        //PwdProperties
        "{E88C0276-DD1D-4672-BD5E-165A2C020204}": undefined,
        //ServerState
        "{AF11ADE0-35A3-40cd-B91B-5FD02110B717}": undefined,
        //NameAndOptionalUID
        "{B120E081-41A3-4df8-A5F5-26E544D714CE}": undefined,
        //SchemaFlagsEx
        "{7D40A971-C899-4de4-B9BA-645C527DD116}": undefined,
        //PrimaryGroupId
        "{F96DE364-89EB-471d-8839-63E3B93CDE16}": undefined,
        //UserParameters
        "{2AD3BF1B-CAD4-4e41-9155-95FA6703EBAC}": undefined,
        //LogonHours
        "{5557ED3C-2A97-4370-8AC5-5B18F1F9DFC5}": _Processors.LogonHoursProcessor,
        //AciItem
        "{035DCFDA-0749-4c5a-ADCF-A63065513062}": undefined,
        //MachineRole
        "{BEBEE229-C233-4aef-985F-0DDF3B344807}": undefined,
        //LdapControl
        "{9CB606DE-0856-4479-87C0-85A08863A508}": undefined,
        //OID
        "{2BB404F6-7A87-4bc1-ADD5-2F836835ADF7}": _Processors.OIDProcessor,
        //CompactTime
        "{2A865BB0-4328-4802-9C2D-7EDD12517569}": undefined
    };

    var JSAttrProcessors = {
        'c': _Processors.CountryProcessor
    }
    //-- end Processor bindings

    var _StringBaseProcessor;
    var _BinaryBaseProcessor;
    var _PhotoProcessor;
    var _MailProcessor;
    var _WebPageProcessor;
    var _MemberProcessor;
    var _MemberOfProcessor;
    var _BooleanProcessor;
    var _CountryProcessor;
    var _DNProcessor;
    var _OIDProcessor;
    var _UserAccountControlProcessor;
    var _CertificateProcessor;
    var _LogonHoursProcessor;

    function ProcessorsImpl() {
        return {
            StringBaseProcessor: _StringBaseProcessor || (_StringBaseProcessor = new StringBaseProcessorImpl()),
            BinaryBaseProcessor: _BinaryBaseProcessor || (_BinaryBaseProcessor = new BinaryBaseProcessorImpl()),
            PhotoProcessor: _PhotoProcessor || (_PhotoProcessor = new PhotoProcessorImpl()),
            MailProcessor: _MailProcessor || (_MailProcessor = new MailProcessorImpl()),
            WebPageProcessor: _WebPageProcessor || (_WebPageProcessor = new WebPageProcessorImpl()),
            MemberProcessor: _MemberProcessor || (_MemberProcessor = new MemberProcessorImpl()),
            MemberOfProcessor: _MemberOfProcessor || (_MemberOfProcessor = new MemberOfProcessorImpl()),
            CountryProcessor: _CountryProcessor || (_CountryProcessor = new CountryProcessorImpl()),
            BooleanProcessor: _BooleanProcessor || (_BooleanProcessor = new BooleanProcessorImpl()),
            DNProcessor: _DNProcessor || (_DNProcessor = new DNProcessorImpl()),
            OIDProcessor: _OIDProcessor || (_OIDProcessor = new OIDProcessorImpl()),
            UserAccountControlProcessor: _UserAccountControlProcessor || (_UserAccountControlProcessor = new UserAccountControlProcessorImpl()),
            CertificateProcessor: _CertificateProcessor || (_CertificateProcessor = new CertificateProcessorImpl()),
            LogonHoursProcessor: _LogonHoursProcessor || (_LogonHoursProcessor = new LogonHoursProcessorImpl())
        }
    }

    function GetProcessorImpl(attrObj) {
        // try to find by attribute type
        if (typeof attrObj.uType != 'undefined' && attrObj.uType) {
            var proc = JSAttrProcessors[attrObj.uType.toLowerCase()];
        }
        // try to find by host's value processor GUID
        if (!proc && typeof attrObj.uValProcID != 'undefined' && attrObj.uValProcID) {
            proc = JSAttrTypeProcessors[attrObj.uValProcID.toLowerCase()];
        }

        if (proc) { return proc; }

        // if not found then get binary processor for binary attributes and string one otherwise
        if (typeof attrObj.uAttrInfoFlags != 'undefined' && attrObj.uAttrInfoFlags) {
            if (Softerra.Class.AttrInfoMgr.IsBinary(attrObj.uAttrInfoFlags)) {
                JSAttrProcessors[attrObj.uType.toLowerCase()] = _Processors.BinaryBaseProcessor;
                return _Processors.BinaryBaseProcessor;
            }
            else {
                JSAttrProcessors[attrObj.uType.toLowerCase()] = _Processors.StringBaseProcessor;
                return _Processors.StringBaseProcessor;
            }
        }
        else {
            return null;
        }
    }

    Initialization();

    //public:
    return {
        GetProcessor: GetProcessorImpl
    };
})();

//
// AttInfoManager
//
Softerra.Class.AttrInfoMgr = (function () {
    //private:
    var ATTR_READONLY = 0x1;
    var ATTR_SINGLEVAL = 0x2;
    var ATTR_OPTIONAL = 0x4;
    var ATTR_BINARY = 0x8;

    return {
        //public:
        IsReadonly: function (flags) {
            return 0 != (parseInt(flags) & ATTR_READONLY);
        },
        IsSingleValue: function (flags) {
            return 0 != (parseInt(flags) & ATTR_SINGLEVAL);
        },
        IsOptional: function (flags) {
            return 0 != (parseInt(flags) & ATTR_OPTIONAL);
        },
        IsBinary: function (flags) {
            return 0 != (parseInt(flags) & ATTR_BINARY);
        },
        SingleValueFlag: function () {
            return ATTR_SINGLEVAL;
        },
        ReadonlyFlag: function () {
            return ATTR_READONLY;
        }
    };
})();

//
// ValueProcessor's features manager
//
Softerra.Class.ValProcFeaturesMgr = (function () {
    //private:
    var HAS_CUSTOM_EDITOR = 0x2;
    var HAS_DEFAULT_ACTION = 0x8;

    return {
        //public:
        HasCustomEditor: function (flags) {
            return (parseInt(flags) & HAS_CUSTOM_EDITOR);
        },
        HasDefaultAction: function (flags) {
            return (parseInt(flags) & HAS_DEFAULT_ACTION);
        }
    };
})();

////////////////////////////
// Processor implementations
////////////////////////////

//
// Base processor (abstract)
//

function BaseProcessorImpl() {
    this.Name = "BaseProcessor";
    //
    //base methods
    //

    // creates TD element with representation of the value for the edit mode
    this.GenEditElem = function (elem, i, newVal) {
        var currAttr = elem.attrinfo('jsonObject');

        var resultContent = new StringBuilder();

        resultContent.append('<td class="val">');

        // if i == -1, then default value inserted
        resultContent.append('<div class="inputWrapDiv">');

        // generate input element

        var inputElemId = NextId();

        var elementDisabled = false;
        if (currAttr.hasCustomEditor && !this.PreventCustomEditor()) {
            elementDisabled = true;
        }

        var classInputControlKeys ='inputControlKeys';
        var inputElemClasses = 'editVal';
        if (!elementDisabled) {
            inputElemClasses += ' ' + classInputControlKeys;
        }
        resultContent.append('<input id="' + inputElemId + '" type="text" tabIndex="0" class="' + inputElemClasses + '"');

        if (elementDisabled) {
            resultContent.append(' readonly="true"');
        }

        // add value to input element
        if (i != -1) {
            if (currAttr.hasCustomEditor) {
                var valForInsert = this.GetViewValue(currAttr, i);
            }
            else {
                var valForInsert = this.GetEditValue(currAttr, i);
            }
        }
        else {
            var valForInsert = newVal ? newVal : this.GetDefVal();
        }
        resultContent.append(' value="' + Softerra.Class.StringMgr.EscapeForAttrValue(valForInsert) + '"');
        resultContent.append(' />');
        // --generate input element

        // keyup handler

        if (!elementDisabled) {
            elem.attrinfo('option', 'EditModeEventHandler').addHandler(classInputControlKeys, 'keyup', { func: function (e) {
                attrinfoEventHandler('onKeyUp', e);
            }
            });
        }

        // binding cue mechanism
        if (currAttr.showcue) {
            AttachCue({ elementId: inputElemId, cueText: currAttr.uFriendName || currAttr.uType });
        }

        resultContent.append('</div>');
        resultContent.append('</td>');

        return resultContent.toString();
    }

    this.BeforeSwitchingModes = function (requiredMode) {
    }

    this.AfterSwitchingModes = function (requiredMode) {
    }

    this.AddValueAfterLastDeleted = function () {
        return true;
    }

    this.GetSaveCancelControlsExtraClass = function () {
        return null;
    }

    this.GetValForCustEditor = function (attrObj, targ, valIndex) {
        var currTRId = $($(targ).parents("tr.val")).first().attr('id');
        var outVal = DataStoreManager.Data(currTRId, 'preSaveData');
        if (outVal) {
            return this.GetCustomEditorEditValue(outVal);
        }
        if (valIndex == -1) { return; }
        return this.GetEditValue(attrObj, valIndex);
    }

    this.SetValByIndex = function (attrObj, targ, valIndex, newVal) {
        var newUseVal = this.GetCustomEditorViewValue(newVal);
        var currTR = $(targ).parents("tr.val").first();
        if (!currTR) { return; }

        // trigger keyup for managing delete button visibility
        currTR.find('input[type=text]').val(newUseVal).triggerHandler('keyup');

        var currTRId = currTR.attr('id');
        currTR.removeAttr('valueIndex');
        DataStoreManager.Data(currTRId, 'preSaveData', newVal);
    },

    this.PreventCustomEditor = function () {
        return false;
    }

    this.HasSimpleInputEditor = function () {
        return false;
    }

    this._getModifValuesImpl = function (attrObj, oldVals, newVals, outObj) {
        if (attrObj.firstonly) { // add new value or replace only first value
            if (newVals.length) {
                if (oldVals.length) {
                    if (oldVals[0] != newVals[0]) {
                        outObj.uValues.push(newVals[0]);
                    }
                    else {
                        return;
                    }
                }
                else {
                    outObj.uValues.push(newVals[0]);
                }
            }
            if (oldVals.length >= 2) {
                for (var i = 1; i < oldVals.length; ++i) {
                    outObj.uValues.push(oldVals[i]);
                }
            }
            return outObj.uValues.length || oldVals.length ? outObj : undefined;
        }
        else {
            if (!Softerra.Func.CompareArraysNoOrder(oldVals, newVals)) {
                outObj.uValues = newVals;
                return outObj.uValues.length || oldVals.length ? outObj : undefined;
            }
        }
    }
}

//
// StringBase processor
//

function StringBaseProcessorImpl() {
    BaseProcessorImpl.call(this);
    this.Name = "StringBaseProcessor";

    //
    // overload methods
    //
    this.GetDefVal = function () {
        return "";
    }

    this.GetEncodingFlag = function () {
        return Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NONE | Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NEEDDISPVALUE;
    }

    this.GetModifiedValues = function (attrObj, valsTable) {
        if (attrObj.readonly) { return; }

        var currThis = this;
        var outObj = { uValues: [], uEncFlags: this.GetEncodingFlag() };

        var elemsObj = valsTable.find('tr.val');
        var oldVals = attrObj.uDispEditVals || [];
        var newVals = [];

        var self = this;

        // gather new values
        elemsObj.each(function (index) {
            var editVal;
            if (attrObj.hasCustomEditor && !self.PreventCustomEditor()) {
                // getting old value or new stored in DataStoreManager
                var attrVals = DataStoreManager.Data($(this).attr('id'), 'preSaveData');
                if (attrVals) {
                    editVal = currThis.GetCustomEditorEditValue(attrVals);
                }
                else {
                    editVal = oldVals[index];
                }
            }
            else {
                var inputElem = $(this).find('input.editVal');
                if (inputElem.hasClass('cueMode')) {
                    editVal = '';
                }
                else {
                    editVal = $(this).find('input.editVal').val();
                }
            }
            if (editVal == '') { return; }
            newVals.push(editVal);
        });

        return this._getModifValuesImpl(attrObj, oldVals, newVals, outObj);
    }

    this.GenViewElem = function (elem, i, newVal) {
        var currAttr = elem.attrinfo('jsonObject');

        var val;
        if (i != -1) {
            val = Softerra.Class.StringMgr.EscapeForHtml(this.GetViewValue(currAttr, i));
        }
        else {
            val = Softerra.Class.StringMgr.EscapeForHtml(newVal ? newVal : this.GetDefVal());
        }
        return val;
    }

    this.GetCustomEditorViewValue = function (custEditorObj) {
        if (custEditorObj) {
            return Softerra.Class.StringMgr.EscapeForHtml(custEditorObj.uDispViewVal);
        }
    }
    this.GetCustomEditorEditValue = function (custEditorObj) {
        if (custEditorObj) {
            return custEditorObj.uDispEditVal;
        }
    }
    this.GetViewValue = function (attrObj, i) {
        if (attrObj.uDispViewVals && i <= (attrObj.uDispViewVals.length - 1)) {
            return attrObj.uDispViewVals[i];
        }
    }
    this.GetEditValue = function (attrObj, i) {
        if (attrObj && attrObj.uDispEditVals && i <= (attrObj.uDispEditVals.length - 1)) {
            return attrObj.uDispEditVals[i];
        }
    }

    this.HasSimpleInputEditor = function () {
        return true;
    }
}

//
// BinaryBase processor
//

function BinaryBaseProcessorImpl() {
    BaseProcessorImpl.call(this);
    this.Name = "BinaryBaseProcessor";
        
    //
    // overload methods
    //
    this.GetDefVal = function () {
        return "";
    }

    this.GetEncodingFlag = function () {
        return Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_URI | 
            Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NEEDDISPVALUE;
    }

    this.GetCustomEditorViewValue = function (val) {
        if (val && val.uDispViewVal) { return val.uDispViewVal; }
    }

    this.GetCustomEditorEditValue = function (val) {
        if (val && val.uLinkValue) { return val.uLinkValue; }
    }

    this.GetModifiedValues = function (attrObj, valsTable) {
        var currThis = this;
        var outObj = { uValues: [], uEncFlags: this.GetEncodingFlag() };

        if (!attrObj.hasCustomEditor) { return; }

        var oldVals = attrObj.uLinkValues || [];
        var newVals = [];

        valsTable.find('tr.val').each(function (index) {
            var currIndex = parseInt($(this).attr('valueIndex'));
            if (currIndex != undefined && !isNaN(currIndex) && currIndex != -1) {
                newVals.push(attrObj.uLinkValues[currIndex]);
            }
            else {
                var editVal;
                var attrVals = DataStoreManager.Data($(this).attr('id'), 'preSaveData');
                if (attrVals) {
                    editVal = currThis.GetCustomEditorEditValue(attrVals);
                    if (editVal) { newVals.push(editVal); }
                }
            }
        });

        return this._getModifValuesImpl(attrObj, oldVals, newVals, outObj);
    }

    this.GetViewValue = function (attrObj, i) {
        if (i <= (attrObj.uDispViewVals.length - 1)) {
            return attrObj.uDispViewVals[i];
        }
    }

    this.GetEditValue = function (attrObj, i) {
        if (i <= (attrObj.uLinkValues.length - 1)) {
            return attrObj.uLinkValues[i];
        }
    }

    this.GenViewElem = function (elem, i, newVal) {
        var currAttr = elem.attrinfo('jsonObject');
        var val;
        if (i != -1) {
            val = Softerra.Class.StringMgr.EscapeForHtml(this.GetViewValue(currAttr, i));
        }
        else {
            val = Softerra.Class.StringMgr.EscapeForHtml(newVal ? newVal : this.GetDefVal());
        }

        return val;
    }

    this.HasSimpleInputEditor = function () {
        return false;
    }
}

//
// Photo processor
//

function PhotoProcessorImpl() {
    BinaryBaseProcessorImpl.call(this);
    this.Name = "PhotoProcessor";

    //
    // overload methods
    //
    this.GetValForCustEditor = function (attrObj, targ, valIndex) {
        var currTD = $($(targ).parents("tr.val")[0]).find("td.val");
        var currIMG = currTD.find(".imgVal");
        Softerra.Func.Check(currIMG);

        return decodeURI(currIMG.attr("src"));
    },
    this.GetCustomEditorViewValue = function (val) {
        if (val && val.uLinkValue) { return val.uLinkValue; }
    }
    this.SetValByIndex = function (attrObj, targ, valIndex, newVal) {
        var newUseVal = this.GetCustomEditorViewValue(newVal);
        var currTR = $($(targ).parents("tr.val")[0]);
        currTR.removeAttr('valueIndex');
        var currTD = currTR.find("td.val");
        if (currTD) {
            var currIMG = currTD.find(".imgVal");
            currIMG.attr("src", newUseVal);
            currIMG.removeAttr('width');
            currIMG.removeAttr('height');
            DataStoreManager.Data(currTR.attr('id'), 'preSaveData', newVal);
            if ($.fn.photo) {
                currIMG.photo('reinit');
            }
        }
    },
    this.GenEditElem = function (elem, i, newVal) {
        var resultContent = new StringBuilder();
        resultContent.append('<td class="val">');
        resultContent.append(PhotoGenElem.call(this, elem, i, 'EditMode', newVal));
        resultContent.append('</td>');

        return resultContent.toString();
    }
    this.GenViewElem = function (elem, i) {
        return PhotoGenElem.call(this, elem, i, 'ViewMode');
    }

    function PhotoGenElem(elem, i, reqMode, newVal) {
        var currAttr = elem.attrinfo('jsonObject');

        var imgId = NextId();
        if ($.fn.photo) {
            var operGroup = PostponedOperationsManager.OperationGroups.attrinfoProcessing;
            addParams = { useDefaultPhoto: false, maxWidth: 500, maxHeight: 200 };
            PostponedOperationsManager.AddOperation(operGroup, true, function (params) {
                $('#' + params[0]).photo(params[1]);
            }, imgId, addParams);
        }

        var commonHandler = elem.attrinfo('option', reqMode == 'ViewMode' ? 'ViewModeEventHandler' : 'EditModeEventHandler');
        commonHandler.addHandler('imgVal', 'dblclick', { func: function (e) {
            if (!$(e.target).attr('src')) { return; }
            var valIndex = parseInt($(e.target).attr('valueIndex'));
            if (valIndex < 0) { return; }
            attrinfoEventHandler('defaultAction', e, valIndex);
            return false;
        }});
        
        return '<img id="' + imgId + '" class="imgVal" valueIndex="' + i + '" src="' + (i != -1 ? currAttr.uLinkValues[i] : (newVal || this.GetDefVal())) + '" />';
    }
}

//
// Mail processor
//
function MailProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "MailProcessor";

    this.GenViewElem = function (elem, i) {
        var currAttr = elem.attrinfo('jsonObject');
        var strResult = new StringBuilder();

        var classA = 'mailProcessorViewValue';
        strResult.append('<a class="' + classA + '" valueIndex="' + i + '" tabIndex="0" href="#">');
        strResult.append(Softerra.Class.StringMgr.EscapeForHtml(currAttr.uDispViewVals[i]));
        strResult.append('</a>');

        elem.attrinfo('option', 'ViewModeEventHandler').addHandler(classA, 'click', { func: function (e) {
            attrinfoEventHandler('defaultAction', e, parseInt($(e.target).attr('valueIndex')));
            return false;
        }});

        return strResult.toString();
    }   
}

//
// Web page processor
//

function WebPageProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "WebPageProcessor";

    this.GenViewElem = function (elem, i) {
        var currAttr = elem.attrinfo('jsonObject');
        var val = Softerra.Class.StringMgr.EscapeForHtml(currAttr.uDispViewVals[i] || '');
        var link = val;
        if (
            link.substring(0, 'http://'.length) != 'http://' &&
            link.substring(0, 'https://'.length) != 'https://'
            ) {
            link = 'http://' + link;
        }
        var elemId = NextId();
        var classA = currAttr.uType + '_webPageProcessorViewValue';

        elem.attrinfo('option', 'ViewModeEventHandler').addHandler(classA, 'click', { func: function (e) {
            attrinfoEventHandler('defaultAction', e, parseInt($(e.target).attr('valueIndex')));
            return false;
        }});

        return '<a class="' + classA + '" href="#" valueIndex="' + i + '" tabIndex="0" target="_blank">' + val + '</a>';
    }
}

//
// Member processor
//

function MemberProcessorImpl() {
    DNProcessorImpl.call(this);
    this.Name = "MemberProcessor";

    this.PreventCustomEditor = function () {
        return true;
    }
}

//
// MemberOf processor
//

function MemberOfProcessorImpl() {
    DNProcessorImpl.call(this);
    this.Name = "MemberOfProcessor";

    this.PreventCustomEditor = function () {
        return true;
    }
}

//
// Country processor
//

function CountryProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "CountryProcessor";

    this.GenViewElem = function (elem, i) {
        var currAttr = elem.attrinfo('jsonObject');
        var strResult = '';
        for (var j in Softerra.Const.Countries) {
            if (j.toLowerCase() == currAttr.uDispEditVals[i].toLowerCase()) {
                strResult = Softerra.Const.Countries[j];
                break;
            }
        }
        if (!strResult) {
            strResult = currAttr.uDispViewVals[i];
        }

        return Softerra.Class.StringMgr.EscapeForHtml(strResult);
    }
}

function DNProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "DNProcessor";

    this.GenViewElem = function (elem, i) {
        var currAttr = elem.attrinfo('jsonObject');
        var className = 'dnProcessorViewValue';
        var str = new StringBuilder();
        str.append('<a tabIndex="0" class="' + className + '" valueIndex="' + i + '" href="#">');
        str.append(Softerra.Class.StringMgr.EscapeForHtml(currAttr.uDispViewVals[i]));
        str.append('</a>');

        elem.attrinfo('option', 'ViewModeEventHandler').addHandler(className, 'click', { func: function (e) {
            attrinfoEventHandler('defaultAction', e, parseInt($(e.target).attr('valueIndex')));
            return false;
        }});

        return str.toString();
    }
}

//
// OID processor
//

function OIDProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "OIDProcessor";

    this.GenViewElem = function (elem, i) {
        var currAttr = elem.attrinfo('jsonObject');

        var className = 'oidProcessorViewValue';
        var str = new StringBuilder();
        str.append('<a class="' + className + '" valueIndex="' + i + '" tabIndex="0" href="#">');
        str.append(Softerra.Class.StringMgr.EscapeForHtml(currAttr.uDispViewVals[i]));
        str.append('</a>');
        elem.attrinfo('option', 'ViewModeEventHandler').addHandler(className, 'click', { func: function (e) {
            attrinfoEventHandler('defaultAction', e, parseInt($(e.target).attr('valueIndex')));
            return false;
        }});
        return str.toString();
    }
}

//
// Boolean processor
//

function BooleanProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "BooleanProcessor";

    this.GenEditElem = function (elem, i, newVal) {
        var currAttr = elem.attrinfo('jsonObject');

        var resultContent = new StringBuilder();

        resultContent.append('<td class="val">');

        if (i == -1) {
            var currVal = this.GetDefVal();
        }
        else {
            var currVal = Softerra.Func.GetBool(currAttr.uDispEditVals[i].toLowerCase());
        }

        resultContent.append('<form class="boolVal">');

        // trick function for uncheck problem fix in IE6
        var uncheckFunc = function () {
            $(this).parent().parent().find('input[type=radio]').removeAttr('checked');
            $(this).attr('checked', 'checked');
            customRadioSync($(this).parent().parent().find('input[type=radio]'));
        }

        // TRUE element
        var inputTrueId = NextId();
        var inputTrue = new TagBuilder('input', false);
        inputTrue.addAttr('id', inputTrueId);
        inputTrue.addAttr('type', 'radio');
        inputTrue.addAttr('name', 'boolInput');
        inputTrue.addAttr('value', 'TRUE');
        inputTrue.addAttr('tabIndex', '0');

        if (currVal) {
            inputTrue.addAttr('checked', 'checked');
        }
        
        resultContent.append('<span class="themedRadio');
        if (currVal) {
           resultContent.append(' selected');
        }
        resultContent.append('">');
        resultContent.append(inputTrue.toString());
        resultContent.append('</span>');

        PostponedBindsManager.AddBind(
            { elemId: inputTrueId, eventType: 'keyup', func: function (e) {
                elem.attrinfo('onKeyUp', e);
            }, context: elem });
        PostponedBindsManager.AddBind(
            { elemId: inputTrueId, eventType: 'click', func: uncheckFunc });

        var trueTextId = NextId();
        resultContent.append('<span id="' + trueTextId + '" class="clickableText">' + S_TRUE + '</span><br>');
        PostponedBindsManager.AddBind(
            { elemId: trueTextId, eventType: 'click', func: function () { $('#' + inputTrueId).click(); return false; }
            });


        // FALSE element
        var inputFalseId = NextId();

        var inputFalse = new TagBuilder('input', false);
        inputFalse.addAttr('id', inputFalseId);
        inputFalse.addAttr('type', 'radio');
        inputFalse.addAttr('name', 'boolInput');
        inputFalse.addAttr('value', 'FALSE');
        inputFalse.addAttr('tabIndex', '0');
        if (!currVal) {
            inputFalse.addAttr('checked', 'checked');
        }

        resultContent.append('<span class="themedRadio');
        if (!currVal) {
           resultContent.append(' selected');
        }
        resultContent.append('">');
        resultContent.append(inputFalse.toString());
        resultContent.append('</span>');

        PostponedBindsManager.AddBind(
            { elemId: inputFalseId, eventType: 'keyup', func: function (e) {
                elem.attrinfo('onKeyUp', e);
            }, context: elem });
        PostponedBindsManager.AddBind({ elemId: inputFalseId, eventType: 'click', func: uncheckFunc });

        var falseTextId = NextId();
        resultContent.append('<span id="' + falseTextId + '" class="clickableText">' + S_FALSE + '</span>');
        PostponedBindsManager.AddBind(
            { elemId: falseTextId, eventType: 'click', func: function () { $('#' + inputFalseId).click(); return false; }
            });

        resultContent.append('</form>');
        resultContent.append('</td>');

        return resultContent.toString();
    }

    this.GetModifiedValues = function (attrObj, valsTable) {
        if (attrObj.readonly) { return; }

        var currThis = this;
        var outObj = { uValues: [], uEncFlags: this.GetEncodingFlag() };

        var elemsObj = valsTable.find('td.val');

        var oldVals = attrObj.uDispEditVals || [];
        var newVals = [];

        // gather new values
        elemsObj.each(function (index) {
            var editVal;
            editVal = $(this).find('form input:checked').val();
            if (editVal == '') { return; }
            newVals.push(editVal);
        });

        return this._getModifValuesImpl(attrObj, oldVals, newVals, outObj);
    }
    
    this.GetDefVal = function () {
        return false;
    }

    this.HasSimpleInputEditor = function () {
        return false;
    }

    this.AddValueAfterLastDeleted = function () {
        return false;
    }
}

function IntegerProcessorImpl() {
    StringBaseProcessorImpl.call(this);
    this.Name = "IntegerProcessor";

    this.GetDefVal = function () {
        return 0;
    }
}

// abstract class
function FlagSetProcessorImpl() {
    IntegerProcessorImpl.call(this);
    this.Name = "FlagSetProcessor";

    var valueIndex = 0;
    var propertiesIndex = 1;
    var shortNameIndex = 2;
    var nameIndex = 3;
    var descriptionIndex = 4;

    this.PreventCustomEditor = function () {
        return true;
    }

    this.BeforeSwitchingModes = function (requiredMode, currentMode, currentContent) {
        if (typeof currentMode === 'undefined' || typeof requiredMode === 'undefined' ) {
            return;
        }

        this.contentScrollOffset = currentContent.find('div.flagSet').scrollTop();
    }

    this.AfterSwitchingModes = function (currentMode, currentContent) {
        if (typeof currentMode === 'undefined') {
            return;
        }

        currentContent.find('div.flagSet').scrollTop(this.contentScrollOffset);
    }

    this.GetModifiedValues = function (attrObj, valsTable) {
        if (attrObj.readonly) { return; }
        if (attrObj.uValsCount != 1) { return; }

        var currThis = this;
        var outObj = { uValues: [], uEncFlags: this.GetEncodingFlag() };

        var elemObj = $(valsTable.find('td.val')[0]);
        if (!elemObj.find('div.' + this._divClass).length) {
            return outObj;
        }

        var oldVal = attrObj.uDispEditVals[0];
        var newVal = 0;

        // get new value
        elemObj.find('div.' + this._divClass + ' input[type=checkbox]:checked').each(function () {
            newVal |= $(this).val();
        });

        if (oldVal != newVal) {
            outObj.uValues.push(newVal);
            return outObj;
        }
    }
    
    this.GenViewElem = function (elem, i, newViewVal, newEditVal) {
        return _GenFlagSet.call(this, elem, i, newEditVal, 'ViewMode');
    }

    this.GenEditElem = function (elem, i, newViewVal, newEditVal) {
        var resultContent = new StringBuilder();
        resultContent.append('<td class="val flagSetTD">');
        resultContent.append(_GenFlagSet.call(this, elem, i, newEditVal, 'EditMode'));
        resultContent.append('</td>');

        return resultContent.toString();
    }

    function _GenFlagSet(elem, i, newEditVal, mode) {
        var currAttr = elem.attrinfo('jsonObject');
        if (!(i == -1 || currAttr.uValsCount == 1)) { return; }
        
        var attrVal = (i == -1) ? newEditVal : parseInt(currAttr.uDispEditVals[0]);
        
        var resultContent = new StringBuilder();
        resultContent.append('<div class="' + 'flagSet ' + this._divClass + '">');
        resultContent.append('<form>');

        var classItem = 'flagSetItem';

        var flagSet = this.GetFlagSet();
        for (var i = 0; i < flagSet.length; ++i) {
            var title = S_FLAG + ': 0x' + flagSet[i][valueIndex].toString(16) + '\n';
            title += flagSet[i][descriptionIndex];

            resultContent.append('<div title="' + Softerra.Class.StringMgr.EscapeForAttrValue(title) + '">');

            var _itemChecked = (attrVal & flagSet[i][valueIndex]);

            resultContent.append('<span class="themedCheckbox');
            if (_itemChecked) {
                resultContent.append(' selected');
            }
            resultContent.append('">');
            resultContent.append('<input class="' + classItem + '" type="checkbox" tabIndex="0"');
            resultContent.append(' value="' + flagSet[i][valueIndex] + '"');
            if (_itemChecked) {
                resultContent.append(' checked="checked"');
            }
            resultContent.append('>');
            resultContent.append('</span>');
            resultContent.append(Softerra.Class.StringMgr.EscapeForHtml(flagSet[i][nameIndex]));

            var commonHandler = elem.attrinfo('option', mode == 'ViewMode' ? 'ViewModeEventHandler' : 'EditModeEventHandler');
            commonHandler.addHandler(classItem, 'click', { func: _ClickFlagSetItem });

            resultContent.append('</div>');
        }
        
        resultContent.append('</form>');
        resultContent.append('</div>');

        return resultContent.toString();
    }

    function _ClickFlagSetItem(event) {
        var elem = getElementByTarget(event.target);
        var jsonObject = elem.attrinfo('jsonObject');
        if (jsonObject.readonly || (uiManager.IsInlineModifyTurnedOn() && elem.attrinfo('option', 'switchedMode') != 'EditMode')) {
            event.preventDefault();
            return false; 
        }

        var targ = event.target;
        if (targ) {
            if (elem.attrinfo('option', 'switchedMode') == 'EditMode') {
                TimersHolder.addFunction(function () {
                    customCheckSync($(targ));
                });
                return;
            }
            else {
                // get current checkbox index
                var currDiv = $(targ).parent().parent();
                var form = $(currDiv).parent();
                Softerra.Func.Check(currDiv, form);

                var currIndex = form.children('div').index(currDiv);
                var bChecked = (currDiv.find('input:checked').length != 0);

                // turn edit mode
                elem.attrinfo('turnMode', 'EditMode', { clearViewModeContent: false });

                // find edit mode checkbox's form
                var editModeDiv = $($(targ).parents('div.ldapAttrInfoDiv').first().find('table.editValues form > div')[currIndex]);
                var editModeCbx = editModeDiv.find('input[type=checkbox]');
                if (editModeCbx) {
                    bChecked ? editModeCbx.attr('checked', 'checked') : editModeCbx.removeAttr('checked');
                    customCheckSync(editModeCbx);
                }
                elem.attrinfo('clearGeneratedMode', 'ViewMode');
            }
        }
        return false;
    }

    this.HasSimpleInputEditor = function () {
        return false;
    }
}

// abstract class
function EnumProcessorImpl() {
    FlagSetProcessorImpl.call(this);
    this.Name = "EnumProcessor";
}

//
// UserAccountControl processor
//

function UserAccountControlProcessorImpl() {
    FlagSetProcessorImpl.call(this);
    this.Name = "UserAccountControlProcessor";

    this._divClass = 'userAccCtrlFlagSet';

    this.GetFlagSet = function () {
        return Softerra.Const.UserAccountControlFlagSetSettings;
    }
}

//
// CertificateProcessor processor
//

function CertificateProcessorImpl() {
    BinaryBaseProcessorImpl.call(this);
    this.Name = "CertificateProcessor";

    this.GenViewElem = function (elem, i) {
        var currAttr = elem.attrinfo('jsonObject');
        var className = 'certificateProcessorViewValue';
        var str = new StringBuilder();
        str.append('<a class="' + className + '" valueIndex="' + i + '" tabIndex="0" href="#">');
        str.append(Softerra.Class.StringMgr.EscapeForHtml(currAttr.uDispViewVals[i]));
        str.append('</a>');

        elem.attrinfo('option', 'ViewModeEventHandler').addHandler(className, 'click', { func: function (e) {
            attrinfoEventHandler('defaultAction', e, parseInt($(e.target).attr('valueIndex')));
            return false;
        } 
        });

        return str.toString();
    }
}

//
// LogonHoursProcessor processor
//

function LogonHoursProcessorImpl() {
    BinaryBaseProcessorImpl.call(this);
    this.Name = "LogonHoursProcessor";

    this.HasSimpleInputEditor = function () {
        return false;
    }
    
    this.GetEncodingFlag = function () {
        return Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NONE | Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NEEDDISPVALUE;
    }

    this.PreventCustomEditor = function () {
        return true;
    }

    this.GetViewValue = function (attrObj, i) {
        return "";
    }

    this.GetDefVal = function () {
        var dayPermitted = '111111111111111111111111';
        var weekPermitted = [];
        for (var i = 0; i < WEEKDAYCOUNT; ++i) {
            weekPermitted.push(dayPermitted);
        }
        return weekPermitted.join('');
    }

    this.GetModifiedValues = function (attrObj, valsTable) {
        if (attrObj.readonly) { return; }

        var currThis = this;
        var outObj = { uValues: [], uEncFlags: this.GetEncodingFlag() };

        var oldVal = attrObj.uDispEditVals2 && attrObj.uDispEditVals2[0];
        var newVal = '';

        var editModeTable = valsTable.find('.logonHoursTable').first();

        if (oldVal && !editModeTable.get(0)) { return outObj; }
        if (!oldVal && !editModeTable.get(0)) { return; }

        for (var i = 0; i < WEEKDAYCOUNT; ++i) {
            var res = _getRowValues(editModeTable, i);
            for (var j = 0; j < res.length; ++j) {
                if (res[j] == 0) {
                    newVal += '0';
                }
                else {
                    newVal += '1';
                }
            }
        }

        if (oldVal == newVal) {
            return;
        }
        else {
            outObj.uValues.push(newVal);
            return outObj;
        }

        return;
    }

    this.AddValueAfterLastDeleted = function () {
        return false;
    }

    this.GetSaveCancelControlsExtraClass = function (elem) {
        if (elem && elem.attrinfo('option', 'generatedContent').EditMode.find('table.editValues .logonHoursTable').length) {
            return 'logonHoursSaveCancelControls';
        }
        else {
            return null;
        }
    }

    this.GetCustomEditorEditValue = function (val) {
        if (val && val.uDispEditVal) { return val.uDispEditVal; }
    }

    this.GenViewElem = function (elem, i) {
        return _GenLogonHours.call(this, elem, i, undefined, 'ViewMode');
    }

    this.GenEditElem = function (elem, i, newViewVal, newEditVal) {
        var resultContent = new StringBuilder();
        resultContent.append('<td class="val">');
        resultContent.append(_GenLogonHours.call(this, elem, i, newEditVal, 'EditMode'));
        resultContent.append('</td>');
        return resultContent.toString();
    }

    //////////////////////////////////////////////////////////////////////////
    // private functions and members

    var HOURSPERDAY = 24;
    var WEEKDAYCOUNT = 7;

    function _turnElementEditMode(elem) {
        if (elem.attrinfo('option', 'switchedMode') == 'ViewMode') {
            elem.attrinfo('turnMode', 'EditMode', { clearViewModeContent: false });
            PostponedBindsManager.PerformBinds();
        }
    }

    function _getRowValues(table, iRow) {
        var resultArr = [];

        var trsData = $(table.find('tr.logonHoursData')[iRow]);
        if (!trsData) { return; }

        var tdsData = trsData.find('.logonHours');
        if (!tdsData || tdsData.length != HOURSPERDAY) { return; }

        tdsData.each(function () {
            if ($(this).hasClass('allowedLogonHours')) {
                resultArr.push(1);
            }
            else if ($(this).hasClass('deniedLogonHours')) {
                resultArr.push(0);
            }
            else {
                return null;
            }
        });

        return resultArr;
    }

    function _getColumnValues(table, iCol) {
        var resultArr = [];

        table.find('tr.logonHoursData').each(function (index) {
            if (index >= WEEKDAYCOUNT) { return; }

            var tdHour = $($(this).find('.logonHours')[iCol]);

            if (tdHour.hasClass('allowedLogonHours')) {
                resultArr.push(1);
            }
            else if (tdHour.hasClass('deniedLogonHours')) {
                resultArr.push(0);
            }
            else {
                return null;
            }
        });

        return resultArr;
    }

    function _markRow(table, iRow, allowed) {
        var trsData = $(table.find('tr.logonHoursData')[iRow]);
        if (!trsData) { return; }

        var tdsData = trsData.find('.logonHours');
        if (!tdsData || tdsData.length != HOURSPERDAY) { return; }

        tdsData.removeClass('allowedLogonHours deniedLogonHours')
            .addClass(allowed ? 'allowedLogonHours' : 'deniedLogonHours');
    }

    function _markColumn(table, iCol, allowed) {
        table.find('tr.logonHoursData').each(function (index) {
            if (index >= WEEKDAYCOUNT) { return; }

            var tdHour = $($(this).find('.logonHours')[iCol]);
            tdHour.removeClass('allowedLogonHours deniedLogonHours')
                .addClass(allowed ? 'allowedLogonHours' : 'deniedLogonHours');
        });
    }

    function _markCell(table, iCol, iRow, allowed) {
        var row = $(table.find('tr.logonHoursData')[iRow]);
        var tdHour = $(row.find('.logonHours')[iCol]);
        tdHour.removeClass('allowedLogonHours deniedLogonHours')
            .addClass(allowed ? 'allowedLogonHours' : 'deniedLogonHours');
    }

    function _getXPos(target) {
        var targetElem = target;
        if (!target.hasClass('logonHours')) {
            var targetElem = target.parents('.logonHours').first();
        }
        if (!targetElem) { return -1; }
        var allElements = target.parents('tr').first().find('.logonHours');
        return allElements.index(targetElem);
    }

    function _getYPos(target) {
        var targetElem = target.parents('tr').first();
        if (!targetElem) { return -1; }
        var allElements = target.parents('.logonHoursTable').first().find('.logonHoursData');
        return allElements.index(targetElem);
    }

    function _performClickHandling(elem) {
        var jsonObj = elem.attrinfo('jsonObject');
        if (jsonObj.readonly || (uiManager.IsInlineModifyTurnedOn() && elem.attrinfo('option', 'switchedMode') != 'EditMode')) {
            return false;
        }
        return true;
    }

    //////////////////////////////////////////////////////////////////////////
    // event handlers

    function _allHoursDaysClick(event) {
        if (!_performClickHandling(event.data.element)) {
            event.preventDefault();
            return false;
        }

        _turnElementEditMode(event.data.element);

        // find edit mode
        var editModeTable =
            $(event.target).parents('div.ldapAttrInfoDiv').first()
            .find('table.editValues .logonHoursTable').first();

        var deniedExists = false;
        for (var i = 0; i < WEEKDAYCOUNT; ++i) {
            if (deniedExists) { break; }
            var res = _getRowValues(editModeTable, i);
            for (var j = 0; j < res.length; ++j) {
                if (res[j] == 0) {
                    deniedExists = true;
                    break;
                }
            }
        }

        for (var i = 0; i < WEEKDAYCOUNT; ++i) {
            _markRow(editModeTable, i, deniedExists);
        }

        return false;
    }

    function _allHoursClick(event) {
        if (!_performClickHandling(event.data.element)) {
            event.preventDefault();
            return false;
        }

        var yPos = _getYPos($(event.target));
        if (yPos == -1) { return false; }
        _turnElementEditMode(event.data.element);

        // find edit mode
        var editModeTable =
            $(event.target).parents('div.ldapAttrInfoDiv').first()
            .find('table.editValues .logonHoursTable').first();
        var deniedExists = false;
        var res = _getRowValues(editModeTable, yPos);
        for (var i = 0; i < HOURSPERDAY; ++i) {
            if (res[i] == 0) {
                deniedExists = true;
                break;
            }
        }
        _markRow(editModeTable, yPos, deniedExists);

        return false;
    }

    function _allDaysClick(event) {
        if (!_performClickHandling(event.data.element)) {
            event.preventDefault();
            return false;
        }

        var xPos = _getXPos($(event.target));
        if (xPos == -1) { return false; }
        _turnElementEditMode(event.data.element);

        // find edit mode
        var editModeTable =
            $(event.target).parents('div.ldapAttrInfoDiv').first()
            .find('table.editValues .logonHoursTable').first();
        var deniedExists = false;
        var res = _getColumnValues(editModeTable, xPos);
        for (var i = 0; i < WEEKDAYCOUNT; ++i) {
            if (res[i] == 0) {
                deniedExists = true;
                break;
            }
        }
        _markColumn(editModeTable, xPos, deniedExists);

        return false;
    }

    function _hourCellClick(event) {
        if (!_performClickHandling(event.data.element)) {
            event.preventDefault();
            return false;
        }

        var target = $(event.target);
        var elem = event.data.element;

        if (elem.attrinfo('option', 'switchedMode') == 'ViewMode') {
            var xPos = _getXPos(target);
            var yPos = _getYPos(target);
            if (xPos == -1 || yPos == -1) { return false; }

            var allowed = true;
            if (target.hasClass('allowedLogonHours')) {
                allowed = true;
            }
            else if (target.hasClass('deniedLogonHours')) {
                allowed = false;
            }
            else {
                return false;
            }

            elem.attrinfo('turnMode', 'EditMode', { clearViewModeContent: false });

            PostponedBindsManager.PerformBinds();

            var editModeTable = $(target).parents('div.ldapAttrInfoDiv').first().find('table.editValues .logonHoursTable').first();
            _markCell(editModeTable, xPos, yPos, !allowed);
        }
        else {
            if (target.hasClass('allowedLogonHours')) {
                target.removeClass('allowedLogonHours').addClass('deniedLogonHours');
            }
            else if (target.hasClass('deniedLogonHours')) {
                target.removeClass('deniedLogonHours').addClass('allowedLogonHours');
            }
        }
        return false;
    }

    function _GenLogonHours(elem, i, newEditVal, mode) {
        var currAttr = elem.attrinfo('jsonObject');

        var currModeEventHandler = mode == 'ViewMode' ? 
            elem.attrinfo('option', 'ViewModeEventHandler') :
            elem.attrinfo('option', 'EditModeEventHandler');

        var logonHours;
        if (i == 0) {
            // check is value deleted
            if (typeof currAttr.uDispEditVals2 == 'undefined' ||
            typeof currAttr.uDispEditVals2[i] == 'undefined') { return; }

            logonHours = currAttr.uDispEditVals2[i];
        }
        else if (i == -1 && newEditVal) {
            logonHours = newEditVal;
        }
        else {
            return;
        }

        var daysOfWeek = currAttr.uDaysOfWeek;

        if (logonHours.length != HOURSPERDAY * WEEKDAYCOUNT) { return; }

        //////////////////////////////////////////////////////////////////////////
        // local functions

        function _generateEmptyTop(elem, appendTo) {
            appendTo.append('<tr class="logonHoursEmptyData">');

            // add empty day
            var classHoursDaysHeader = 'logonHoursAllHoursDays';
            appendTo.append('<td class="' + classHoursDaysHeader + '" title="' + S_ALWAYS + '"></td>');

            if (!uiManager.IsProfileReadonly()) {
                currModeEventHandler.addHandler(classHoursDaysHeader, 'click', { func: _allHoursDaysClick, data: { element: elem} });
            }
            
            // add LogonHours empty values
            for (var iHour = 0; iHour < HOURSPERDAY; ++iHour) {
                // tdHour
                var tdHour = new TagBuilder('td');
                {
                    var classAllDays = 'logonHoursAllDays';
                    tdHour.addClass(classAllDays);
                    tdHour.addClass('logonHours');
                    tdHour.addClass('empty');
                    tdHour.addContent(iHour);

                    var tdTitle = Softerra.Class.StringMgr.Format(S_HOURS_WHOLE_WEEK,
                            daysOfWeek[0], daysOfWeek[WEEKDAYCOUNT - 1], iHour, ((iHour + 1) % 24));
                    tdHour.addAttrEscaped('title', tdTitle);

                    if (!uiManager.IsProfileReadonly()) {
                        currModeEventHandler.addHandler(classAllDays, 'click', { func: _allDaysClick, data: { element: elem} });
                    }
                }
                appendTo.append(tdHour.toString());
            }

            appendTo.append('</tr>'); // logonHoursEmptyData
        }

        function _generateData(elem, appendTo) {
            for (var iDay = 0; iDay < WEEKDAYCOUNT; ++iDay) {
                appendTo.append('<tr class="logonHoursData">');

                // add day name
                var classAllHours = 'logonHoursAllHours';
                var tdDay = '<td class="' + classAllHours + '" title="' + S_ALL_DAY + '"><span class="dayOfWeek logonHoursAllHours">'
                    + daysOfWeek[iDay] + '</span></td>';
                appendTo.append(tdDay);

                if (!uiManager.IsProfileReadonly()) {
                    currModeEventHandler.addHandler(classAllHours, 'click', { func: _allHoursClick, data: { element: elem} });
                }

                // add LogonHours values
                for (var iHour = 0; iHour < HOURSPERDAY; ++iHour) {
                    // tdHour
                    var tdHour = new TagBuilder('td');
                    {
                        var denied = logonHours.charAt(iDay * HOURSPERDAY + iHour) == '0';
                        var classOneCell = 'logonHoursOneCell';
                        tdHour.addClass('logonHours');
                        tdHour.addClass(classOneCell);
                        tdHour.addClass(denied ? 'deniedLogonHours' : 'allowedLogonHours');

                        var tdTitle = Softerra.Class.StringMgr.Format(S_DAY_FROM_TO,
                            daysOfWeek[iDay], iHour, ((iHour + 1) % 24));
                        tdHour.addAttrEscaped('title', tdTitle);

                        if (!uiManager.IsProfileReadonly()) {
                            currModeEventHandler.addHandler(classOneCell, 'click', { func: _hourCellClick, data: { element: elem} });
                        }
                    }
                    appendTo.append(tdHour.toString());
                }

                appendTo.append('</tr>'); // logonHoursData
            }
        }

        function _generateLegend() {
            var trLegend = new TagBuilder('tr');
            trLegend.addClass('logonHoursLegend');
            trLegend.addContent('<td></td>');

            // tdLegend
            var tdLegend = new TagBuilder('td');
            {
                tdLegend.addAttr('colspan', '' + HOURSPERDAY);
                tdLegend.addContent('<table class="legendTable"><tr>');
                tdLegend.addContent('<td class="logonHoursSpacing"></td>');
                tdLegend.addContent('<td class="logonHours allowedLogonHours"><div class="logonHours"></div></td>');
                tdLegend.addContent('<td class="description"><span>' + S_LOGON_PERMITTED + '</span></td>');

                tdLegend.addContent('<td class="logonHours deniedLogonHours"><div class="logonHours"></div></td>');
                tdLegend.addContent('<td class="lastdescription"><span>' + S_LOGON_DENIED + '</span></td>');

                tdLegend.addContent('</tr></table>');
            }
            trLegend.addContent(tdLegend.toString());

            return trLegend.toString();
        }

        // --local functions
        //////////////////////////////////////////////////////////////////////////
        
        var resultTable = new StringBuilder();
        resultTable.append('<div class="logonHoursTableDiv">');
        resultTable.append('<table class="logonHoursTable">');

        // generate empty top
        _generateEmptyTop(elem, resultTable);

        // generate data
        _generateData(elem, resultTable);

        // generate legend
        resultTable.append(_generateLegend());

        resultTable.append('</table>'); // logonHoursTable
        resultTable.append('</div>'); // logonHoursTable div

        return resultTable.toString();
    }
}
