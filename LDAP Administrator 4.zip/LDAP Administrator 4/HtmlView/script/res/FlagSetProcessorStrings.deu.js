﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

Softerra.Const.UserAccountControlFlagSetSettings = [
    //Value, Properties, ShortName, Name, Description
    [0x1, 0, "LogonScript", "Anmeldeskript wird ausgeführt", "Das Anmeldeskript wird ausgeführt. Dieser Flag funktioniert nicht für ADSI-LDAP-Anbieter bei Lese- und Schreibvorgängen. Für einen ADSI-WinNT-Anbieter bedeutet dieser Flag schreibgeschützten Daten und kann für Benutzerobjekte nicht gesetzt werden.\r\nADSI-Flag: ADS_UF_SCRIPT"],
    [0x2, 0, "AccountDisabled", "Konto ist deaktiviert", "Das Benutzerkonto ist deaktiviert.\r\nADSI-Flag: ADS_UF_ACCOUNTDISABLE"],
    [0x8, 0, "HomeDirectoryRequired", "Das Basisverzeichnis ist erforderlich", "Das Basisverzeichnis ist erforderlich.\r\nADSI-Flag: ADS_UF_HOMEDIR_REQUIRED"],
    [0x10, 0, "AccountLocked", "Konto ist gesperrt", "Konto ist zur Zeit gesperrt.\r\nADSI-Flag: ADS_UF_LOCKOUT"],
    [0x20, 0, "NoPasswordRequired", "Kein Kennwort ist erforderlich", "Kein Kennwort ist erforderlich.\r\nADSI-Flag: ADS_UF_PASSWD_NOTREQD"],
    [0x40, 0, "DisallowChangePassword", "Das Kennwort kann vom Benutzer nicht geändert werden", "Das Kennwort kann vom Benutzer nicht geändert werden. Dieser Flag kann gelesen, aber nicht direkt gesetzt werden.\r\nADSI-Flag: ADS_UF_PASSWD_CANT_CHANGE"],
    [0x80, 0, "ReversibleEncryptionPassword", "Das Kennwort mit Hilfe der umkehrbaren Verschlüsselung speichern", "Der Benutzer kann ein verschlüsseltes Kennwort senden.\r\nADSI-Flag: ADS_UF_ENCRYPTED_TEXT_PASSWORD_ALLOWED"],
    [0x100, 0, "TempDuplicateAccount", "Vorübergehend dupliziertes Konto", "Dieses Konto ist für die Benutzer bestimmt, deren primäres Konto in einer anderen Domäne liegt. Dieses Konto bietet den Benutzern Zugriff auf diese Domäne, aber nicht auf beibiege Domäne, die dieser Domäne traut.\r\nADSI-Flag: ADS_UF_TEMP_DUPLICATE_ACCOUNT"],
    [0x200, 0, "NormalAccount", "Normales Konto", "Es ist ein standardmäßiger Kontotyp, der einen typischen Benutzer darstellt.\r\nADSI-Flag: ADS_UF_NORMAL_ACCOUNT"],
    [0x800, 0, "InterdomainTrustAccount", "Domänenübergreifendes Vertrauenskonto", "Es ist eine Erlaubnis, das Konto einer Systemdomäne zu vertrauen, die anderen Domänen vertraut.\r\nADSI-Flag: ADS_UF_INTERDOMAIN_TRUST_ACCOUNT"],
    [0x1000, 0, "WorkstationTrustAccount", "Arbeitsstation-Vertrauenskonto", "Es ist ein Computerkonto für Microsoft Windows NT Arbeitsstation / Windows 2000 Professional oder Windows NT Server/Windows 2000 Server, die Mitglieder dieser Domäne sind.\r\nADSI-Flag: ADS_UF_WORKSTATION_TRUST_ACCOUNT"],
    [0x2000, 0, "ServerTrustAccount", "Server-Vertrauenskonto", "Es ist ein Computerkonto für einen Systemreservedomänencontroller, der ein Mitglied dieser Domäne ist.\r\nADSI-Flag: ADS_UF_SERVER_TRUST_ACCOUNT"],
    [0x10000, 0, "NoPasswordExpiration", "Das Kennwort läuft nie ab", "Das Kennwort für dieses Konto wird nie ablaufen.\r\nADSI-Flag: ADS_UF_DONT_EXPIRE_PASSWD"],
    [0x20000, 0, "MSNLogonAccount", "MSN-Anmeldekonto", "Es ist ein MSN-Anmeldekonto.\r\nADSI-Flag: ADS_UF_MNS_LOGON_ACCOUNT"],
    [0x40000, 0, "SmartcardRequired", "Eine Smartcard ist für interaktive Anmeldung erforderlich", "Der Benutzer muss mit Hilfe einer Smartcard anmelden.\r\nADSI-Flag: ADS_UF_SMARTCARD_REQUIRED"],
    [0x80000, 0, "TrustedForDelegation", "Dem Konto wird für Delegierungszwecke vertraut", "Dem Dienstkonto (Benutzer- oder Computerkonto), unter dem ein Dienst funktioniert, wird für Kerberos-Delegierungszwecke vertraut. Jeder solcher Dienst kann einen Client imitieren, der den Dienst abfragt.\r\nADSI-Flag: ADS_UF_TRUSTED_FOR_DELEGATION"],
    [0x100000, 0, "NotDelegated", "Konto ist vertraulich und kann nicht delegiert werden", "Der Sicherheitskontext des Benutzers wird nicht einem Dienst delegiert, sogar wenn das Dienstkonto als ein für Kerberos-Delegierung vertrauenswürdiges gesetzt ist.\r\nADSI-Flag: ADS_UF_NOT_DELEGATED"],
    [0x200000, 0, "DESKeyOnly", "Für dieses Konto verwenden Sie DES-Verschlüsselungstypen", "Diesen Prinzipal einschränken, so dass nur DES-Standardverschlüsselungstypen (Data Encryption Standard) für Schlüssel verwendet werden können.\r\nADSI-Flag: ADS_UF_USE_DES_KEY_ONLY"],
    [0x400000, 0, "NoPreauthRequired", "Keine Kerberos-Präauthentifizierung erforderlich", "Dieses Konto erfordert keine Kerberos-Präauthentifizierung für die Anmeldung.\r\nADSI-Flag: ADS_UF_DONT_REQUIRE_PREAUTH"],
    [0x800000, 0, "PasswordExpired", "Das Kennwort ist abgelaufen", "Das Benutzerkennwort ist abgelaufen. Dieser Flag wurde vom System anhand der Daten aus dem Attribute des zuletzt gesetzten Kennwortes und der Domänenrichtlinien erstellt. Es ist schreibgeschützt und kann nicht gesetzt werden.\r\nADSI-Flag: ADS_UF_PASSWORD_EXPIRED"],
    [0x1000000, 0, "TrustedToAuthForDelegation", "Das Konto ist vertrauenswürdig hinsichtlich der Delegierung", "Das Konto ist für Delegierung aktiviert. Diese Einstellung sollte aus Sicherheitsgründen vorsichtig vorgenommen werden; die Konten, bei denen diese Option aktiviert ist, unterliegen einer strengen Kontrolle. Diese Einstellung ermöglicht einem Dienst, der unter diesem Konto ausgeführt wird, die Identität des Clients anzunehmen und sich unter diesen Anmeldeinformationen auf anderen Remoteservern im Netzwerk anzumelden.\r\nADSI-Flag: ADS_UF_TRUSTED_TO_AUTHENTICATE_FOR_DELEGATION"],
    [0x2000000, 0, "NoAuthDataRequired", "PAC muss in einem Kerberos-Ticket nicht enthalten sein", "Dieses Bit gibt an, dass bei der Ausgabe eines Service-Tickets vom KDC für dieses Konto PAC NICHT eingeschlossen werden muss. Weitere Informationen finden Sie in RFC4120."],
    [0x4000000, 0, "PartialSecretsAccount", "Das Konto ist ein Computerkonto für einen RODC", "Gibt an, dass das Konto ein Computerkonto für einen RODC ist. Ist dieses Bit gesetzt, so muss WorkstationTrustAccount auch gesetzt werden. (Windows Server 2008 und später)."]
];
