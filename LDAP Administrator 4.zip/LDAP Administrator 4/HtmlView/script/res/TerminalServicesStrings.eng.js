﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

//////////////////////////////////////////////////////////////////////////
// Sessions

var S_END_DISCONN_SESS = 'End a disconnected session:';
var S_ACTIVE_SESS_LIMIT = 'Active session limit:';
var S_IDLE_SESS_LIMIT = 'Idle session limit:';
var S_SESS_LIMIT_COMBO = [
    [0, 'Never'],
    [1, '1 minute'],
    [5, '5 minutes'],
    [10, '10 minutes'],
    [15, '15 minutes'],
    [30, '30 minutes'],
    [60, '1 hour'],
    [120, '2 hours'],
    [180, '3 hours'],
    [1440, '1 day'],
    [2880, '2 days']
];

var S_SESS_LIMIT_REACHED = 'When a session limit is reached or connection is broken:';
var S_SESS_LIMIT_REACHED_GROUP = [
    [0, 'Disconnect from session'],
    [1, 'End session']
];

var S_ALLOW_RECONN = 'Allow reconnection:';
var S_ALLOW_RECONN_GROUP = [
    [0, 'From any client'],
    [1, 'From originating client only']
];

//////////////////////////////////////////////////////////////////////////
// Environment

var S_ENVIR_STARTINGPROGRAM = 'Starting program:';
var S_ENVIR_START_PROGRAM_AT_LOGON = 'Start the following program at logon:';
var S_ENVIR_PROGRAM_FILE_NAME = 'Program file name:';
var S_ENVIR_START_IN = 'Start in:';

var S_ENVIR_CLIENT_DEVICES = 'Client devices:';
var S_ENVIR_CONN_CLIENT_DRIVES = 'Connect client drives at logon';
var S_ENVIR_CONN_CLIENT_PRINTERS = 'Connect client printers at logon';
var S_ENVIR_DEF_TO_MAIN_PRINTER = 'Default to main client printer';

//////////////////////////////////////////////////////////////////////////
// Remote Control
var S_REMCONTROL_ENABLECONTROL_DESCR = 'To remotely control or observe a user\'s session, select the following checkbox:';
var S_REMCONTROL_ENABLECONTROL = 'Enable remote control';
var S_REMCONTROL_REQPERMISSION_DESCR = 'To require the user\'s permission to control or observe the session, select the following checkbox:';
var S_REMCONTROL_REQPERMISSION = 'Require user\'s permission';
var S_REMCONTROL_CONTROLLEVEL_DESCR = 'Specify the level of control you want to have over a user\'s session:';
var S_REMCONTROL_VIEWSESSION = 'View the user\'s session';
var S_REMCONTROL_INTERACTSESSION = 'Interact with the session';

//////////////////////////////////////////////////////////////////////////
// Terminal Services Profile

var S_TERMSPROF_PROFILE_PATH = 'Profile path:';
var S_TERMSPROF_HOME_FOLDER = 'Home folder:';
var S_TERMSPROF_LOCAL_PATH = 'Local path:';
var S_TERMSPROF_CONNECT = 'Connect:';
var S_TERMSPROF_TO = 'To:';
var S_TERMSPROF_ALLOW_LOGON = 'Allow logon to terminal server';