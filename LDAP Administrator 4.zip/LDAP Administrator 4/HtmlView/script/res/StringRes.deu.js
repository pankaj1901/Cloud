﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

var CURRENT_LANG = 'deu';

var S_CUSTOMEDITOR = 'Mit dem benutzerdefinierten Editor bearbeiten';

var S_NO_CHILDREN = 'Es gibt keine Elemente zum Anzeigen.';

var S_SAVE = 'Speichern';
var S_CANCEL = 'Abbrechen';

var S_ABUTTON_SAVE = 'speichern';
var S_ABUTTON_CANCEL = 'abbrechen';
var S_ABUTTON_SAVE_ABBR = 'speich.';
var S_ABUTTON_CANCEL_ABBR = 'abbrech.';
var S_ABUTTON_EDIT = 'Bearbeiten';
var S_ABUTTON_DELETE = 'Löschen';
var S_ABUTTON_ADD = 'Hinzufügen';

var S_ONE_MEMBER_FOUND = '1 Mitglied gefunden';
var S_N_MEMBERS_FOUND = '%s Mitglieder gefunden';
var S_ONE_GROUP_FOUND = '1 Gruppe gefunden';
var S_N_GROUPS_FOUND = '%s Gruppen gefunden';
var S_FETCHED_N_ELEMENTS = 'Suche...&nbsp;&nbsp;&nbsp;&nbsp;Gefunden: %s';
var S_SEARCH_ABORTED = 'Suche vom Benutzer abgebrochen.';
var S_FETCH_ALL_OBJECTS = 'Alle verfügbaren Objekte abrufen';
var S_MEMBERS = 'Mitglied';
var S_GROUPS = 'Gruppe';
var S_PARENTS = 'Übergeordneter DN';
var S_TYPE = 'Typ'; 
var S_OBJECT = 'Objekt';
var S_MEMBERSHIP_FILTER_CUE = 'Geben Sie einen Objektnamen oder Maske ein';
var S_ADD = 'HINZUFÜGEN';
var S_REMOVE = 'ENTFERNEN';

var S_IMPORT = 'IMPORTIEREN';
var S_EXPORT = 'EXPORTIEREN';
var S_MODIFY_DYNAMIC_MEMBERSHIP = 'Dynamische Mitgliedschaft ändern...';

var S_APPLYING_CHANGES = 'Die Änderungen werden übernommen...';
var S_N_OBJECTS_SELECTED = '%s Objekte ausgewählt';
var S_ONE_OBJECT_SELECTED = '1 Objekt ausgewählt';

var S_TRUE = 'Wahr';
var S_FALSE = 'Falsch';

var S_PREV = 'Zur';
var S_NEXT = 'Weit';

var S_STOP = 'Beenden';
var S_REFRESH = 'Aktualisieren';

var S_PROC_NOT_FOUND = 'Prozessor nicht gefunden.';
var S_ARG_LIST_SIZE_ERROR = 'Falsche Anzahl von Parametern.';
var S_ARG_LIST_TYPE_ERROR = 'Falscher Typ des Arguments mit Index %s.';

var S_FLAG = 'Flag';
var S_SAVING = '&nbsp;&nbsp;&nbsp;Wird gespeichert...';

var S_PAGE_DATA_LOST = 'Sind Sie sicher, dass Sie zum Bearbeitungsmodus wechseln möchten? Alle nicht gespeicherten Daten werden verloren gehen.';
var S_CHANGE_TO_VIEW_MODE = 'Sind Sie sicher, dass Sie zum Anzeigen-Modus wechseln möchten? Alle nicht gespeicherten Daten werden verloren gehen.';
var S_TABCLICK_DATA_LOST = 'Sind Sie sicher, dass Sie zu einer anderen Registerkarte wechseln möchten? Alle nicht gespeicherten Daten werden verloren gehen.';
var S_CONTROLCLICK_DATA_LOST = 'Nicht gespeicherte Änderungen gehen verloren, wenn Sie dieses Steuerelement zum Bearbeitungsmodus wechseln.\n\nSind Sie sicher, dass Sie den Vorgang fortsetzen möchten?';
var S_ATTRIBUTESCHANGED_SAVECONFIRM = "%s wurde geändert. \nMöchten Sie die von Ihnen vorgenommenen Änderungen speichern?";
var S_USERPARAMETERS_PARSING_FAILED = "Fehler beim Analysieren des Wertes vom Attribut userParameters.\nDas Format des Wertes ist nicht gültig.\nStandardeinstellungen für Remotedesktopdienste anzeigen."

var S_ENTRY = 'Eintrag';
var S_GROUP = 'Gruppe';
var S_SERVER_PROFILE = 'Serverprofil';
var S_LDAP_REFERRAL = 'LDAP-Referenz';
var S_SEARCH_RESULT = 'Suchergebnis';

var S_HELP = 'Hilfe';
var S_FAILED_LAUNCH_HELP = 'Fehler beim Starten der Hilfe.';

var S_LOGON_PERMITTED = 'Anmeldung gestattet';
var S_LOGON_DENIED = 'Anmeldung verweigert';
var S_DAY_FROM_TO = '%s von %s:00 bis %s:00';
var S_ALWAYS = 'Immer';
var S_ALL_DAY = 'Den ganzen Tag';
var S_HOURS_WHOLE_WEEK = '%s bis %s von %s:00 bis %s:00';

var S_ADD_PHOTO = 'Photo Hinzufügen';
var S_CHANGE = 'Ändern';
var S_DELETE = 'Löschen';
var S_OPERATION_FAILED = 'Vorgang fehlgeschlagen.';

var S_ENABLE_ACCOUNT  = 'AKTIVIEREN';
var S_DISABLE_ACCOUNT = 'DEAKTIVIEREN';
var S_RESET_PASSWORD  = 'KENNWORT ZURÜCKSETZEN';
var S_UNLOCK_ACCOUNT  = 'ENTSPERREN';

var S_EDIT_BTN = "BEARBEITEN";
var S_VIEW_BTN = "ANZEIGEN";
