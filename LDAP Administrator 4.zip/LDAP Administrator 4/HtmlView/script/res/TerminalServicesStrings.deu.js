﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

//////////////////////////////////////////////////////////////////////////
// Sessions

var S_END_DISCONN_SESS = 'Getrennte Sitzung beenden:';
var S_ACTIVE_SESS_LIMIT = 'Zeitlimit für aktive Sitzungen:';
var S_IDLE_SESS_LIMIT = 'Leerlaufsitzungslimit:';
var S_SESS_LIMIT_COMBO = [
    [0, 'Nie'],
    [1, '1 Minute'],
    [5, '5 Minuten'],
    [10, '10 Minuten'],
    [15, '15 Minuten'],
    [30, '30 Minuten'],
    [60, '1 Stunde'],
    [120, '2 Stunden'],
    [180, '3 Stunden'],
    [1440, '1 Tag'],
    [2880, '2 Tage']
];

var S_SESS_LIMIT_REACHED = 'Wenn das Sitzungslimit erreicht oder die Verbindung getrennt wurde:';
var S_SESS_LIMIT_REACHED_GROUP = [
    [0, 'Sitzung trennen'],
    [1, 'Sitzung beenden']
];

var S_ALLOW_RECONN = 'Erneute Verbindung zulassen:';
var S_ALLOW_RECONN_GROUP = [
    [0, 'Von einem beliebigen Client'],
    [1, 'Nur vom ursprünglichen Client']
];

//////////////////////////////////////////////////////////////////////////
// Environment

var S_ENVIR_STARTINGPROGRAM = 'Programm wird gestartet';
var S_ENVIR_START_PROGRAM_AT_LOGON = 'Das folgende Programm bei der Anmeldung starten:';
var S_ENVIR_PROGRAM_FILE_NAME = 'Programm-Dateiname:';
var S_ENVIR_START_IN = 'Starten in:';

var S_ENVIR_CLIENT_DEVICES = 'Clientgeräte';
var S_ENVIR_CONN_CLIENT_DRIVES = 'Clientgeräte bei der Anmeldung anschliessen';
var S_ENVIR_CONN_CLIENT_PRINTERS = 'Clientdrucker bei der Anmeldung anschliessen';
var S_ENVIR_DEF_TO_MAIN_PRINTER = 'Standardmäßig der Client-Hauptdrucker';

//////////////////////////////////////////////////////////////////////////
// Remote Control
var S_REMCONTROL_ENABLECONTROL_DESCR = 'Markieren Sie das folgende Kontrollkästchen, um die Remotesteuerung für eine Benutzersitzung zu aktivieren:';
var S_REMCONTROL_ENABLECONTROL = 'Remotesteuerung aktivieren';
var S_REMCONTROL_REQPERMISSION_DESCR = 'Markieren Sie das folgende Kontrollkästchen, um die Erlaubnis des Benutzers zum Überwachen der Sitzung einzuholen:';
var S_REMCONTROL_REQPERMISSION = 'Erlaubnis des Benutzers einholen';
var S_REMCONTROL_CONTROLLEVEL_DESCR = 'Geben Sie die Überwachungsebene für eine Benutzersitzung an';
var S_REMCONTROL_VIEWSESSION = 'Benutzersitzung anzeigen';
var S_REMCONTROL_INTERACTSESSION = 'In die Sitzung eingreifen';

//////////////////////////////////////////////////////////////////////////
// Terminal Services Profile

var S_TERMSPROF_PROFILE_PATH = 'Profilpfad:';
var S_TERMSPROF_HOME_FOLDER = 'Basisordner';
var S_TERMSPROF_LOCAL_PATH = 'Lokaler Pfad:';
var S_TERMSPROF_CONNECT = 'Verbinden:';
var S_TERMSPROF_TO = 'Mit:';
var S_TERMSPROF_ALLOW_LOGON = 'Anmeldung zum Terminalserver zulassen';