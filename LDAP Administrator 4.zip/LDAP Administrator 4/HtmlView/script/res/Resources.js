﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

var IMG_PERSON_DEFAULT_PHOTO = 'header/user_no_photo.png';
var IMG_PERSON_DEFAULT_PHOTO_DARK = 'header/user_no_photo_dark.png';

var IMG_EDIT_WITH_CUSTOM_EDITOR = 'operations/launch_custom_editor.png';
var IMG_EDIT_WITH_CUSTOM_EDITOR_DARK = 'operations/launch_custom_editor_dark.png';
 
var IMG_M2G_SEARCHSTART = 'operations/m2g_search.png';
var IMG_M2G_SEARCHSTART_DARK = 'operations/m2g_search_dark.png';

var IMG_M2G_SEARCHSTOP = 'operations/m2g_stopsearch.png';
var IMG_M2G_SEARCHSTOP_DARK = 'operations/m2g_stopsearch_dark.png';

var IMG_EDITBTN_ENG = 'operations/edit_eng.ico';
var IMG_EDITBTN_OVER_ENG = 'operations/edit_over_eng.ico';
var IMG_EDITBTN_CLICKED_ENG = 'operations/edit_clicked_eng.ico';
var IMG_EDITBTN_DEU = 'operations/edit_deu.ico';
var IMG_EDITBTN_OVER_DEU = 'operations/edit_over_deu.ico';
var IMG_EDITBTN_CLICKED_DEU = 'operations/edit_clicked_deu.ico';

var IMG_VIEWBTN_ENG = 'operations/view_eng.ico';
var IMG_VIEWBTN_OVER_ENG = 'operations/view_over_eng.ico';
var IMG_VIEWBTN_CLICKED_ENG = 'operations/view_clicked_eng.ico';
var IMG_VIEWBTN_DEU = 'operations/view_deu.ico';
var IMG_VIEWBTN_OVER_DEU = 'operations/view_over_deu.ico';
var IMG_VIEWBTN_CLICKED_DEU = 'operations/view_clicked_deu.ico';

var IMG_WAIT_SMALL = 'operations/wait.png';
var IMG_WAIT_SMALL_DARK = 'operations/wait_dark.png';
