﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

var CURRENT_LANG = 'eng';

var S_CUSTOMEDITOR = 'Edit with the custom editor';

var S_NO_CHILDREN = 'There are no items to display.';

var S_SAVE = 'Save';
var S_CANCEL = 'Cancel';

var S_ABUTTON_SAVE = 'save';
var S_ABUTTON_CANCEL = 'cancel';
var S_ABUTTON_SAVE_ABBR = 'save';
var S_ABUTTON_CANCEL_ABBR = 'cancel';
var S_ABUTTON_EDIT = 'Edit';
var S_ABUTTON_DELETE = 'Delete';
var S_ABUTTON_ADD = 'Add';

var S_ONE_MEMBER_FOUND = '1 member found';
var S_N_MEMBERS_FOUND = '%s members found';
var S_ONE_GROUP_FOUND = '1 group found';
var S_N_GROUPS_FOUND = '%s groups found';
var S_FETCHED_N_ELEMENTS = 'Searching...&nbsp;&nbsp;&nbsp;&nbsp;Found: %s';
var S_SEARCH_ABORTED = 'Search aborted by user.';
var S_FETCH_ALL_OBJECTS = 'Fetch all available objects';
var S_MEMBERS = 'Member';
var S_GROUPS = 'Group';
var S_PARENTS = 'Parent DN';
var S_TYPE = 'Type';
var S_OBJECT = 'Object';
var S_MEMBERSHIP_FILTER_CUE = 'type an object name or mask';
var S_ADD = 'ADD';
var S_REMOVE = 'REMOVE';
var S_IMPORT = 'IMPORT';
var S_EXPORT = 'EXPORT';
var S_MODIFY_DYNAMIC_MEMBERSHIP = 'Modify Dynamic Membership...';
var S_APPLYING_CHANGES = 'Applying changes...';
var S_N_OBJECTS_SELECTED = '%s objects selected';
var S_ONE_OBJECT_SELECTED = '1 object selected';

var S_TRUE = 'True';
var S_FALSE = 'False';

var S_PREV = 'Prev';
var S_NEXT = 'Next';

var S_STOP = 'Stop';
var S_REFRESH = 'Refresh';

var S_PROC_NOT_FOUND = 'Processor not found.';
var S_ARG_LIST_SIZE_ERROR = 'Wrong parameter count.';
var S_ARG_LIST_TYPE_ERROR = 'Wrong type of argument with index %s.';

var S_FLAG = 'Flag';
var S_SAVING = '&nbsp;&nbsp;&nbsp;Saving...';

var S_PAGE_DATA_LOST = 'Are you sure you want to switch to Edit mode? All unsaved data will be lost.';
var S_CHANGE_TO_VIEW_MODE = 'Are you sure you want to switch to View mode? All unsaved data will be lost.';
var S_TABCLICK_DATA_LOST = 'Are you sure you want to switch to another tab? All unsaved data will be lost.';
var S_CONTROLCLICK_DATA_LOST = 'Unsaved modifications will be lost if you switch this control to the edit mode.\n\nAre you sure you would like to continue?';
var S_ATTRIBUTESCHANGED_SAVECONFIRM = "The %s was modified. \nDo you want to save the changes you've made?";
var S_USERPARAMETERS_PARSING_FAILED = "Fail to parse the userParameters attribute value.\nThe value format is not valid.\nShow default Remote Desktop Services settings."

var S_ENTRY = 'Entry';
var S_GROUP = 'Group';
var S_SERVER_PROFILE = 'Server Profile';
var S_LDAP_REFERRAL = 'LDAP Referral';
var S_SEARCH_RESULT = 'Search Result';

var S_HELP = 'Help';
var S_FAILED_LAUNCH_HELP = 'Failed to launch help.';

var S_LOGON_PERMITTED = 'Logon Permitted';
var S_LOGON_DENIED = 'Logon Denied';
var S_DAY_FROM_TO = '%s from %s:00 to %s:00';
var S_ALWAYS = 'Always';
var S_ALL_DAY = 'All day';
var S_HOURS_WHOLE_WEEK = '%s through %s from %s:00 to %s:00';

var S_ADD_PHOTO = 'Add Photo'; 
var S_CHANGE = 'Change';
var S_DELETE = 'Delete';
var S_OPERATION_FAILED = 'Operation failed.';

var S_ENABLE_ACCOUNT  = 'ENABLE';
var S_DISABLE_ACCOUNT = 'DISABLE';
var S_RESET_PASSWORD  = 'RESET PASSWORD';
var S_UNLOCK_ACCOUNT = 'UNLOCK';

var S_EDIT_BTN = "EDIT";
var S_VIEW_BTN = "VIEW";