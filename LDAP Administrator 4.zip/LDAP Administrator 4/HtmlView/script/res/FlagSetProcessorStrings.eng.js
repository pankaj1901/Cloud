﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

Softerra.Const.UserAccountControlFlagSetSettings = [
    //Value, Properties, ShortName, Name, Description
    [0x1, 0, "LogonScript", "Logon script is executed", "The logon script is executed. This flag does not work for the ADSI LDAP provider on either read or write operations. For the ADSI WinNT provider, this flag is read-only data, and it cannot be set for user objects.\r\nADSI flag: ADS_UF_SCRIPT"],
    [0x2, 0, "AccountDisabled", "Account is disabled", "The user account is disabled.\r\nADSI flag: ADS_UF_ACCOUNTDISABLE"],
    [0x8, 0, "HomeDirectoryRequired", "Home directory is required", "The home directory is required.\r\nADSI flag: ADS_UF_HOMEDIR_REQUIRED"],
    [0x10, 0, "AccountLocked", "Account is locked out", "The account is currently locked out.\r\nADSI flag: ADS_UF_LOCKOUT"],
    [0x20, 0, "NoPasswordRequired", "No password is required", "No password is required.\r\nADSI flag: ADS_UF_PASSWD_NOTREQD"],
    [0x40, 0, "DisallowChangePassword", "User cannot change password", "The user cannot change the password. This flag can be read, but not set directly.\r\nADSI flag: ADS_UF_PASSWD_CANT_CHANGE"],
    [0x80, 0, "ReversibleEncryptionPassword", "Store password using reversible encryption", "The user can send an encrypted password.\r\nADSI flag: ADS_UF_ENCRYPTED_TEXT_PASSWORD_ALLOWED"],
    [0x100, 0, "TempDuplicateAccount", "Temporary duplicated account", "This is an account for users whose primary account is in another domain. This account provides user access to this domain, but not to any domain that trusts this domain. Also known as a local user account.\r\nADSI flag: ADS_UF_TEMP_DUPLICATE_ACCOUNT"],
    [0x200, 0, "NormalAccount", "Normal account", "This is a default account type that represents a typical user.\r\nADSI flag: ADS_UF_NORMAL_ACCOUNT"],
    [0x800, 0, "InterdomainTrustAccount", "Interdomain trust account", "This is a permit to trust account for a system domain that trusts other domains.\r\nADSI flag: ADS_UF_INTERDOMAIN_TRUST_ACCOUNT"],
    [0x1000, 0, "WorkstationTrustAccount", "Workstation trust account", "This is a computer account for a Microsoft Windows NT Workstation/Windows 2000 Professional or Windows NT Server/Windows 2000 Server that is a member of this domain.\r\nADSI flag: ADS_UF_WORKSTATION_TRUST_ACCOUNT"],
    [0x2000, 0, "ServerTrustAccount", "Server trust account", "This is a computer account for a system backup domain controller that is a member of this domain.\r\nADSI flag: ADS_UF_SERVER_TRUST_ACCOUNT"],
    [0x10000, 0, "NoPasswordExpiration", "Password never expires", "The password for this account will never expire.\r\nADSI flag: ADS_UF_DONT_EXPIRE_PASSWD"],
    [0x20000, 0, "MSNLogonAccount", "MSN logon account", "This is an MNS logon account.\r\nADSI flag: ADS_UF_MNS_LOGON_ACCOUNT"],
    [0x40000, 0, "SmartcardRequired", "Smart card is required for interactive logon", "The user must log on using a smart card.\r\nADSI flag: ADS_UF_SMARTCARD_REQUIRED"],
    [0x80000, 0, "TrustedForDelegation", "Account is trusted for delegation", "The service account (user or computer account), under which a service runs, is trusted for Kerberos delegation. Any such service can impersonate a client requesting the service.\r\nADSI flag: ADS_UF_TRUSTED_FOR_DELEGATION"],
    [0x100000, 0, "NotDelegated", "Account is sensitive and cannot be delegated", "The security context of the user will not be delegated to a service even if the service account is set as trusted for Kerberos delegation.\r\nADSI flag: ADS_UF_NOT_DELEGATED"],
    [0x200000, 0, "DESKeyOnly", "Use DES encryption types for this account", "Restrict this principal to use only Data Encryption Standard (DES) encryption types for keys.\r\nADSI flag: ADS_UF_USE_DES_KEY_ONLY"],
    [0x400000, 0, "NoPreauthRequired", "Do not require Kerberos preauthentication", "This account does not require Kerberos preauthentication for logon.\r\nADSI flag: ADS_UF_DONT_REQUIRE_PREAUTH"],
    [0x800000, 0, "PasswordExpired", "Password has expired", "The user password has expired. This flag is created by the system using data from the password last set attribute and the domain policy. It is read-only and cannot be set.\r\nADSI flag: ADS_UF_PASSWORD_EXPIRED"],
    [0x1000000, 0, "TrustedToAuthForDelegation", "Account is trusted to authenticate for delegation", "The account is enabled for delegation. This is a security-sensitive setting; accounts with this option enabled should be strictly controlled. This setting enables a service running under the account to assume a client identity and authenticate as that user to other remote servers on the network.\r\nADSI flag: ADS_UF_TRUSTED_TO_AUTHENTICATE_FOR_DELEGATION"],
    [0x2000000, 0, "NoAuthDataRequired", "PAC must not be included in a Kerberos ticket", "This bit indicates that when the KDC is issuing a service ticket for this account, the PAC MUST NOT be included. For more information, see RFC4120."],
    [0x4000000, 0, "PartialSecretsAccount", "Account is a computer account for an RODC", "Specifies that the account is a computer account for an RODC. If this bit is set, the WorkstationTrustAccount must also be set. (Windows Server 2008 and later)."]
];
