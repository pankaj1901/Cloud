/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

//
// Control Processors Manager 
//

Softerra.Class.ControlProcessorsMgr = (function () {

    // private:
    var _Processors = new ControlProcessorsImpl();

    //
    // Control Processors bindings
    //
    var JSControlProcessors = {
        'sessions': _Processors.SessionsProcessor,
        'environment': _Processors.EnvironmentProcessor,
        'remoteControl': _Processors.RemoteControlProcessor,
        'terminalServicesProfile': _Processors.TerminalServicesProfileProcessor
    };

    var _SessionsProcessor;
    var _EnvironmentProcessor;
    var _RemoteControlProcessor;
    var _TerminalServicesProfileProcessor;

    function ControlProcessorsImpl() {
        return {
            SessionsProcessor: _SessionsProcessor || (_SessionsProcessor = new ControlSessionsProcessorImpl()),
            EnvironmentProcessor: _EnvironmentProcessor || (_EnvironmentProcessor = new ControlEnvironmentProcessorImpl()),
            RemoteControlProcessor: _RemoteControlProcessor || (_RemoteControlProcessor = new ControlRemoteControlProcessorImpl()),
            TerminalServicesProfileProcessor: _TerminalServicesProfileProcessor ||
                (_TerminalServicesProfileProcessor = new ControlTerminalServicesProfileProcessorImpl())
        }
    }

    //public:
    return {
        GetProcessor: function (controlName) {
            return JSControlProcessors[controlName];
        }
    };
})();

//////////////////////////////////////////////////////////////////////////
// Processor implementations

//
// Base processor (abstract)
//

function ControlBaseProcessorImpl() {
    this.Name = "ControlBaseProcessor";

    //////////////////////////////////////////////////////////////////////////
    // base public methods

    this.Init = function (elem) {
        return false;
    }

    this.GenViewMode = function (elem) {
        // not impl
    }

    this.GenEditMode = function (elem) {
        // not impl
    }

    this.HasEditMode = function () {
        // not impl
    }

    this.GetModifiedValues = function (elem) {
        // not impl
    }

    this.TurnMode = function (elem, requiredMode) {
        // not impl
    }

    this.ReinitViewMode = function (elem) {
        // not impl
    }

    this.ReinitEditMode = function (elem) {
        // not impl
    }
}

//
// TerminalServicesBaseProcessor
//

function TerminalServicesBaseProcessorImpl() {
    ControlBaseProcessorImpl.call(this);
    this.Name = "TerminalServicesBaseProcessor";

    //////////////////////////////////////////////////////////////////////////
    // public methods

    // returns true if succeed
    this.Init = function (elem) {
        // expecting input.userParametersAttr
        var userParamsElem = elem.find('input.userParametersAttr[type=hidden]').first();
        if (!userParamsElem) { return; }

        var userParamsAttr;
        try {
            userParamsAttr = $.parseJSON(userParamsElem.attr("value"));
        }
        catch (e) { }

        if (userParamsAttr && userParamsAttr.uType == 'userParameters') {
            if (userParamsAttr.uDispEditVals2) {
                if (userParamsAttr.uDispEditVals2.length != 1) { return; }
                userParamsAttr.uValsIndexes = [0];
            }
            else {
                userParamsAttr.uDispEditVals2 = [{ uFields: {}}];
                userParamsAttr.uValsIndexes = [-1];
            }

            // set default values if don't exist
            var fields = userParamsAttr.uDispEditVals2[0].uFields;
            this._InitFields(fields);

            // save initialized object as a widget's option
            elem.control('option', 'userParamsAttr', userParamsAttr);
            return true;
        }
        else {
            return;
        }
    }

    // Terminal Services controls don't have EditMode
    this.HasEditMode = function () {
        return false;
    }

    this.TurnMode = function (elem, requiredMode) {
        if (requiredMode == 'ViewMode') {
            if (!elem.control('optionExists', 'ViewModeContent')) {
                this.GenViewMode(elem);
            }
            this.ReinitViewMode(elem);

            if (this.inlineAttributeEditTR) {
                this.inlineAttributeEditTR.removeClass('attributeEditSelection');
                this.inlineAttributeEditTR = null;
            }
        }
        else {
            if (!uiManager.IsGlobalEditTurnedOn()) {
                var _parent = elem.parent();
                this.inlineAttributeEditTR = _parent.parents('tr');
                this.inlineAttributeEditTR.addClass('attributeEditSelection');    
            }
        }
    }

    // generates ViewMode common structure. Method _GenViewModeImpl is overriden.
    this.GenViewMode = function (elem) {
        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;
        var viewModeContent = new StringBuilder();

        viewModeContent.append(this._GenViewModeImpl(elem, fields));

        var viewMode = $('<div></div>');
        elem.control('option', 'Content').append(viewMode);
        elem.control('option', 'ViewModeContent', viewMode);
        viewMode.html(viewModeContent.toString());

        customCheckCreate(viewMode);
        customRadioCreate(viewMode);
    }

    // performs common GetModifiedValues actions. Method _GetModifiedValuesImpl is overriden.
    this.GetModifiedValues = function (elem) {
        var ctrlElements = this._GetCtrlElements(elem);
        if (!ctrlElements) { return; }

        // userParameters attribute
        var encFlag = Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NONE | Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NEEDDISPVALUE;
        var userParamsAttr = elem.control('option', 'userParamsAttr');
        var modifObj = { uValsIndexes: userParamsAttr.uValsIndexes, uValues: [], uEncFlags: encFlag, uType: userParamsAttr.uType };
        var modifVal = cloneObj(elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields);

        this._GetModifiedValuesImpl(elem, ctrlElements, modifVal);

        var modifications = [];
        modifObj.uValues.push($.toJSON(modifVal));
        modifications.push(modifObj);
        return modifications;
    }
    
    //////////////////////////////////////////////////////////////////////////
    // protected methods

    this._GetModifiedValuesImpl = function (elem, ctrlElements, modifVal) { 
        // not impl
    }

    this._GenViewModeImpl = function (elem, fields) {
        // not impl
        return '';
    }

    this._InitFields = function (fields) {
        // not impl
    }

    // retrieves control elements. Calls overriden method _FindCtrlElements
    this._GetCtrlElements = function (elem) {
        if (elem.control('optionExists', 'ctrlElements')) {
            return elem.control('option', 'ctrlElements');
        }
        else {
            return this._FindCtrlElements(elem);
        }
    }

    this._FindCtrlElements = function (elem) {
        // not impl
    }

    // returns true if switching to EditMode is allowed.
    this.CheckAndCancelInlineModifies = function (elem) {
        if (uiManager.IsProfileReadonly()) { return false; }
        if (elem.control('option', 'currentMode') == 'EditMode') { return true; }
        if (!uiManager.IsInlineModifyTurnedOn()) { return true; }

        if (confirm(S_CONTROLCLICK_DATA_LOST)) {
            uiManager.CancelAllInlineModifies();
            return true;
        }
        else {
            return false;
        }
    }
}

//
// ControlSessionsProcessor
//

function ControlSessionsProcessorImpl() {
    TerminalServicesBaseProcessorImpl.call(this);
    this.Name = "ControlSessionsProcessor";

    //////////////////////////////////////////////////////////////////////////
    // public methods

    this._GenViewModeImpl = function (elem, fields) {
        var viewModeContent = new StringBuilder();

        viewModeContent.append('<table class="sessCtrlContent terminalServices">');
        // field 1: end a disconnected session
        viewModeContent.append(_genEndDisconnSessTR.call(this, elem, fields));
        // field 2: active session limit
        viewModeContent.append(_genActiveSessLimitTR.call(this, elem, fields));
        // field 3: idle session limit
        viewModeContent.append(_genIdleSessLimitTR.call(this, elem, fields));
        // field 4: session limit reached
        viewModeContent.append(_genSessLimitReachedTR.call(this, elem, fields));
        // field 5: allow reconnection
        viewModeContent.append(_genAllowReconnTR.call(this, elem, fields));
        viewModeContent.append('</table>');

        elem.control('option', 'ViewModeEventHandler').addHandler('clickableText', 'click',
                { func: clickableTextClick }
        );

        return viewModeContent.toString();
    }

    this.ReinitViewMode = function (elem) {
        var sessCtrlElements = this._GetCtrlElements(elem);
        if (!sessCtrlElements) { return; }

        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;
        sessCtrlElements.endDisconnSessComboBox.val(fields.uMaxDisconnectionTime);
        customSelectSync(sessCtrlElements.endDisconnSessComboBox);
        sessCtrlElements.activeSessLimitComboBox.val(fields.uMaxConnectionTime);
        customSelectSync(sessCtrlElements.activeSessLimitComboBox);
        sessCtrlElements.idleSessLimitComboBox.val(fields.uMaxIdleTime);
        customSelectSync(sessCtrlElements.idleSessLimitComboBox);

        sessCtrlElements.limitReachedForm.attr('currValue', fields.uBrokenConnectionAction);
        sessCtrlElements.limitReachedForm.find('input').removeAttr('checked');
        sessCtrlElements.limitReachedForm.find('input[value=' + fields.uBrokenConnectionAction + ']').attr('checked', 'checked');
        customRadioSync(sessCtrlElements.limitReachedForm.find('input'));

        sessCtrlElements.allowReconnForm.attr('currValue', fields.uReconnectionAction);
        sessCtrlElements.allowReconnForm.find('input').removeAttr('checked');
        sessCtrlElements.allowReconnForm.find('input[value=' + fields.uReconnectionAction + ']').attr('checked', 'checked');
        customRadioSync(sessCtrlElements.allowReconnForm.find('input'));

        elem.control('setDirty', false);

        // get focus out of the control
        if (document.hasFocus()) {
            $('body').focus();
        }
    }
    
    //////////////////////////////////////////////////////////////////////////
    // protected methods

    this.generateComboBox = function (opts) {
        if (!opts || !opts.optionsSet) { return ''; }

        var valueIndex = 0;
        var labelIndex = 1;

        var result = new StringBuilder();
        opts.attrs = opts.attrs || '';

        result.append('<span class="themedSelect"><span class="themedSelectText"></span><span class="themedSelectArrow"></span>');
        result.append('<select ' + opts.attrs + '>');
        for (var i = 0; i < opts.optionsSet.length; ++i) {
            result.append('<option value="' + opts.optionsSet[i][valueIndex] + '">' + opts.optionsSet[i][labelIndex] + '</option>')
        }
        result.append('</select></span>');
        return result.toString();
    }

    this._GetModifiedValuesImpl = function (elem, ctrlElements, modifVal) {
        if (ctrlElements.endDisconnSessComboBox.val() != modifVal.uMaxDisconnectionTime) {
            modifVal.uMaxDisconnectionTime = ctrlElements.endDisconnSessComboBox.val();
        }
        if (ctrlElements.activeSessLimitComboBox.val() != modifVal.uMaxConnectionTime) {
            modifVal.uMaxConnectionTime = ctrlElements.activeSessLimitComboBox.val();
        }
        if (ctrlElements.idleSessLimitComboBox.val() != modifVal.uMaxIdleTime) {
            modifVal.uMaxIdleTime = ctrlElements.idleSessLimitComboBox.val();
        }
        if (ctrlElements.limitReachedForm.attr('currValue') != modifVal.uBrokenConnectionAction) {
            modifVal.uBrokenConnectionAction = ctrlElements.limitReachedForm.attr('currValue');
        }
        if (ctrlElements.allowReconnForm.attr('currValue') != modifVal.uReconnectionAction) {
            modifVal.uReconnectionAction = ctrlElements.allowReconnForm.attr('currValue');
        }
    }

    this._InitFields = function (fields) {
        fields.uMaxDisconnectionTime = fields.uMaxDisconnectionTime || 0;
        fields.uMaxConnectionTime = fields.uMaxConnectionTime || 0;
        fields.uMaxIdleTime = fields.uMaxIdleTime || 0;
        fields.uReconnectionAction = fields.uReconnectionAction || 0;
        fields.uBrokenConnectionAction = fields.uBrokenConnectionAction || 0;
    }

    this._FindCtrlElements = function (elem) {
        var sessCtrlElements = {};
        sessCtrlElements.endDisconnSessComboBox = elem.find('.comboEndDisconnectedSession').first();
        sessCtrlElements.activeSessLimitComboBox = elem.find('.comboActiveSessLimit').first();
        sessCtrlElements.idleSessLimitComboBox = elem.find('.comboIdleSessLimit').first();
        sessCtrlElements.limitReachedForm = elem.find('.sessCtrlLimitReachedForm').first();
        sessCtrlElements.allowReconnForm = elem.find('.sessCtrlAllowReconnForm').first();
        elem.control('option', 'ctrlElements', sessCtrlElements);
        return sessCtrlElements;
    }

    function _genEndDisconnSessTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="sessCtrlLabelTD description">');
        res.append('<span>' + S_END_DISCONN_SESS + '</span>');
        res.append('</td><td class="sessCtrlValueTD">');
        var combo = this.generateComboBox({
            optionsSet: S_SESS_LIMIT_COMBO,
            attrs: ' class="combobox comboEndDisconnectedSession"'
        });

        elem.control('option', 'ViewModeEventHandler').addHandler('comboEndDisconnectedSession', 'change',
            { func: selectChange }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('comboEndDisconnectedSession', 'keydown',
            { func: selectChangeDelayed }
        );
        // we can't bind blur event to widget
        PostponedBindsManager.AddBindByClass('comboEndDisconnectedSession',
            { eventType: 'blur', func: selectChange }
        );
        // we can't bind focus event to widget
        PostponedBindsManager.AddBindByClass('comboEndDisconnectedSession',
            { eventType: 'focus', func: selectChange }
        );

        res.append(combo);
        res.append('</td></tr>');
        return res.toString();
    }
    function _genActiveSessLimitTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="sessCtrlLabelTD  description">');
        res.append('<span>' + S_ACTIVE_SESS_LIMIT + '</span>');
        res.append('</td><td class="sessCtrlValueTD">');
        var combo = this.generateComboBox({
            optionsSet: S_SESS_LIMIT_COMBO,
            attrs: ' class="combobox comboActiveSessLimit"'
        });

        elem.control('option', 'ViewModeEventHandler').addHandler('comboActiveSessLimit', 'change',
            { func: selectChange }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('comboActiveSessLimit', 'keydown',
            { func: selectChangeDelayed }
        );
        // we can't bind blur event to widget
        PostponedBindsManager.AddBindByClass('comboActiveSessLimit',
            { eventType: 'blur', func: selectChange }
        );
        // we can't bind focus event to widget
        PostponedBindsManager.AddBindByClass('comboActiveSessLimit',
            { eventType: 'focus', func: selectChange }
        );

        res.append(combo);
        res.append('</td></tr>');
        return res.toString();
    }
    function _genIdleSessLimitTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="sessCtrlLabelTD  description">');
        res.append('<span>' + S_IDLE_SESS_LIMIT + '</span>');
        res.append('</td><td class="sessCtrlValueTD">');
        var combo = this.generateComboBox({
            optionsSet: S_SESS_LIMIT_COMBO,
            attrs: ' class="combobox comboIdleSessLimit"'
        });

        elem.control('option', 'ViewModeEventHandler').addHandler('comboIdleSessLimit', 'change',
            { func: selectChange }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('comboIdleSessLimit', 'keydown',
            { func: selectChangeDelayed }
        );
        // we can't bind blur event to widget
        PostponedBindsManager.AddBindByClass('comboIdleSessLimit',
            { eventType: 'blur', func: selectChange }
        );
        // we can't bind focus event to widget
        PostponedBindsManager.AddBindByClass('comboIdleSessLimit',
            { eventType: 'focus', func: selectChange }
        );

        res.append(combo);
        res.append('</td></tr>');
        return res.toString();
    }
    function _genSessLimitReachedTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="sessCtrlLabelTD  description">');
        res.append('<span>' + S_SESS_LIMIT_REACHED + '</span>');
        res.append('</td><td class="sessCtrlValueTD">');
        res.append('<form class="sessCtrlLimitReachedForm" currValue="' + fields.uBrokenConnectionAction + '">');
        for (var i = 0; i < S_SESS_LIMIT_REACHED_GROUP.length; ++i) {
            res.append('<input class="sessCtrlLimitReached" name="sessLimitReachedGroup" type="radio" value="' + S_SESS_LIMIT_REACHED_GROUP[i][0] + '" tabIndex="0" />');
            res.append('<span class="clickableText" clickElemName="sessCtrlLimitReached' + i + '">' + S_SESS_LIMIT_REACHED_GROUP[i][1] + '</span>');
            if (i != S_SESS_LIMIT_REACHED_GROUP.length - 1) { res.append('<br>'); }
            elem.control('option', 'ViewModeEventHandler').addHandler('sessCtrlLimitReached', 'change',
                { func: radioButtonClick }
            );
        }
        res.append('</form>');
        res.append('</td></tr>');
        return res.toString();
    }
    function _genAllowReconnTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr class="trNoBottomPadding"><td class="sessCtrlLabelTD  description">');
        res.append('<span>' + S_ALLOW_RECONN + '</span>');
        res.append('</td><td class="sessCtrlValueTD">');
        res.append('<form class="sessCtrlAllowReconnForm" currValue="' + fields.uReconnectionAction + '">');
        for (var i = 0; i < S_ALLOW_RECONN_GROUP.length; ++i) {
            res.append('<input class="sessCtrlAllowReconnGroup" name="sessAllowReconnGroup" type="radio" value="' + S_ALLOW_RECONN_GROUP[i][0] + '" tabIndex="0" />');
            res.append('<span class="clickableText" clickElemName="sessCtrlAllowReconnGroup' + i + '">' + S_ALLOW_RECONN_GROUP[i][1] + '</span>');
            if (i != S_ALLOW_RECONN_GROUP.length - 1) { res.append('<br>'); }
            elem.control('option', 'ViewModeEventHandler').addHandler('sessCtrlAllowReconnGroup', 'change',
                { func: radioButtonClick }
            );
        }
        res.append('</form>');
        res.append('</td></tr>');
        return res.toString();
    }

    //////////////////////////////////////////////////////////////////////////
    // event handlers

    function clickableTextClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        var ctrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
        if (!ctrlElements) { return; }

        var targElement;
        switch ($(e.target).attr('clickElemName')) {
            case 'sessCtrlLimitReached0':
                targElement = ctrlElements.limitReachedForm.find('input').first();
                break;
            case 'sessCtrlLimitReached1':
                targElement = ctrlElements.limitReachedForm.find('input').last();
                break;
            case 'sessCtrlAllowReconnGroup0':
                targElement = ctrlElements.allowReconnForm.find('input').first();
                break;
            case 'sessCtrlAllowReconnGroup1':
                targElement = ctrlElements.allowReconnForm.find('input').last();
                break;
            default:
        }

        if (!targElement) { return; }

        // if attr 'checked' state changed after clicking on it trigger 'change'
        if (targElement.attr('checked') != targElement.click().attr('checked')) {
            targElement.change();
        }
    }

    function radioButtonClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }

        var targ = $(e.target);
        var form = targ.parent().parent();
        if (targ.val() == form.attr('currValue')) {
            return;
        }
        else {
            form.attr('currValue', targ.val());

            if (elem.control('option', 'currentMode') == 'ViewMode') {
                if (uiManager.IsInlineModifyTurnedOn()) {
                    e.preventDefault();
                    return false;
                }
                elem.control('turnMode', 'EditMode');
            }
            
            elem.control('setDirty', true);
        }
    }

    function selectChange(e) {
        if (customSelectSync($(e.target))) { setDirty(e); }
    }

    function selectChangeDelayed(e) {
        TimersHolder.addFunction(function () {
             if (customSelectSync($(e.target))) { setDirty(e); }
        });
    }

    function setDirty(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }
        if (elem.control('option', 'currentMode') == 'ViewMode') {
            if (uiManager.IsInlineModifyTurnedOn()) {
                e.preventDefault();
                return false;
            }
            elem.control('turnMode', 'EditMode');
        }
        elem.control('setDirty', true);
    }
}

//
// ControlEnvironmentProcessor
//

function ControlEnvironmentProcessorImpl() {
    TerminalServicesBaseProcessorImpl.call(this);
    this.Name = "ControlEnvironmentProcessor";

    //////////////////////////////////////////////////////////////////////////
    // public methods

    this._GenViewModeImpl = function (elem, fields) {
        var viewModeContent = new StringBuilder();

        viewModeContent.append('<table class="environmentCtrlContent terminalServices">');
        // field 1: starting program
        viewModeContent.append(_genStartingProgramTR.call(this, elem, fields));
        // field 2: client devices
        viewModeContent.append(_genClientDevicesTR.call(this, elem, fields));
        viewModeContent.append('</table>');

        elem.control('option', 'ViewModeEventHandler').addHandler('clickableText', 'click',
                { func: clickableTextClick }
        );

        return viewModeContent.toString();
    }

    this.ReinitViewMode = function (elem) {
        var environmentCtrlElements = this._GetCtrlElements(elem);
        if (!environmentCtrlElements) { return; }

        // starting program
        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;
        environmentCtrlElements.programFileNameEdit.val(fields.uTerminalServicesInitialProgram);
        environmentCtrlElements.programStartInEdit.val(fields.uTerminalServicesWorkDirectory);

        if (fields.uStartProgramAtLogon == '0') {
            environmentCtrlElements.startFollofingProgramCheckBox.attr('checked', 'checked');
            disableElements([environmentCtrlElements.programFileNameEdit,
                environmentCtrlElements.programStartInEdit], false);
            // make visually enabled
            environmentCtrlElements.programFileNameEdit.removeClass('inputfieldDisabled');
            environmentCtrlElements.programStartInEdit.removeClass('inputfieldDisabled');
        }
        else {
            environmentCtrlElements.startFollofingProgramCheckBox.removeAttr('checked');
            disableElements([environmentCtrlElements.programFileNameEdit,
                environmentCtrlElements.programStartInEdit], true);
            // make visually disabled
            environmentCtrlElements.programFileNameEdit.addClass('inputfieldDisabled');
            environmentCtrlElements.programStartInEdit.addClass('inputfieldDisabled');
        }
        customCheckSync(environmentCtrlElements.startFollofingProgramCheckBox);

        // client devices
        environmentCtrlElements.connClientDrivesCheckBox.removeAttr('checked');
        if (fields.uConnectClientDrivesAtLogon == '1') {
            environmentCtrlElements.connClientDrivesCheckBox.attr('checked', 'checked');
        }
        customCheckSync(environmentCtrlElements.connClientDrivesCheckBox);

        environmentCtrlElements.connClientPrintersCheckBox.removeAttr('checked');
        if (fields.uConnectClientPrintersAtLogon == '1') {
            environmentCtrlElements.connClientPrintersCheckBox.attr('checked', 'checked');
        }
        customCheckSync(environmentCtrlElements.connClientPrintersCheckBox);

        environmentCtrlElements.defToMainPrinterCheckBox.removeAttr('checked');
        if (fields.uDefaultToMainPrinter == '1') {
            environmentCtrlElements.defToMainPrinterCheckBox.attr('checked', 'checked');
        }
        customCheckSync(environmentCtrlElements.defToMainPrinterCheckBox);

        elem.control('setDirty', false);
        // get focus out of the control
        if (document.hasFocus()) {
            $('body').focus();
        }
    }

    //////////////////////////////////////////////////////////////////////////
    // protected methods

    this._InitFields = function (fields) {
        fields.uStartProgramAtLogon = (typeof fields.uStartProgramAtLogon == 'undefined') ?
            1 : fields.uStartProgramAtLogon;
        fields.uTerminalServicesWorkDirectory = fields.uTerminalServicesWorkDirectory || '';
        fields.uTerminalServicesInitialProgram = fields.uTerminalServicesInitialProgram || '';
        fields.uConnectClientDrivesAtLogon = (typeof fields.uConnectClientDrivesAtLogon == 'undefined') ?
            1 : fields.uConnectClientDrivesAtLogon;
        fields.uConnectClientPrintersAtLogon = typeof fields.uConnectClientPrintersAtLogon == 'undefined' ?
            1 : fields.uConnectClientPrintersAtLogon;
        fields.uDefaultToMainPrinter = typeof fields.uDefaultToMainPrinter == 'undefined' ?
            1 : fields.uDefaultToMainPrinter;
    }

    this._GetModifiedValuesImpl = function (elem, ctrlElements, modifVal) {
        // starting program
        if (!!ctrlElements.startFollofingProgramCheckBox.attr('checked') != (modifVal.uStartProgramAtLogon == '0')) {
            modifVal.uStartProgramAtLogon = ctrlElements.startFollofingProgramCheckBox.attr('checked') ? '0' : '1';
        }
        if (ctrlElements.programFileNameEdit.val() != modifVal.uTerminalServicesInitialProgram) {
            modifVal.uTerminalServicesInitialProgram = ctrlElements.programFileNameEdit.val();
        }
        if (ctrlElements.programStartInEdit.val() != modifVal.uTerminalServicesWorkDirectory) {
            modifVal.uTerminalServicesWorkDirectory = ctrlElements.programStartInEdit.val();
        }

        // client devices
        if (!!ctrlElements.connClientDrivesCheckBox.attr('checked') != (modifVal.uConnectClientDrivesAtLogon == '1')) {
            modifVal.uConnectClientDrivesAtLogon = ctrlElements.connClientDrivesCheckBox.attr('checked') ? '1' : '0';
        }
        if (!!ctrlElements.connClientPrintersCheckBox.attr('checked') != (modifVal.uConnectClientPrintersAtLogon == '1')) {
            modifVal.uConnectClientPrintersAtLogon = ctrlElements.connClientPrintersCheckBox.attr('checked') ? '1' : '0';
        }
        if (!!ctrlElements.defToMainPrinterCheckBox.attr('checked') != (modifVal.uDefaultToMainPrinter == '1')) {
            modifVal.uDefaultToMainPrinter = ctrlElements.defToMainPrinterCheckBox.attr('checked') ? '1' : '0';
        }
    }

    this._FindCtrlElements = function (elem) {
        var environmentCtrlElements = {};

        environmentCtrlElements.startFollofingProgramCheckBox = elem.find('.startFollowingProgram').first();
        environmentCtrlElements.programFileNameEdit = elem.find('.programFileName').first();
        environmentCtrlElements.programStartInEdit = elem.find('.programStartIn').first();
        environmentCtrlElements.connClientDrivesCheckBox = elem.find('.connClientDrives').first();
        environmentCtrlElements.connClientPrintersCheckBox = elem.find('.connClientPrinters').first();
        environmentCtrlElements.defToMainPrinterCheckBox = elem.find('.defToMainPrinter').first();

        elem.control('option', 'ctrlElements', environmentCtrlElements);
        return environmentCtrlElements;
    }

    function _genStartingProgramTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr class="trBottomPadding20pt"><td class="envCtrlStartingProgramLabel  description">' + S_ENVIR_STARTINGPROGRAM + '</td>');
        res.append('<td>');
        res.append('<div class="startFollowingProgramDiv"><input type="checkbox" name="startFollowingProgram" class="startFollowingProgram checkbox" /><span class="clickableText" clickElemName="startFollowingProgram">' + S_ENVIR_START_PROGRAM_AT_LOGON + '</span></div>');
        res.append('<table class="innerTable">');
        res.append('<tr><td class="tdWithInputText"><span class="inputDescription">' + S_ENVIR_PROGRAM_FILE_NAME + '</span></td></tr>');
        res.append('<tr class="trBottomPadding6pt" ><td class="tdWithInputText"><span class="themedInput"><span class="themedInputText"></span><input type="text" class="programFileName environmentInputfield inputfield" /></span></td></tr>');
        res.append('<tr><td class="tdWithInputText"><span class="inputDescription">' + S_ENVIR_START_IN + '</span></td></tr>');
        res.append('<tr><td class="tdWithInputText"><span class="themedInput"><span class="themedInputText"></span><input type="text" class="programStartIn environmentInputfield inputfield" /></span></td></tr>');
        res.append('</table>');
        res.append('</td></tr>');

        elem.control('option', 'ViewModeEventHandler').addHandler('checkbox', 'change',
                { func: checkBoxClick }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('environmentInputfield', 'keyup',
                { func: setInputFieldDirty }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('environmentInputfield', 'paste',
                { func: setInputFieldDirty }
        );
        // we can't bind blur event to widget
        PostponedBindsManager.AddBindByClass('environmentInputfield',
            { eventType: 'blur', func: setInputFieldDirty }
        );

        return res.toString();
    }

    function _genClientDevicesTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="envCtrlStartingProgramLabel  description">' + S_ENVIR_CLIENT_DEVICES + '</td>');
        res.append('<td>');
        res.append('<input type="checkbox" name="connClientDrives" class="connClientDrives checkbox" /><span class="clickableText" clickElemName="connClientDrives">' + S_ENVIR_CONN_CLIENT_DRIVES + '</span>');
        res.append('<br>');
        res.append('<input type="checkbox" name="connClientPrinters" class="connClientPrinters checkbox" /><span class="clickableText" clickElemName="connClientPrinters">' + S_ENVIR_CONN_CLIENT_PRINTERS + '</span>');
        res.append('<br>');
        res.append('<input type="checkbox" name="defToMainPrinter" class="defToMainPrinter checkbox" /><span class="clickableText" clickElemName="defToMainPrinter">' + S_ENVIR_DEF_TO_MAIN_PRINTER + '</span>');
        res.append('<br>');
        res.append('</td></tr>');

        elem.control('option', 'ViewModeEventHandler').addHandler('checkbox', 'change',
                { func: checkBoxClick }
        );

        return res.toString();
    }
 
    //////////////////////////////////////////////////////////////////////////
    // event handlers

    function clickableTextClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        var ctrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
        if (!ctrlElements) { return; }

        switch ($(e.target).attr('clickElemName')) {
            case 'startFollowingProgram':
                ctrlElements.startFollofingProgramCheckBox.click().change();
                break;
            case 'connClientDrives':
                ctrlElements.connClientDrivesCheckBox.click().change();
                break;
            case 'connClientPrinters':
                ctrlElements.connClientPrintersCheckBox.click().change();
                break;
            case 'defToMainPrinter':
                ctrlElements.defToMainPrinterCheckBox.click().change();
                break;
            default:
        }
    }

    function checkBoxClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }

        if (elem.control('option', 'currentMode') == 'ViewMode') {
            elem.control('turnMode', 'EditMode');
        }
        elem.control('setDirty', true);

        var targ = $(e.target);
        if (targ.hasClass('startFollowingProgram')) {
            var environmentCtrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
            if (!environmentCtrlElements) { return; }
            if (targ.attr('checked')) {
                disableElements([environmentCtrlElements.programFileNameEdit,
                    environmentCtrlElements.programStartInEdit], false);
                environmentCtrlElements.programFileNameEdit.removeClass('inputfieldDisabled');
                environmentCtrlElements.programStartInEdit.removeClass('inputfieldDisabled');
            }
            else {
                disableElements([environmentCtrlElements.programFileNameEdit,
                    environmentCtrlElements.programStartInEdit], true);
                environmentCtrlElements.programFileNameEdit.addClass('inputfieldDisabled');
                environmentCtrlElements.programStartInEdit.addClass('inputfieldDisabled');
            }
        }
    }

    function setInputFieldDirty(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (elem.control('option', 'isDirty')) { return; }

        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;

        TimersHolder.addFunction(function () {
            if ($(e.target).hasClass('programFileName')) {
                if ($(e.target).val() == fields.uTerminalServicesInitialProgram) {
                    return;
                }
            }
            if ($(e.target).hasClass('programStartIn')) {
                if ($(e.target).val() == fields.uTerminalServicesWorkDirectory) {
                    return;
                }
            }

            if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
                elem.control('procMethod', 'ReinitViewMode', elem);
                return false;
            }

            if (elem.control('option', 'currentMode') == 'ViewMode') {
                elem.control('turnMode', 'EditMode');
            }
            elem.control('setDirty', true);
        });
    }
}

//
// ControlRemoteControlProcessor
//

function ControlRemoteControlProcessorImpl() {
    TerminalServicesBaseProcessorImpl.call(this);
    this.Name = "ControlRemoteControlProcessor";

    //////////////////////////////////////////////////////////////////////////
    // public methods

    this._GenViewModeImpl = function (elem, fields) {
        var viewModeContent = new StringBuilder();

        viewModeContent.append('<table class="remoteControlCtrlContent terminalServices">');
        viewModeContent.append(_genEnableControlTR.call(this, elem, fields));
        viewModeContent.append(_genReqPermissionTR.call(this, elem, fields));
        viewModeContent.append(_genControlLevelTR.call(this, elem, fields));
        viewModeContent.append('</table>');
                
        elem.control('option', 'ViewModeEventHandler').addHandler('checkbox', 'change',
                { func: checkboxClick }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('radiobutton', 'change',
                { func: radioButtonClick }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('clickableText', 'click',
                { func: clickableTextClick }
        );

        return viewModeContent.toString();
    }

    this.ReinitViewMode = function (elem) {
        var ctrlElements = this._GetCtrlElements(elem);
        if (!ctrlElements) { return; }

        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;

        // uEnableRemoteControl
        var val = parseInt(fields.uEnableRemoteControl);
        if (val != 0) {
            ctrlElements.enableControlCheckBox.attr('checked', 'checked');
            disableElements([ctrlElements.requirePermissionCheckBox, 
                ctrlElements.viewSessionRadioBtn, ctrlElements.interactSessionRadioBtn], false);
        }
        else {
            ctrlElements.enableControlCheckBox.removeAttr('checked');
            disableElements([ctrlElements.requirePermissionCheckBox,
                ctrlElements.viewSessionRadioBtn, ctrlElements.interactSessionRadioBtn], true);
        }
        customCheckSync(ctrlElements.enableControlCheckBox);

        if (val == 1 || val == 3) {
            ctrlElements.requirePermissionCheckBox.attr('checked', 'checked');
        }
        else {
            ctrlElements.requirePermissionCheckBox.removeAttr('checked');
        }
        customCheckSync(ctrlElements.requirePermissionCheckBox);

        if (val == 3 || val == 4) {
            ctrlElements.viewSessionRadioBtn.attr('checked', 'checked');
            ctrlElements.interactSessionRadioBtn.removeAttr('checked');
        }
        else if (val == 1 || val == 2) {
            ctrlElements.viewSessionRadioBtn.removeAttr('checked');
            ctrlElements.interactSessionRadioBtn.attr('checked', 'checked');
        }
        else {
            ctrlElements.viewSessionRadioBtn.removeAttr('checked');
            ctrlElements.interactSessionRadioBtn.removeAttr('checked');
        }
        customRadioSync(ctrlElements.viewSessionRadioBtn);
        customRadioSync(ctrlElements.interactSessionRadioBtn);

        elem.control('setDirty', false);
        // get focus out of the control
        if (document.hasFocus()) {
            $('body').focus();
        }
    }

    //////////////////////////////////////////////////////////////////////////
    // protected methods

    function _genEnableControlTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="description">' + S_REMCONTROL_ENABLECONTROL_DESCR + '</td><td>');
        res.append('<input type="checkbox" class="checkbox enableRemoteControl" name"enableRemoteControl" />' + '<span class="clickableText" clickElemName="enableRemoteControl">' + S_REMCONTROL_ENABLECONTROL + '</span>');
        res.append('</td></tr>');
        return res.toString()
    }
    function _genReqPermissionTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="description">' + S_REMCONTROL_REQPERMISSION_DESCR + '</td><td>');
        res.append('<input type="checkbox" class="checkbox reqUserPermission" name"reqUserPermission" />' + '<span class="clickableText" clickElemName="reqUserPermission">' + S_REMCONTROL_REQPERMISSION + '</span>');
        res.append('</td></tr>');
        return res.toString()
    }
    function _genControlLevelTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr class="trNoBottomPadding"><td class="description">' + S_REMCONTROL_CONTROLLEVEL_DESCR + '</td><td>');
        res.append('<form class="remoteControlLevelForm">');
        res.append('<input class="radiobutton viewSession" name="remoteControlLevelGroup" type="radio" tabIndex="0" />');
        res.append('<span class="clickableText" clickElemName="viewSession">' + S_REMCONTROL_VIEWSESSION + '</span>');
        res.append('<br>');
        res.append('<input class="radiobutton interactSession" name="remoteControlLevelGroup" type="radio" tabIndex="0" />');
        res.append('<span class="clickableText" clickElemName="interactSession">' + S_REMCONTROL_INTERACTSESSION + '</span>');
        res.append('</form>');
        res.append('</td></tr>');
        return res.toString()
    }

    this._InitFields = function (fields) {
        fields.uEnableRemoteControl = fields.uEnableRemoteControl || 1;
    }

    this._GetModifiedValuesImpl = function (elem, ctrlElements, modifVal) {
        var enableControl = ctrlElements.enableControlCheckBox.attr('checked');
        var reqPermission = ctrlElements.requirePermissionCheckBox.attr('checked');
        var viewSess = ctrlElements.viewSessionRadioBtn.attr('checked');
        var interactSess = ctrlElements.interactSessionRadioBtn.attr('checked');

        if (!enableControl) {
            modifVal.uEnableRemoteControl = '0';
        }
        else if (reqPermission && !viewSess && interactSess) {
            modifVal.uEnableRemoteControl = '1';
        }
        else if (!reqPermission && !viewSess && interactSess) {
            modifVal.uEnableRemoteControl = '2';
        }
        else if (reqPermission && viewSess && !interactSess) {
            modifVal.uEnableRemoteControl = '3';
        }
        else if (!reqPermission && viewSess && !interactSess) {
            modifVal.uEnableRemoteControl = '4';
        }
    }

    this._FindCtrlElements = function (elem) {
        var ctrlElements = {};

        ctrlElements.enableControlCheckBox = elem.find('.enableRemoteControl').first();
        ctrlElements.requirePermissionCheckBox = elem.find('.reqUserPermission').first();
        ctrlElements.viewSessionRadioBtn = elem.find('.viewSession').first();
        ctrlElements.interactSessionRadioBtn = elem.find('.interactSession').first();

        elem.control('option', 'ctrlElements', ctrlElements);
        return ctrlElements;
    }

    //////////////////////////////////////////////////////////////////////////
    // event handlers

    function clickableTextClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        var ctrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
        if (!ctrlElements) { return; }

        switch ($(e.target).attr('clickElemName')) {
            case 'enableRemoteControl':
                ctrlElements.enableControlCheckBox.click().change();
                break;
            case 'reqUserPermission':
                ctrlElements.requirePermissionCheckBox.click().change();
                break;
            case 'viewSession':
                if (ctrlElements.viewSessionRadioBtn.attr('checked') !=
                    ctrlElements.viewSessionRadioBtn.click().attr('checked')) {
                    ctrlElements.viewSessionRadioBtn.change();
                }
                break;
            case 'interactSession':
                if (ctrlElements.interactSessionRadioBtn.attr('checked') !=
                    ctrlElements.interactSessionRadioBtn.click().attr('checked')) {
                    ctrlElements.interactSessionRadioBtn.change();
                }
                break;
            default:
        }
    }

    function checkboxClick(e) {
        var elem = getCtrlElementByTarget(e.target);

        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }

        if (elem.control('option', 'currentMode') == 'ViewMode') {
            elem.control('turnMode', 'EditMode');
        }
        elem.control('setDirty', true);

        if ($(e.target).hasClass('enableRemoteControl')) {
            var ctrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
            if (!ctrlElements) { return; }

            if ($(e.target).attr('checked')) {
                disableElements([ctrlElements.requirePermissionCheckBox,
                    ctrlElements.viewSessionRadioBtn, ctrlElements.interactSessionRadioBtn], false);

                var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;
                if (fields.uEnableRemoteControl == '0' && 
                    !ctrlElements.viewSessionRadioBtn.attr('checked') &&
                    !ctrlElements.interactSessionRadioBtn.attr('checked')) {
                    ctrlElements.interactSessionRadioBtn.attr('checked', 'checked');
                    customRadioSync(ctrlElements.interactSessionRadioBtn);
                }
            }
            else {
                disableElements([ctrlElements.requirePermissionCheckBox,
                    ctrlElements.viewSessionRadioBtn, ctrlElements.interactSessionRadioBtn], true);
            }
        }
    }

    function radioButtonClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (elem.control('option', 'isDirty')) { return; }

        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }

        if (elem.control('option', 'currentMode') == 'ViewMode') {
            elem.control('turnMode', 'EditMode');
        }
        elem.control('setDirty', true);
    }
}

//
// ControlTerminalServicesProfileProcessor
//

function ControlTerminalServicesProfileProcessorImpl() {
    TerminalServicesBaseProcessorImpl.call(this);
    this.Name = "ControlTerminalServicesProfileProcessor";

    //////////////////////////////////////////////////////////////////////////
    // public methods

    this.ReinitViewMode = function (elem) {
        var ctrlElements = this._GetCtrlElements(elem);
        if (!ctrlElements) { return; }

        // starting program
        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;

        ctrlElements.profilePathEdit.val(fields.uTerminalServicesProfilePath);

        if (_isPathLocal(fields.uTerminalServicesHomeDirectory)) {
            var comboVal = fields.uTerminalServicesHomeDrive || '';
            ctrlElements.driveCombo.val(comboVal);
            customSelectSync(ctrlElements.driveCombo);

            ctrlElements.localPathRadioBtn.attr('checked', 'checked');
            customRadioSync(ctrlElements.localPathRadioBtn);
            ctrlElements.connectRadioBtn.removeAttr('checked');
            customRadioSync(ctrlElements.connectRadioBtn);
            ctrlElements.localPathEdit.val(fields.uTerminalServicesHomeDirectory);
            ctrlElements.netPathEdit.val('');
            disableElements([ctrlElements.localPathEdit], false);
            ctrlElements.localPathEdit.removeClass('inputfieldDisabled');
            disableElements([ctrlElements.driveCombo, ctrlElements.netPathEdit], true);
            ctrlElements.netPathEdit.addClass('inputfieldDisabled');
        }
        else {
            var comboVal = fields.uTerminalServicesHomeDrive || 'Z:';
            ctrlElements.driveCombo.val(comboVal);
            customSelectSync(ctrlElements.driveCombo);

            ctrlElements.connectRadioBtn.attr('checked', 'checked');
            customRadioSync(ctrlElements.connectRadioBtn);
            ctrlElements.localPathRadioBtn.removeAttr('checked');
            customRadioSync(ctrlElements.localPathRadioBtn);
            ctrlElements.localPathEdit.val('');
            ctrlElements.netPathEdit.val(fields.uTerminalServicesHomeDirectory);
            disableElements([ctrlElements.driveCombo, ctrlElements.netPathEdit], false);
            ctrlElements.netPathEdit.removeClass('inputfieldDisabled');
            disableElements([ctrlElements.localPathEdit], true);
            ctrlElements.localPathEdit.addClass('inputfieldDisabled');
        }

        if (fields.uAllowLogon == '1') {
            ctrlElements.allowLogonCheckBox.attr('checked', 'checked');
        }
        else {
            ctrlElements.allowLogonCheckBox.removeAttr('checked');
        }
        customCheckSync(ctrlElements.allowLogonCheckBox);

        if (fields.uParsingFailed == '1') {
            uiManager._parsingError = S_USERPARAMETERS_PARSING_FAILED;
            uiManager.VerifyUserParametersParsing();
        }

        elem.control('setDirty', false);
        if (document.hasFocus()) {
            $('body').focus();
        }
    }

    //////////////////////////////////////////////////////////////////////////
    // protected methods

    this._GenViewModeImpl = function (elem, fields) {
        var viewModeContent = new StringBuilder();

        viewModeContent.append('<table class="termServProfileCtrlContent terminalServices" cellspacing="0" cellpadding="0">');
        viewModeContent.append(_genProfilePathTR.call(this, elem, fields));
        viewModeContent.append(_genHomeFolderTR.call(this, elem, fields));
        viewModeContent.append('</table>');

        // bind event handlers

        // input text fields
        elem.control('option', 'ViewModeEventHandler').addHandler('inputfieldTermSProfile', 'keyup',
                { func: onInputFieldEvent }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('inputfieldTermSProfile', 'paste',
                { func: onInputFieldEvent }
        );
        PostponedBindsManager.AddBindByClass('inputfieldTermSProfile',
            { eventType: 'blur', func: onInputFieldEvent }
        );
        // group buttons
        elem.control('option', 'ViewModeEventHandler').addHandler('termSProfCtrlRadioBtn', 'change',
            { func: radioButtonClick }
        );
        // letter combo
        elem.control('option', 'ViewModeEventHandler').addHandler('letterCombo', 'change',
            { func: selectChange }
        );
        elem.control('option', 'ViewModeEventHandler').addHandler('letterCombo', 'keydown',
            { func: selectChangeDelayed }
        );
        // we can't bind blur event to widget
        PostponedBindsManager.AddBindByClass('letterCombo',
            { eventType: 'blur', func: selectChange }
        );
        // we can't bind focus event to widget
        PostponedBindsManager.AddBindByClass('letterCombo',
            { eventType: 'focus', func: selectChange }
        );
        // checkbox
        elem.control('option', 'ViewModeEventHandler').addHandler('allowLogon', 'change',
                { func: setDirty }
        );
        // clickable text
        elem.control('option', 'ViewModeEventHandler').addHandler('clickableText', 'click',
                { func: clickableTextClick }
        );

        return viewModeContent.toString();
    }

    this._InitFields = function (fields) {
        fields.uTerminalServicesProfilePath = fields.uTerminalServicesProfilePath || '';
        fields.uTerminalServicesHomeDirectory = fields.uTerminalServicesHomeDirectory || '';
        fields.uTerminalServicesHomeDrive = fields.uTerminalServicesHomeDrive || '';
        fields.uAllowLogon = fields.uAllowLogon || 1;
    }

    this._GetModifiedValuesImpl = function (elem, ctrlElements, modifVal) {
        // uTerminalServicesProfilePath
        modifVal.uTerminalServicesProfilePath = ctrlElements.profilePathEdit.val();

        // uTerminalServicesHomeDirectory, uTerminalServicesHomeDrive
        if (ctrlElements.localPathRadioBtn.attr('checked')) {
            modifVal.uTerminalServicesHomeDirectory = ctrlElements.localPathEdit.val();
            modifVal.uTerminalServicesHomeDrive = '';
        }
        else {
            modifVal.uTerminalServicesHomeDirectory = ctrlElements.netPathEdit.val();
            modifVal.uTerminalServicesHomeDrive = ctrlElements.driveCombo.val();
        }

        // uAllowLogon
        modifVal.uAllowLogon = ctrlElements.allowLogonCheckBox.attr('checked') ? '1' : '0';
    }

    this._FindCtrlElements = function (elem) {
        var ctrlElements = {};

        ctrlElements.profilePathEdit = elem.find('.profilePath').first();
        ctrlElements.localPathEdit = elem.find('.localDir').first();
        ctrlElements.netPathEdit = elem.find('.netDir').first();
        ctrlElements.localPathRadioBtn = elem.find('.termSProfCtrlLocalDir').first();
        ctrlElements.connectRadioBtn = elem.find('.termSProfCtrlNetDir').first();
        ctrlElements.driveCombo = elem.find('.letterCombo').first();
        ctrlElements.allowLogonCheckBox = elem.find('.allowLogon').first();

        elem.control('option', 'ctrlElements', ctrlElements);
        return ctrlElements;
    }

    function _isPathLocal(strPath) {
        if (strPath.length >= 2 && strPath.substring(0, 2) == '\\\\') { return false; }
        return true;
    }

    function _genProfilePathTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr><td class="description">');
        res.append(S_TERMSPROF_PROFILE_PATH);
        res.append('</td>');
        res.append('<td>');
        res.append('<table class="innerTable"><tr><td class="tdWithInputText">');
        res.append('<span class="themedInput"><span class="themedInputText"></span>');
        res.append('<input type="text" class="profilePath inputfieldTermSProfile inputfield" />');
        res.append('</span>');
        res.append('</td></tr></table>');
        res.append('</td></tr>');
        return res.toString();
    }
    function _genHomeFolderTR(elem, fields) {
        var res = new StringBuilder();
        res.append('<tr class = "trNoBottomPadding"><td class="description">' + S_TERMSPROF_HOME_FOLDER + '</td>');
        res.append('<td >');
        res.append('<form class="termSProfCtrlHomeDirForm">');
        res.append('<table class="innerTable"><tr class="trBottomPadding6pt">');

        // local
        res.append('<td><input class="termSProfCtrlLocalDir termSProfCtrlRadioBtn" name="termSProfDirTypeGroup" type="radio" tabIndex="0" />');
        res.append('<span class="clickableText" clickElemName="termSProfCtrlLocalDir">' + S_TERMSPROF_LOCAL_PATH + '&nbsp;&nbsp;&nbsp;</span></td>');
        res.append('<td colspan="2" class="tdWithInputText"><span class="themedInput"><span class="themedInputText"></span><input type="text" class="localDir inputfieldTermSProfile inputfield" /></span></td>');
        res.append('</tr><tr>');

        // net
        res.append('<td><input class="termSProfCtrlNetDir termSProfCtrlRadioBtn" name="termSProfDirTypeGroup" type="radio" tabIndex="0" />');
        res.append('<span class="clickableText" clickElemName="termSProfCtrlNetDir">' + S_TERMSPROF_CONNECT + '</span></td>');
        // combo box
        res.append('<td><span class="themedSelect"><span class="themedSelectText"></span><span class="themedSelectArrow"></span>');
        res.append('<select class="letterCombo">');

        res.append('<option value=""></option>')
        for (var i = 'C'.charCodeAt(0); i <= 'Z'.charCodeAt(0); ++i) {
            var currVal = String.fromCharCode(i) + ':';
            res.append('<option value="' + currVal + '">' + currVal + '</option>')
        }
        res.append('</select></span>');

        res.append('<span class="connectToSpan">&nbsp;&nbsp;' + S_TERMSPROF_TO + '&nbsp;</span></td>');
        res.append('<td class="tdWithInputText"><span class="themedInput"><span class="themedInputText"></span><input type="text" class="netDir inputfieldTermSProfile inputfield" /></span></td>');

        res.append('</tr></table>');
        res.append('</form>');

        // allow logon
        res.append('<div class="divHeight8pt"></div>');
        res.append('<input type="checkbox" name="allowLogonCheckbox" class="checkbox allowLogon" />');
        res.append('<span class="clickableText" clickElemName="allowLogonCheckbox">' +'&nbsp;' + S_TERMSPROF_ALLOW_LOGON + '</span>');
        res.append('</td></tr>');

        return res.toString();
    }

    //////////////////////////////////////////////////////////////////////////
    // event handlers

    function clickableTextClick(e) {
        var elem = getCtrlElementByTarget(e.target);
        var ctrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
        if (!ctrlElements) { return; }

        switch ($(e.target).attr('clickElemName')) {
            case 'termSProfCtrlLocalDir':
                if (ctrlElements.localPathRadioBtn.attr('checked') !=
                    ctrlElements.localPathRadioBtn.click().attr('checked')) {
                    ctrlElements.localPathRadioBtn.change();
                }                
                break;
            case 'termSProfCtrlNetDir':
                if (ctrlElements.connectRadioBtn.attr('checked') !=
                    ctrlElements.connectRadioBtn.click().attr('checked')) {
                    ctrlElements.connectRadioBtn.change();
                }                
                break;
            case 'allowLogonCheckbox':
                ctrlElements.allowLogonCheckBox.click().change();
                break;
            default:
        }
    }

    function onInputFieldEvent(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (elem.control('option', 'isDirty')) { return; }

        var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;

        TimersHolder.addFunction(function () {
            if ($(e.target).hasClass('profilePath')) {
                if ($(e.target).val() == fields.uTerminalServicesProfilePath) {
                    return;
                }
            }
            else if ($(e.target).hasClass('localDir') || $(e.target).hasClass('netDir')) {
                if ($(e.target).val() == fields.uTerminalServicesHomeDirectory) {
                    return;
                }
            }

            if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
                elem.control('procMethod', 'ReinitViewMode', elem);
                return false;
            }

            if (elem.control('option', 'currentMode') == 'ViewMode') {
                elem.control('turnMode', 'EditMode');
            }
            elem.control('setDirty', true);
        });
    }

    function radioButtonClick(e) {
        var elem = getCtrlElementByTarget(e.target);

        // disable or enable components
        var ctrlElements = elem.control('procMethod', '_GetCtrlElements', elem);
        if (!ctrlElements) { return; }
        if (ctrlElements.localPathRadioBtn.attr('checked')) {
            disableElements([ctrlElements.driveCombo, ctrlElements.netPathEdit], true);
            ctrlElements.netPathEdit.addClass('inputfieldDisabled');
            disableElements([ctrlElements.localPathEdit], false);
            ctrlElements.localPathEdit.removeClass('inputfieldDisabled');
        }
        else {
            disableElements([ctrlElements.localPathEdit], true);
            ctrlElements.localPathEdit.addClass('inputfieldDisabled');
            disableElements([ctrlElements.driveCombo, ctrlElements.netPathEdit], false);
            ctrlElements.netPathEdit.removeClass('inputfieldDisabled');
            var fields = elem.control('option', 'userParamsAttr').uDispEditVals2[0].uFields;
            var comboVal = ctrlElements.driveCombo.val() || 'Z:';
            ctrlElements.driveCombo.val(comboVal);
            customSelectSync(ctrlElements.driveCombo);
        }

        if (elem.control('option', 'isDirty')) { return; }

        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }

        if (elem.control('option', 'currentMode') == 'ViewMode') {
            elem.control('turnMode', 'EditMode');
        }
        elem.control('setDirty', true);
    }

    function selectChange(e) {
        if (customSelectSync($(e.target))) { setDirty(e); }
    }

    function selectChangeDelayed(e) {
        TimersHolder.addFunction(function () {
             if (customSelectSync($(e.target))) { setDirty(e); }
        });
    }

    function setDirty(e) {
        var elem = getCtrlElementByTarget(e.target);
        if (elem.control('option', 'isDirty')) { return; }

        if (!elem.control('procMethod', 'CheckAndCancelInlineModifies', elem)) {
            elem.control('procMethod', 'ReinitViewMode', elem);
            return false;
        }

        if (elem.control('option', 'currentMode') == 'ViewMode') {
            elem.control('turnMode', 'EditMode');
        }
        elem.control('setDirty', true);
    }
}