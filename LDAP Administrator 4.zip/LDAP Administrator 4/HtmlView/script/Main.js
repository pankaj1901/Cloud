﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

var IMG_PATH = HTMLVIEW_PATH + 'images/';

//
// create Softerra namespace and it's nested namespaces
//
if (Softerra === undefined) {
    var Softerra = {};
}
if (Softerra.Const === undefined) {
    Softerra.Const = {};
}
if (Softerra.Var === undefined) {
    Softerra.Var = {};
}
if (Softerra.Func === undefined) {
    Softerra.Func = {};
}
if (Softerra.Class === undefined) {
    Softerra.Class = {};
}

var dpiScaleFactor = 1.0;

// class responsible for dynamic loading different content
Softerra.Class.ContentLoader = (function () {
    var _scriptPath = HTMLVIEW_PATH + 'script/';

    // list of scripts to be loaded
    var _scripts = [
    // Main libraries
    _scriptPath + 'Debug.js',
    _scriptPath + 'Lib.js',
    _scriptPath + 'Processors.js',
    _scriptPath + 'ControlProcessors.js',
    _scriptPath + 'UIManager.js',
    // jQuery
    _scriptPath + 'external/jQuery/jQueryLib.js',
    _scriptPath + 'external/jQuery/jquery.cookie.js',
    _scriptPath + 'external/jQuery/ui/jquery.ui.core.js',
    _scriptPath + 'external/jQuery/ui/jquery.ui.widget.js',
    _scriptPath + 'external/jQuery/ui/jquery.ui.tabs.js',
    // External Plugins    
    _scriptPath + 'external/Plugins/blockUI/jquery.blockUI.2.31.js',
    _scriptPath + 'external/Plugins/jquery.pagination/jquery.pagination.js',
    _scriptPath + 'external/Plugins/Json/jquery.json-2.2.min.js',
    // Resources
    _scriptPath + 'res/Countries.' + LANGUAGE + '.js',
    _scriptPath + 'res/FlagSetProcessorStrings.' + LANGUAGE + '.js',
    _scriptPath + 'res/TerminalServicesStrings.' + LANGUAGE + '.js',
    _scriptPath + 'res/Resources.js',
    _scriptPath + 'res/StringRes.' + LANGUAGE + '.js',
    // Custom widgets
    _scriptPath + 'ui/jquery.ui.allattrsinfo.js',
    _scriptPath + 'ui/jquery.ui.attrinfo.js',
    _scriptPath + 'ui/jquery.ui.control.js',
    _scriptPath + 'ui/jquery.ui.childnodes.js',
    _scriptPath + 'ui/jquery.ui.errorinfo.js',
    _scriptPath + 'ui/jquery.ui.fold.js',
    _scriptPath + 'ui/jquery.ui.groupmembership.js',
    _scriptPath + 'ui/jquery.ui.photo.js'
    ];

    if ($.browser.msie && $.browser.version == '6.0') {
        _scripts.push(_scriptPath + 'external/DD_belatedPNG_0.0.8a.js');
    }

    // list of stylesheets to be loaded
    var _styles = [
        HTMLVIEW_PATH + '/styles/styles.css',
        HTMLVIEW_PATH + '/script/external/Plugins/jquery.pagination/pagination.css',
        HTMLVIEW_PATH + '/styles/error.css',
        HTMLVIEW_PATH + '/styles/fold.css',
        HTMLVIEW_PATH + '/styles/getstarted.css',
        HTMLVIEW_PATH + '/styles/info.css',
        HTMLVIEW_PATH + '/styles/m2g.css',
        HTMLVIEW_PATH + '/styles/childnodes.css',
        HTMLVIEW_PATH + '/styles/shortinfo2.css',
        HTMLVIEW_PATH + '/styles/tabledata.css',
        HTMLVIEW_PATH + '/styles/tabs.css',
        HTMLVIEW_PATH + '/styles/logonhours.css',
        HTMLVIEW_PATH + '/styles/changephoto.css',
        HTMLVIEW_PATH + '/styles/terminalservices.css'
    ];

    var _scriptFilesProcessed = 0;

    function LoadCSS(path) {
        var _link = $('<link>');
        $("head").append(_link);
        _link.attr({
            rel: "stylesheet",
            type: "text/css",
            href: path
        });
    }

    function AppendStyleZoom(selName, value) {
            if (document.styleSheets.length < 1) { return; }
            var sheet = document.styleSheets[0];
            sheet.addRule(selName, "zoom: " + value);
    }

    function UpdateDPIScaleStyles() {
            var valueHalf = "50%";
            AppendStyleZoom(".dpiScaleHalf", valueHalf);
    }

    return {
        Load: function (funcAfterLoad) {
            // load stylesheets
            for (var i = 0; i < _styles.length; ++i) {
                LoadCSS(_styles[i]);
            }

            // calc DPI scale factor
            dpiScaleFactor = screen.deviceXDPI / 96;

            // update DPI scale styles
            if (dpiScaleFactor > 1.0) { 
                UpdateDPIScaleStyles();
            }

            // load scripts
            if (_scripts.length == 0) {
                funcAfterLoad();
            }
            else {
                for (var i = 0; i < _scripts.length; ++i) {
                    $.ajax({
                        url: _scripts[i],
                        dataType: 'script',
                        cache: true,
                        success: function (data) {
                            if (++_scriptFilesProcessed == _scripts.length) {
                                funcAfterLoad();
                            }
                        }
                    });
                }

                // check whether all files have been loaded (trick for IE because it doesn't return error if file doesn't exist)
                TimersHolder.addFunction(function () {
                    if (_scriptFilesProcessed == _scripts.length) {
                        return;
                    }

                    // trace filenames whose loading failed
                    $('script').each(function () {
                        if (this.readyState == 'loading') {
                            if (typeof trace == 'function') {
                                trace('error loading: ' + $(this).attr('src'));
                            }
                        }
                    });
                    if (_scriptFilesProcessed != _scripts.length) {
                        funcAfterLoad();
                    }
                }, null, 2000);
            }
        }
    }
})();

var mainFuncCalled = false;
$(window).load(function () {
    // initializing function
    var fInitAllAsync = function () {
        if (mainFuncCalled) {
            return;
        }

        mainFuncCalled = true;

        if (typeof uiManager == 'undefined') {
            uiManager = new Softerra.Class.EntryUIManager();
        }

        try {
            uiManager.InitAll();
        }
        catch (e) { }

        try {
            window.external.ContextNode.SyncOperation("NotifyPageLoadComplete", '', 0);
        }
        catch (e) { }
    }

    if (window.document.readyState != 'complete') {
        window.document.onreadystatechange = function () {
            if (window.document.readyState != 'complete') {
                return;
            }
            // load all scripts and stylesheets and call init function afterwards
            Softerra.Class.ContentLoader.Load(fInitAllAsync);
        }
        return;
    }

    // load all scripts and stylesheets and call init function afterwards
    Softerra.Class.ContentLoader.Load(fInitAllAsync);
});
