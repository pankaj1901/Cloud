/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

var BTN_IMG_PATH = IMG_PATH + 'misc/';

Softerra.Class.EntryUIManager = function () {
    //////////////////////////////////////////////////////////////////////////
    //private members:
    this._tabsCurrPanel = null; // currently selected tab's container

    this._m2gMembersWdgs = null;
    this._m2gGroupsWdgs = null;

    this._allAttrsInfoWdgs = null;
    this._attrInfoWdgs = null;
    this._controlsWdgs = null;

    this._changeablePhotoWdgs = null;

    this._globalSaveCancelButtons = null;

    this._globalEditTurnedOn = false;
    this._inlineModifyTurnedOn = false;
    this._CommonEditTurnedOn = false;

    this._tabbedInlineModifyTurnedOn = false;
    this._isProfileReadonly;

    this._allInited = false;

    this._viewName = null;
    try {
        this._viewName = escape(window.external.ContextNode.SyncOperation("GetViewName", "", 0));
    }
    catch (e) { this._viewName = 'default' }

    this._parsingError = null;

    this._lang = typeof CURRENT_LANG != 'undefined' ? CURRENT_LANG : 'eng';

    //private methods:
    function _initWidgets() {
        var self = this;

        if ($.fn.tabs) {
            $('#tabs')
                .bind('tabsselect', $.proxy(_onTabSelect, this))
                .bind('tabsshow', $.proxy(_onTabShow, this))
                .tabs({
                    cookie: {
                        expires: 30,
                        name: this._viewName
                    }
                });
        }

        if ($.fn.fold) {
            $('div.fold')
                .bind('foldshow', $.proxy(_onFoldShow, this))
                .fold({ viewName: this._viewName });
        };

        if ($.fn.groupmembership) {
            this._m2gMembersWdgs = $('#m2gMembers').groupmembership({
                objectsType: 'members'
            });

            this._m2gGroupsWdgs = $('#m2gGroups').groupmembership({
                objectsType: 'groups'
            });
        };

        if ($.fn.childnodes) {
            $('#childnodes').childnodes();
        };

        if ($.fn.photo) {
            // image elements
            $('.quickPhoto').photo();
            // input elements
            this._changeablePhotoWdgs = $('.changeablePhoto').photo();
        };

        if ($.fn.errorinfo) {
            $('input.ldapErrorInfo').errorinfo();
        }

        if ($.fn.allattrsinfo) {
            if (!this._allAttrsInfoWdgs) {
                this._allAttrsInfoWdgs = $('input.ldapAllAttrsInfo[type=hidden]').allattrsinfo();
            }
        }
    };

    // create URLs for hovered, clicked and default images for GlobalSwitchMode button for view and edit modes
    function _initSwitchModeBtnUrls(mode) {
        if (mode == 'ViewMode') {
            this.switchModeBtnUrl = 'url(' + IMG_PATH +
            ((this._lang == 'deu') ? IMG_VIEWBTN_DEU : IMG_VIEWBTN_ENG) + ')';
            this.switchModeBtnOverUrl = 'url(' + IMG_PATH +
            ((this._lang == 'deu') ? IMG_VIEWBTN_OVER_DEU : IMG_VIEWBTN_OVER_ENG) + ')';
            this.switchModeBtnClickedUrl = 'url(' + IMG_PATH +
            ((this._lang == 'deu') ? IMG_VIEWBTN_CLICKED_DEU : IMG_VIEWBTN_CLICKED_ENG) + ')';
        }
        else {
            this.switchModeBtnUrl = 'url(' + IMG_PATH +
            ((this._lang == 'deu') ? IMG_EDITBTN_DEU : IMG_EDITBTN_ENG) + ')';
            this.switchModeBtnOverUrl = 'url(' + IMG_PATH +
            ((this._lang == 'deu') ? IMG_EDITBTN_OVER_DEU : IMG_EDITBTN_OVER_ENG) + ')';
            this.switchModeBtnClickedUrl = 'url(' + IMG_PATH +
            ((this._lang == 'deu') ? IMG_EDITBTN_CLICKED_DEU : IMG_EDITBTN_CLICKED_ENG) + ')';
        }
    }

    function _initButtons() {
        var self = this;

        _initSwitchModeBtnUrls.call(this, 'EditMode');

        $('.globalSwitchModeBtn').each(function () {
            if (self.IsProfileReadonly()) {
                $(this).hide();
            }
            else {
                $(this)
                    .css('background-image', self.switchModeBtnUrl)
                    .removeClass('globalView_' + self._lang)
                    .addClass('globalEdit_' + self._lang)
                    .bind('mouseenter', function () {
                        $(this).css('background-image', self.switchModeBtnOverUrl);
                    })
                    .bind('mouseleave', function () {
                        $(this).css('background-image', self.switchModeBtnUrl);
                    })
                    .bind('mousedown', function () {
                        $(this).css('background-image', self.switchModeBtnClickedUrl);
                    })
                    .bind('mouseup', function () {
                        $(this).css('background-image', self.switchModeBtnUrl);
                    })
                    .click($.proxy(function () {
                        _onGlobalSwitchModeClick.call(this, true);
                        return false;
                    }, self));
            }
        });
    }
    
    function _getAccountState() {
        var res;
        res = window.external.ContextNode.SyncOperation("IsAccountDisabled", "", 0);
        
        if (res == 'unchangable')
        {
            return 'unchangable'
        }
        
        if (res == true)
        {
            return 'Disabled';
        }

        return 'Enabled';
    }
    
    function _ExecuteUserAccountCommand(command)
    {
        try
        {
            window.external.ContextNode.SyncOperation(command, "", 0);
        }
        catch(e)
        {
            return;
        }
            
        if (this.IsInlineModifyTurnedOn() || this.IsGlobalEditTurnedOn())
        {
            _InitUserAccountButtons.call(this);
        }
        else
        {
            window.external.ContextNode.SyncOperation("Refresh", "", 0);
        }
    }
    
    function _IsAccountLocked()
    {
        var res;
        res = window.external.ContextNode.SyncOperation("IsAccountLocked", "", 0);

        if (res == true)
        {
            return true;
        }
        
        return false;
    }
    
    function _InitUserAccountButton(button, btn_text, hide)
    {
        if (this.IsProfileReadonly() || hide) {
            button.hide();                              
        }
        else 
        {
            button.show();
            button.unbind();
            button.text(btn_text);
            button.bind('click', $.proxy(function () {
                    _ExecuteUserAccountCommand.call(this, button.val());
                    return false;
                }, this));
        }
    }
       
    function _InitUserAccountButtons()
    {
        var self = this;
        $('.UserAccountControlButtons').each(function() 
        {
            switch($(this).val()) 
            {
                case "UnlockAccount":
                    _InitUserAccountButton.call(self, $(this), S_UNLOCK_ACCOUNT, !_IsAccountLocked.call(self));
                    break;
                case "EnableAccount":
                    _InitUserAccountButton.call(self, $(this), S_ENABLE_ACCOUNT, (_getAccountState.call(self) != "Disabled"));      
                    break;
                case "DisableAccount":
                    _InitUserAccountButton.call(self, $(this), S_DISABLE_ACCOUNT, (_getAccountState.call(self) != 'Enabled'));     
                    break;
                case "ResetPassword":
                    _InitUserAccountButton.call(self, $(this), S_RESET_PASSWORD, false);            
                    break;
                default:
                    $(this).hide();
            }
        });

        $('.separators').remove();    

        // Insert buttons separators
        var nVisibleCount = 0;
        $('.UserAccountControlButtons').each(function() {
        if ($(this).is(":visible")) {
            nVisibleCount++;
        }
        });
        
        $('.UserAccountControlButtons').each(function() {
        if ($(this).is(":visible") && ((nVisibleCount - 1) > 0)) {
            $(this).addClass('ButtonSeparator');
            nVisibleCount--;
        }
        });
        
    }
    
    function _initViewEditButton(mode) {
        var self = this;
        
        $('.editbutton').each(function () { 
            if (self.IsProfileReadonly()) {
                $(this).hide();
            }
            else {
                $(this).show();
                $(this).unbind();
                $(this).css('width', self.Lang() == 'eng' ? '57pt' : '70.5pt');
                var btn_name = '<span>' + ((mode == 'EditMode') ? S_EDIT_BTN : S_VIEW_BTN) + '</span>';
                $(this).text(((mode == 'EditMode') ? S_EDIT_BTN : S_VIEW_BTN));
                $(this).text('');
                $(this).append(btn_name);
                $(this).click($.proxy(function () {
                    _onGlobalSwitchModeClick.call(this, true);
                    return false;
                }, self));
            }
        });
    }

    function _initUACButtons() {
        var self = this;
        
        _initViewEditButton.call(this, 'EditMode');

        _InitUserAccountButtons.call(this);
    }

    function _initHovers() {
        var self = this;
        // initialize OnAttrHover handler
        $('table.data tr.attr').each(function () {
            $(this).bind('mouseenter', { target: this }, $.proxy(onAttrHoverOn, self));
            $(this).bind('mouseleave', { target: this }, $.proxy(onAttrHoverOff, self));
            $(this).bind('mousemove', { target: this }, $.proxy(onAttrMouseMove, self));
        });
    }

    function onAttrMouseMove(e) {
        if (!e.data.target.mouseMoveProcessed && !uiManager.trHovered) {
            onAttrHoverOn.call(this,e);
            e.data.target.mouseMoveProcessed = true;
        }
    }

    function onAttrHoverOn(e) {
        if (this.IsProfileReadonly()) { return; }

        if (!this.IsInlineModifyTurnedOn() && !this.IsGlobalEditTurnedOn()) {
            $(e.data.target).addClass("current");
            uiManager.trHovered = e.data.target;
        }

        // trick to resolve problem with inline buttons appearance
        // we manually trigger onhover event for attribute if it is situated in currently hovered container
        // and manually trigger onhoveroff when mouse leaves this area.

        var attr = $(e.data.target).find('input.ldapAttrInfo[type=hidden]');
        if (attr.length != 1) { return; }


        if (this._attrHovered) {
            this._attrHovered.attrinfo('parentHoverOff');
            this._attrHovered = null;
        }
        this._attrHovered = attr.first();
        this._attrHovered.attrinfo('parentHoverOn', e);

    }

    // trigger hoveroff event for attribute for which we manually triggered hoveron event.
    function onAttrHoverOff(e) {
        $(e.data.target).removeClass("current");
        uiManager.trHovered = null;

        if (this._attrHovered) {
            this._attrHovered.attrinfo('parentHoverOff');
            this._attrHovered = null;
        }
    }

    function _initOther() {
        // png fix for IE 5.5/6
        _applyPngTransparanceFix.call(this);
    }

    function _applyPngTransparanceFix() {
        var badBrowser = (/MSIE ((5\.5)|6)/.test(navigator.userAgent) && navigator.platform == "Win32");
        if (badBrowser && typeof (DD_belatedPNG) != 'undefined' && DD_belatedPNG.fix) {
            $('img[src$=.png]').addClass('pngfix');
            DD_belatedPNG.fix('img.pngfix');
        }
    }

    function _addSaveCancelButtons() {
        var self = this;
        var buttonsInited = true;
        // create container for buttons
        if (!this._globalSaveCancelButtons) {
            this._globalSaveCancelButtons = $("div.globalSaveCancelButtons");
            buttonsInited = false;
        }
        if (!this._globalSaveCancelButtons.length) { return; }

        // generate buttons and attach handlers
        this._globalSaveCancelButtons.each(function () {
            // simply show or create and show
            if (buttonsInited) {
                $(this).show();
            }
            else {
                $(this).append('<br>');
                var table = $('<table>').addClass('globalSaveCancelButtons');
                $(this).append(table);
                var tr = $('<tr>');
                table.append(tr);

                var tdSave = $('<td>');
                tr.append(tdSave);
                var btnSave = $('<button type="button" tabIndex="0">' + S_SAVE + '</button>').addClass('saveGlobal')
                    .addClass(self.Lang()).click($.proxy(_onSaveBtnClick, self));
                tdSave.append(btnSave);

                tr.append('<td>&nbsp;&nbsp;&nbsp;</td>');

                var tdCancel = $('<td>');
                tr.append(tdCancel);
                var btnCancel = $('<button type="button" tabIndex="0">' + S_CANCEL + '</button>').addClass('cancelGlobal')
                    .addClass(self.Lang()).click($.proxy(_onCancelBtnClick, self));
                tdCancel.append(btnCancel);
            }
        })
    }

    // hide save/cancel buttons
    function _removeSaveCancelButtons() {
        if (this._globalSaveCancelButtons) {
            this._globalSaveCancelButtons.each(function () {
                $(this).hide();
            });
        }
    }

    function _notifyHostModifyStateChanged() {
        // if state hasn't changed - do nothing
        var stateTurnedOn = this._globalEditTurnedOn || this._inlineModifyTurnedOn;
        if (stateTurnedOn == this._CommonEditTurnedOn) { return; }
        this._CommonEditTurnedOn = stateTurnedOn;
        // notify host about modify state changed.
        // if current host's state is TRUE then if user change node confirmation proposing save changes will appear
        try {
            window.external.ContextNode.SyncOperation("SetModifyEnabled", "", stateTurnedOn ? 1 : 0);
        }
        catch (e) { }
    }

    //////////////////////////////////////////////////////////////////////////
    // handlers

    function _onGlobalSwitchModeClick(isHeaderBtnClicked) {
        var gatherResult = _gatherAllModifications.call(this);
        if (this.IsInlineModifyTurnedOn() || (this.IsGlobalEditTurnedOn() && isHeaderBtnClicked)) {
             if (gatherResult.modifications && gatherResult.modifications.length) {
                if (confirm(this.IsInlineModifyTurnedOn() ? S_PAGE_DATA_LOST : S_CHANGE_TO_VIEW_MODE)) {
                    uiManager.CancelAllInlineModifies();
                }
                else {
                    // prevent tab selection
                    return;
                }
            }
            else if (this.IsInlineModifyTurnedOn()) {
                uiManager.CancelAllInlineModifies();
            }
        }

        this._globalEditTurnedOn = !this._globalEditTurnedOn;

        _notifyHostModifyStateChanged.call(this);

        var fAttrInfoTurnViewMode = function () {
            this.attrinfo('turnMode', 'ViewMode', {
                clearViewModeContent: true,
                clearEditModeContent: true,
                globalSwitchMode: true
            });
        }
        var fAttrInfoTurnEditMode = function () {
            this.attrinfo('turnMode', 'EditMode', {
                clearViewModeContent: true,
                clearEditModeContent: true,
                globalSwitchMode: true
            });
        }
        var fControlTurnViewMode = function () {
            this.control('turnMode', 'ViewMode', { globalSwitchMode: true });
        }
        var fControlTurnEditMode = function () {
            this.control('turnMode', 'EditMode', { globalSwitchMode: true });
        }

        _initViewEditButton.call(this, this._globalEditTurnedOn ? 'ViewMode' : 'EditMode');

        if (this._globalEditTurnedOn) {
            // change button's images
            _initSwitchModeBtnUrls.call(this, 'ViewMode');
            
            $(".globalSwitchModeBtn").removeClass('globalEdit_' + this._lang).addClass('globalView_' + this._lang);
            _addSaveCancelButtons.call(this);
            
            this._changeablePhotoWdgs.each(function () {
                $(this).photo('turnMode', 'EditMode');
            });

            this._attrInfoWdgs.each(function () {
                if ($(this).attrinfo('option', 'isVisible')) {
                    fAttrInfoTurnEditMode.call($(this));
                }
                else {
                    // postponed switch invisible
                    var operGroup = PostponedOperationsManager.OperationGroups.attrinfoTurnMode;
                    PostponedOperationsManager.AddOperation(operGroup, true, $.proxy(function () {
                        fAttrInfoTurnEditMode.call(this);
                    }, $(this)));
                }
            });
            this._controlsWdgs.each(function () {
                if ($(this).control('option', 'isVisible')) {
                    fControlTurnEditMode.call($(this));
                }
                else {
                    // postponed switch invisible
                    var operGroup = PostponedOperationsManager.OperationGroups.controlTurnMode;
                    PostponedOperationsManager.AddOperation(operGroup, true, $.proxy(function () {
                        fControlTurnEditMode.call(this);
                    }, $(this)));
                }
            });
        }
        else {
            _initSwitchModeBtnUrls.call(this, 'EditMode');
            
            $(".globalSwitchModeBtn").removeClass('globalView_' + this._lang).addClass('globalEdit_' + this._lang);
            _removeSaveCancelButtons.call(this);

            this._changeablePhotoWdgs.each(function () {
                $(this).photo('turnMode', 'ViewMode');
            });

            this._attrInfoWdgs.each(function () {
                if ($(this).attrinfo('option', 'isVisible')) {
                    fAttrInfoTurnViewMode.call($(this));
                }
                else {
                    // postponed switch invisible
                    var operGroup = PostponedOperationsManager.OperationGroups.attrinfoTurnMode;
                    PostponedOperationsManager.AddOperation(operGroup, true, $.proxy(function () {
                        fAttrInfoTurnViewMode.call(this);
                    }, $(this)));
                }
            });
            this._controlsWdgs.each(function () {
                if ($(this).control('option', 'isVisible')) {
                    fControlTurnViewMode.call($(this));
                }
                else {
                    // postponed switch invisible
                    var operGroup = PostponedOperationsManager.OperationGroups.controlTurnMode;
                    PostponedOperationsManager.AddOperation(operGroup, true, $.proxy(function () {
                        fControlTurnViewMode.call(this);
                    }, $(this)));
                }
            });
        }

        // !isHeaderBtnClicked - cancel button was clicked so we need trigger mouseleave event instead of mouseenter
        if (isHeaderBtnClicked) {
            $('.globalSwitchModeBtn').trigger('mouseenter');
        }
        else {
            $('.globalSwitchModeBtn').trigger('mouseleave');
        }

        TimersHolder.addFunction(function () {
            // execute postponed operations
            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoTurnMode);
            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.controlTurnMode);
            PostponedBindsManager.PerformBinds();
        });

        _updateFoldPanesLastTDVals();
        
        return false;
    }

    function _onSaveBtnClick() {
        var gatherResult = _gatherAllModifications.call(this);
        if (!gatherResult) {
            _onCancelBtnClick.call(this);
            return false;
        }

        if (gatherResult.preventSaving) {
            return;
        }

        var modifications = gatherResult.modifications;

        if (modifications && modifications.length) {
            this.ManualSaveInitiated();
            _saveModifiedAttributes.call(this, modifications, true);
        }
        else {
            _onCancelBtnClick.call(this);
        }

        return false;
    }

    function _gatherAllModifications() {
        var gatherResult = {};
        var multiplyModifiedAttrs = [];
        gatherResult.modifications = [];
        gatherResult.preventSaving = false;
        var fAttrAlreadyModified = function (modifs, attrType) {
            for (var i = 0; i < modifs.length; i++) {
                if (modifs[i].uType == attrType) { return true; }
            }
        }

        var bBreakEach = false;
        // ask every attr whether it has been modified
        this._attrInfoWdgs.each(function () {
            if (bBreakEach) { return; }
            if ($(this).attrinfo('option', 'switchedMode') == 'ViewMode') { return; }

            // get attached attribute object
            var obj = $(this).attrinfo('option', 'jsonObject');
            Softerra.Func.Check(obj);
            if (!obj.uType) { return; }

            // if current attribute is readonly - get next attribute
            if (obj.readonly) { return; }

            // get processor for current attribute
            var proc = Softerra.Class.ProcessorsMgr.GetProcessor(obj);

            // find 
            var valsTable = $(this).parent().find('.editValues');
            if (proc && proc.GetModifiedValues) {
                var resultObj = proc.GetModifiedValues.call(proc, obj, valsTable);
                if (resultObj != undefined) {
                    // check whether this attribute has already been modified. If yes - add it to the multiplyModifiedAttrs array.
                    // If not - push to gatherResult.modifications
                    if (fAttrAlreadyModified(gatherResult.modifications, obj.uType)) {
                        var existsInAlreadyModifArr = false;
                        for (var i = 0; i < multiplyModifiedAttrs.length; ++i) {
                            if (multiplyModifiedAttrs[i].uType == obj.uType) {
                                existsInAlreadyModifArr = true;
                                break;
                            }
                            if (!existsInAlreadyModifArr) {
                                multiplyModifiedAttrs.push(obj);
                            }
                        }
                    }
                    else {
                        resultObj.uType = obj.uType;
                        gatherResult.modifications.push(resultObj);
                    }
                }
            }
        });

        // loop through controls and gather modifications
        this._controlsWdgs.each(function () {
            if ($(this).control('option', 'currentMode') == 'ViewMode') { return; }
            var controlModifications = $(this).control('getModifications');
            if (!controlModifications) { return; }

            var bModificationLegal = true;
            // save backup for the reason if control tries to modify attribute that is already present and 
            // can't merge values for it. Then we simply rollback modifications array.
            var modifsBackup = cloneObj(gatherResult);

            // if one of control's attributes failed then all control's modifications are illegal
            for (var i = 0; i < controlModifications.length; ++i) {
                if (!bModificationLegal) { break; }
                var bFound = false;

                for (var iGathRes = 0; iGathRes < gatherResult.modifications.length; ++iGathRes) {
                    if (gatherResult.modifications[iGathRes].uType != controlModifications[i].uType) { continue; }
                    bFound = true;
                    if (gatherResult.modifications[iGathRes].uEncFlags != controlModifications[i].uEncFlags) {
                        bModificationLegal = false;
                        break;
                    }

                    var mergeRes = ValuesMerger.merge(controlModifications[i].uType, controlModifications[i].uEncFlags,
                        gatherResult.modifications[i].uValues, controlModifications[i].uValues);
                    if (!mergeRes) {
                        bModificationLegal = false;
                        break;
                    }
                    else {
                        gatherResult.modifications[iGathRes].uValues = mergeRes;
                        break;
                    }
                }

                if (bModificationLegal && !bFound) {
                    gatherResult.modifications.push(controlModifications[i]);
                }
            }

            if (!bModificationLegal) {
                gatherResult = modifsBackup;
            }
        });

        return gatherResult;
    }

    function _saveModifiedAttributes(modifications, refreshNode) {
        if (!modifications || !modifications.length) { return; }

        var modifyRequest = { refreshNode: refreshNode, uModifications: modifications };
        var jsonResultObj = $.toJSON(modifyRequest);

        if (jsonResultObj) {
            var operId;
            try {
                operId = window.external.ContextNode.SyncOperation("ModifyEntry", jsonResultObj, 0);
            }
            catch (e) { }
        }
    }

    function _onCancelBtnClick() {
        _onGlobalSwitchModeClick.call(this);
        return false;
    }

    function _onTabSelect(e, ui) {
        // check whether modifications exists on the current tab.
        if (this.IsTabbedInlineModifyTurnedOn()) {
            if (confirm(S_TABCLICK_DATA_LOST)) {
                uiManager.CancelAllInlineModifies();
            }
            else {
                // prevent tab selection
                e.preventDefault();
                return;
            }
        }

        // set attrs and controls on the tab we are leaving as invisible
        $(this._tabsCurrPanel).find('input.ldapAttrInfo[type=hidden]').each(function () {
            $(this).attrinfo('option', 'isVisible', false);
        });
        $(this._tabsCurrPanel).find('.control').each(function () {
            $(this).control('option', 'isVisible', false);
        });
    }

    function _onTabShow(e, args) {
        this._tabsCurrPanel = args.panel;

        // set attrs and controls on the newly showed tab as visible
        $(args.panel).find('input.ldapAttrInfo[type=hidden]').each(function () {
            $(this).attrinfo('option', 'isVisible', true);
        });
        $(args.panel).find('.control').each(function () {
            $(this).control('option', 'isVisible', true);
        });

        _pageElementsVisibilityChanged.call(this);
 
        this.VerifyUserParametersParsing();
    }

    function _onFoldShow() {
        _pageElementsVisibilityChanged.call(this);
    }

    function _pageElementsVisibilityChanged() {
        // notify groupmembership widgets about their visibility changed
        if (this._m2gGroupsWdgs) {
            this._m2gGroupsWdgs.groupmembership('showIfVisible');
        }
        if (this._m2gMembersWdgs) {
            this._m2gMembersWdgs.groupmembership('showIfVisible');
        }
    }

    function _updateFoldPanesLastTDVals () {
        $('div.foldPane').each(function () {
                $(this).find('td.val:last').addClass('last');
            });    
    }

    //////////////////////////////////////////////////////////////////////////
    //public:
    this.InitAll = function () {
        //synchronous
        // discard links (images) from tabbing if they shouldn't participate in tabbing
        $('a[tabIndex=0]').attr('tabIndex', -1);
        $('.indexable').each(function (index) {
            $(this).attr('tabindex', '0');
        });

        _initOther.call(this); // png fix
        _initWidgets.call(this); // tabs, fold, groupmembership, childnodes, photo, errorinfo, allattrsinfo

        var fInlineModifyTurned = function (event, data) {
            uiManager._inlineModifyTurnedOn = data.state;
            if (uiManager.trHovered) {
                $(uiManager.trHovered).trigger('mouseleave');
            }
            _notifyHostModifyStateChanged.call(uiManager);

            if (data.state) {
                if (data.element[data.notifier]('option', 'tabbed') == true) {
                    uiManager._tabbedInlineModifyTurnedOn = true;
                }
            }
            else {
                uiManager._tabbedInlineModifyTurnedOn = false;
            }
        }

        var uiManager = this;
        var fInitAttributes = function () {
            uiManager._attrInfoWdgs = $('input.ldapAttrInfo[type=hidden]');
            uiManager._attrInfoWdgs.each(function () {
                $(this).attrinfo({ uiManager: uiManager });
            })
            .bind('attrinfoInlineModifyTurned'.toLowerCase(), fInlineModifyTurned);

            $('div#tabs input.ldapAttrInfo').each(function () {
                $(this).attrinfo('option', 'tabbed', true);
                $(this).attrinfo('option', 'isVisible', false);
            });

            if (uiManager._tabsCurrPanel) {
                uiManager._tabsCurrPanel.find('input.ldapAttrInfo').attrinfo('option', 'isVisible', true);
            }

            uiManager._attrInfoWdgs.each(function () {
                var attr = this;
                if ($(this).attrinfo('option', 'isVisible')) {
                    $(this).attrinfo('turnMode', 'ViewMode');
                }
                else {
                    var operGroup = PostponedOperationsManager.OperationGroups.attrinfoProcessing;
                    PostponedOperationsManager.AddOperation(operGroup, true, function (params) {
                        TimersHolder.addFunction($.proxy(function () {
                            $(attr).attrinfo('turnMode', 'ViewMode');
                        }, attr), null, 0);
                        TimersHolder.addFunction(function () {
                            PostponedOperationsManager.Execute(operGroup);
                            PostponedBindsManager.PerformBinds();
                        });
                    });
                }
            });

            _updateFoldPanesLastTDVals();    
        }

        var fInitControls = function () {
            uiManager._controlsWdgs = $('.control');
            uiManager._controlsWdgs.each(function () {
                $(this).control();
            })
            .bind('controlInlineModifyTurned'.toLowerCase(), fInlineModifyTurned);

            $('div#tabs .control').each(function () {
                $(this).control('option', 'tabbed', true);
                $(this).control('option', 'isVisible', false);
            });

            if (uiManager._tabsCurrPanel) {
                uiManager._tabsCurrPanel.find('.control').control('option', 'isVisible', true);
            }

            uiManager._controlsWdgs.each(function () {
                var currControl = this;
                if ($(this).control('option', 'isVisible')) {
                    $(this).control('turnMode', 'ViewMode');
                }
                else {
                    var operGroup = PostponedOperationsManager.OperationGroups.controlProcessing;
                    PostponedOperationsManager.AddOperation(operGroup, true, function (params) {
                        TimersHolder.addFunction($.proxy(function () {
                            $(currControl).control('turnMode', 'ViewMode');
                        }, currControl), null, 0);
                        TimersHolder.addFunction(function () {
                            PostponedOperationsManager.Execute(operGroup);
                            PostponedBindsManager.PerformBinds();
                        });
                    });
                }
            });
        }

        fInitAttributes();
        fInitControls();
        _initButtons.call(this);
        _initHovers.call(this);
        _initUACButtons.call(this);
        this._allInited = true;

        TimersHolder.addFunction(function () {
            //asynchronous
            TimersHolder.addFunction(function () {
                PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
                PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.controlProcessing);
                PostponedBindsManager.PerformBinds();
            });
        })

        return;
    }

    this.IsGlobalEditTurnedOn = function () {
        return this._globalEditTurnedOn;
    };

    this.IsInlineModifyTurnedOn = function () {
        return this._inlineModifyTurnedOn;
    };

    this.IsTabbedInlineModifyTurnedOn = function () {
        return this._tabbedInlineModifyTurnedOn;
    };

    this.IsProfileReadonly = function () {
        if (this._isProfileReadonly == undefined) {
            try {
                this._isProfileReadonly = window.external.ContextNode.SyncOperation("IsProfileReadonly", "", 0);
            }
            catch (e) {
                this._isProfileReadonly = true;
            }
        }

        return this._isProfileReadonly;
    };

    this.VerifyUserParametersParsing = function () {
        if (this._parsingError == null) { 
            return; 
        }
        
        var tabHref = $("#tabs .ui-tabs-selected").children("a").attr("href");
        if (tabHref == '#tabAdvanced') {
            alert(this._parsingError);
            this._parsingError = null;
        }
    }                                               

    this.IsPageInited = function () {
        return this._allInited;
    }

    this.ViewName = function () {
        return this._viewName;
    }

    this.CancelAllInlineModifies = function () {
        this._attrInfoWdgs.each(function () {
            if ($(this).attrinfo('option', 'isInlineModifyTurnedOn')) {
                $(this).attrinfo('cancelInlineModify');
            }
        });
        this._controlsWdgs.each(function () {
            if ($(this).control('option', 'isInlineModifyTurnedOn')) {
                $(this).control('cancel');
            }
        });
    }

    this.DontAskAboutSaving = false;
    // this function is called by the host and perform saving data if modifications were made
    this.OnBeforePageChenged = function () {
        if (this.DontAskAboutSaving) { return; }
        if (this.IsGlobalEditTurnedOn() || this.IsInlineModifyTurnedOn()) {
            var gatherResult = _gatherAllModifications.call(this);

            if (!gatherResult) { return; }
            if (gatherResult.preventSaving) { return; }

            if (gatherResult.modifications && gatherResult.modifications.length) {
                var objName = S_OBJECT;
                try {
                    objName = window.external.ContextNode.Name;
                }
                catch (e) { }

                this.DontAskAboutSaving = true;
                var confirmMsg = Softerra.Class.StringMgr.Format(S_ATTRIBUTESCHANGED_SAVECONFIRM, objName);
                var saveData = confirm(confirmMsg);
                if (saveData) {
                    _saveModifiedAttributes.call(this, gatherResult.modifications, false);
                }
            }
        }
        return true;
    }

    // called by the host
    this.FadePage = function () {
        TimersHolder.killTimers();
        var bgColor = $("html").css("background-color");
        if ('transparent' == bgColor) { bgColor = 'White'; }
        Softerra.Func.ShowWaitingPage({ opacity: 0.5, backgroundColor: bgColor });
    }

    this.ManualSaveInitiated = function () {
        this.DontAskAboutSaving = true;
    }

    this.Lang = function () {
        return this._lang;
    }
};