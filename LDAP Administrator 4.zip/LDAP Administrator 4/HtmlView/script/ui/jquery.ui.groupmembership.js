/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {
    $.widget("ui.groupmembership", {
        options: {
            childrenPerPage: 15,
            objectsType: null
        },

        _create: function () {
            if (!Softerra.Func.StringInArray(['groups', 'members'], this.options.objectsType, true)) {
                return;
            };

            this._checkedDNs = [];

            this.refreshButton = null;
            this.addObjectsButton = null;
            this.removeObjectsButton = null;

            this._headerCheckbox = null;

            this._baseView = null;

            this._contPaginView = null;

            this._contentView = null;
            this._selectedStatus = null;
            this._contentHeader = null;

            this._contentFilter = null;
            this._filterInputElem = null;

            this._searchResView = null;
            this._paginationView = null;
            this._statusView = null;
            this._buttonsView = null;

            this._typeColumnHidden = true;

            this._isProfileReadonly = null;
            try {
                this._isProfileReadonly = window.external.ContextNode.SyncOperation("IsProfileReadonly", "", 0);
            }
            catch (e) {
                this._isProfileReadonly = true;
            }

            this._isDynamicGroup = false;
            try {
                this._isDynamicGroup = window.external.ContextNode.SyncOperation("IsDynamicGroup", "", 0);
            }
            catch (e) {
            }

            this._canAddRemoveMembers = null;
            try {
                this._canAddRemoveMembers = window.external.ContextNode.SyncOperation("CanAddRemoveMembers", "", 0);
            }
            catch (e) {
                this._canAddRemoveMembers = true;
            }

            this.showIfVisible();
        },

        _getTypeColumnNum: function()
        {
            if (this._isProfileReadonly) {
                return 2;
            }
            else {
                return 3;
            }
        },

        _checkDN: function (dn) {
            for (var i = 0; i < this._checkedDNs.length; ++i) {
                if (dn == this._checkedDNs[i]) {
                    return;
                }
            }
            this._checkedDNs.push(dn);

            if (this.processingElement.state != 'waiting') {
                this.removeObjectsButton.removeAttr('disabled');
                customButtonSync(this.removeObjectsButton);
            }
        },

        _uncheckDN: function (dn) {
            for (var i = 0; i < this._checkedDNs.length; ++i) {
                if (dn == this._checkedDNs[i]) {
                    this._checkedDNs.splice(i, 1);
                    break;
                }
            }

            if (this._checkedDNs.length && this.processingElement.state != 'waiting') {
                this.removeObjectsButton.removeAttr('disabled');
                customButtonSync(this.removeObjectsButton);
            }
            else {
                this.removeObjectsButton.attr('disabled', 'disabled');
                customButtonSync(this.removeObjectsButton);
            }
        },

        _isDNChecked: function (dn) {
            for (var i = 0; i < this._checkedDNs.length; ++i) {
                if (dn == this._checkedDNs[i]) {
                    return true;
                }
            }
            return false;
        },

        _disableButtons: function () {
            if (this.refreshButton) {
                this.refreshButton.attr('disabled', 'disabled');
                customButtonSync(this.refreshButton);
            }
            if (this.addObjectsButton) {
                this.addObjectsButton.attr('disabled', 'disabled');
                customButtonSync(this.addObjectsButton);
            }
            if (this.removeObjectsButton) {
                this.removeObjectsButton.attr('disabled', 'disabled');
                customButtonSync(this.removeObjectsButton);
            }
            if (this.exportObjectsButton) {
                this.exportObjectsButton.attr('disabled', 'disabled');
                customButtonSync(this.exportObjectsButton);
            }
            if (this.importObjectsButton) {
                this.importObjectsButton.attr('disabled', 'disabled');
                customButtonSync(this.importObjectsButton);
            }
            if (this.modifyDynamicMembership) {
                this.modifyDynamicMembership.attr('disabled', 'disabled');
                customButtonSync(this.modifyDynamicMembership);
            }
         },

        _enableButtons: function () {
            if (this.refreshButton) {
                this.refreshButton.removeAttr('disabled');
                customButtonSync(this.refreshButton);
            }
            if (this.addObjectsButton) {
                this.addObjectsButton.removeAttr('disabled');
                customButtonSync(this.addObjectsButton);
            }
            if (this.removeObjectsButton) {
                this.removeObjectsButton.removeAttr('disabled');
                customButtonSync(this.removeObjectsButton);
            }
            if (this.exportObjectsButton) {
                this.exportObjectsButton.removeAttr('disabled');
                customButtonSync(this.exportObjectsButton);
            }
            if (this.importObjectsButton) {
                this.importObjectsButton.removeAttr('disabled');
                customButtonSync(this.importObjectsButton);
            }
            if (this.modifyDynamicMembership) {
                this.modifyDynamicMembership.removeAttr('disabled');
                customButtonSync(this.modifyDynamicMembership);
            }
        },

        showIfVisible: function () {
            // if not visible on the page - skip
            if (!this.element.is(':visible')) { return; }

            if (!this.processingElement) {
                this.processingElement = {
                    pane: this.element,
                    objectsType: this.options.objectsType,
                    state: 'idle',
                    prevState: 'idle',
                    displayedCount: 0,
                    pageIndex: 0,
                    fetchedObjects: []
                };
            }

            this._processOneElement(false);
        },

        _processOneElement: function (fullSearch) {
            var elem = this.processingElement;

            // if generated - skip
            if (elem.state == 'generated') { return; }

            var operation = this._getOperationByElement(elem);

            // if stopped - remove corresponded operation and create view
            if (elem.state == 'stopped') {
                this._generateView({ element: elem, operation: operation });
                return;
            }

            // if idle - find already completed operation or start new one, set waiting state
            if (elem.state == 'idle') {
                elem.state = 'waiting';

                // if operation isn't started yet - start it
                if (!operation) {
                    var filter = '';
                    if (this._filterInputElem && !this._filterInputElem.hasClass('cueMode')) {
                        filter = this._filterInputElem.val() || '';
                    }

                    var operName = (elem.objectsType == 'members') ? 'EnumMemberObjects' : 'EnumMembershipObjects';
                    var params = { uEnumObjectsFilter: filter };
                    var operId = 0;
                    if (fullSearch) {
                        operId = window.external.ContextNode.BeginAsyncOperation(operName, $.toJSON(params), 0);
                    }
                    else {
                        params.uSizeLimit = this.options.childrenPerPage;
                        operId = window.external.ContextNode.BeginAsyncOperation(operName, $.toJSON(params), 0);
                    }

                    this._disableButtons();

                    var newOperation = {
                        operId: operId,
                        objectsType: elem.objectsType,
                        state: 'pending',
                        processedCount: 0,
                        prevProcessedCount: 0,
                        fullSearch: fullSearch,
                        duration: 0
                    };

                    $.fn.groupmembership._startedOperations.push(newOperation);

                    this._generateView({ element: elem, operation: newOperation });

                    TimersHolder.addFunction($.proxy(function () {
                        this._processOneElement(false);
                    }, this));

                    return;
                }
            }
            if (elem.state == 'waiting') {
                // check whether operation has been finished
                if (operation.state == 'pending') {
                    var isFinished = false;
                    try {
                        isFinished = window.external.ContextNode.FinishedAsyncOperation(operation.operId);
                    }
                    catch (e) {}

                    if (isFinished) {
                        operation.state = 'finished';
                        this._enableButtons();
                        elem.state = 'generated';
                        this._generateView({ operation: operation, element: elem });
                    }
                    else {
                        if (operation.duration > $.fn.groupmembership._waitBeforeShowTimeout) {
                            this._generateView({ operation: operation, element: elem });
                        }

                        this._disableButtons();

                        operation.duration += $.fn.groupmembership._checkEnumOperTimeout;
                        TimersHolder.addFunction($.proxy(function () {
                            this._processOneElement(false);
                        }, this), null, $.fn.groupmembership._checkEnumOperTimeout);
                    }
                }
                else if (operation.state == 'finished') {
                    this._enableButtons();
                    elem.state = 'generated';
                    this._generateView({ operation: operation, element: elem });
                }
            }
        },

        //////////////////////////////////////////////////////////////////////////
        // html generators
        _generateView: function (opts) {
            if (!this._baseView) {
                this._generateBaseView(opts);
            }
            this._getNecessaryOperationData(opts);
            this._generateSelectedStatus();
            this._generateFilter(opts);
            this._generateStatus(opts);
            this._generateNElementsFetchedView(opts);
            this._generatePagination(opts);
            this._generateHeaderCheckboxState();
            opts.element.prevState = opts.element.state;
            opts.element.prevProcessedCount = opts.element.processedCount;
            
            if (Softerra.Func.GetBool(opts.element.resObj.uNotOnlyStaticTypes)) {
                this._showTypeColumn(true);
            }
            
            if (!this._isProfileReadonly && this._canShowAddRemoveButtons(opts.operation.objectsType)) {
                if (this._checkedDNs.length && this.processingElement.state != 'waiting') {
                    this.removeObjectsButton.removeAttr('disabled');
                    customButtonSync(this.removeObjectsButton);
                }
                else {
                    this.removeObjectsButton.attr('disabled', 'disabled');
                    customButtonSync(this.removeObjectsButton);
                }
            }
        },
        
        _canShowAddRemoveButtons: function (objectsType)
        {
            return (objectsType == 'groups' || (this._canAddRemoveMembers == true && objectsType == 'members'));
        },

        _generateBaseView: function (opts) {
            var elemAppendTo = opts.element.pane;
            elemAppendTo.empty();
            this._baseView = $('<div>').addClass('m2g');
            elemAppendTo.append(this._baseView);

            this._contPaginView = $('<div>').addClass('m2gContentAndPagination');
            this._baseView.append(this._contPaginView);

            this._contentView = $('<div>').addClass('m2gContent');
            this._contPaginView.append(this._contentView);

            this._generateContentView();

            var paginationAndStatusDiv = $('<div class="m2gPaginationAndStatus clearfix">');
            this._contPaginView.append(paginationAndStatusDiv);

            var paginationAndStatus = $('<table class="paginAndStatus">');
            paginationAndStatusDiv.append(paginationAndStatus);

            var trPaginationAndStatus = $('<tr>');
            paginationAndStatus.append(trPaginationAndStatus);

            var tdPagination = $('<td class="m2gTdPagination">');
            trPaginationAndStatus.append(tdPagination);
            this._paginationView = $('<div class="m2gPagination">');
            tdPagination.append(this._paginationView);

            this._statusView = $('<td class="m2gTdStatus"></td>');
            trPaginationAndStatus.append(this._statusView);

            this._buttonsView = $('<div>').addClass('m2gButtons');
            this._baseView.append(this._buttonsView);
            this._appendManageButton(this._buttonsView, opts);
        },

        _getTableHeaderId: function()
        {
            return "tableHeader" + this.options.objectsType; 
        },

        _getTableContentId: function()
        {
            return "tableContent" + this.options.objectsType;
        },

        _generateContentView: function () {
            if (!this._contentView) { return; }

            if (!this._contentHeader) {
                this._contentView.empty();

                // generate selected status view
                this._selectedStatus = $('<div class="m2gSelectedStatus">');
                this._contentView.append(this._selectedStatus);

                // generate header
                this._contentHeader = $('<div class="m2gContentHeader">');
                this._contentView.append(this._contentHeader);

                var tableHeader = $('<table id="' + this._getTableHeaderId() + '" class="header">');
                this._contentHeader.append(tableHeader);

                var trHeader = $('<tr>');
                tableHeader.append(trHeader);

                if (!this._isProfileReadonly) {
                    var tdDropDownList = $('<td class="headerCheckbox">');
                    trHeader.append(tdDropDownList);
                    this._headerCheckbox = $('<input type="checkbox" value="false" />').click($.proxy(this._headerCheckboxClick, this));
                    tdDropDownList.append(this._headerCheckbox.wrap("<span class='themedCheckbox'></span>").parent());
                }
                trHeader.append('<td class="headerIcon">');
                trHeader.append('<td class="headerObject">' + (
                    (this.options.objectsType == 'members') ?
                    S_MEMBERS :
                    S_GROUPS) +
                    '</td>');
                trHeader.append('<td ' + this._getTypeColumnDisaplyStyle() + 'class="headerType">' + S_TYPE + '</td>');
                trHeader.append('<td class="headerParent">' + S_PARENTS + '</td>');
            
                this._contentFilter = $('<div class="m2gContentFilter">');
                this._contentView.append(this._contentFilter);
                this._searchResView = $('<div class="m2gSearchRes">');
                this._contentView.append(this._searchResView);
            }
            else {
                this._searchResView.empty();
            }
        },

        _getNecessaryOperationData: function (opts) {
            opts.operation.processedCount = window.external.ContextNode.AsyncOperationStatus(opts.operation.operId);
            opts.element.pagesCount = Math.ceil(opts.operation.processedCount / this.options.childrenPerPage);

            var bStateChanged = opts.element.state != opts.element.prevState;

            if (opts.element.fetchedObjects.length < this.options.childrenPerPage || bStateChanged) {
                var lastFetchedIndex = (this.options.childrenPerPage * opts.element.pageIndex) + opts.element.fetchedObjects.length;
                if (opts.operation.processedCount > lastFetchedIndex || bStateChanged) {
                    var params = $.toJSON(
                        {
                            uPageNumber: opts.element.pageIndex,
                            uChildrenPerPage: this.options.childrenPerPage,
                            uStartIndex: opts.element.fetchedObjects.length
                        });
                    var resObj;
                    try {
                        var resStr = window.external.ContextNode.EndAsyncOperation(opts.operation.operId, params);
                        opts.element.resObj = $.parseJSON(resStr);
                        if (opts.element.resObj.objects.constructor == Array) {
                            opts.element.fetchedObjects = opts.element.fetchedObjects.concat(opts.element.resObj.objects);
                        }
                    }
                    catch (e) {
                        opts.operation.state = 'failed';
                    }
                }
                else {
                    return;
                }
            }
        },

        _generateFilter: function (opts) {
            if (!this._contentFilter) { return; }

            if (!this._filterInputElem) {
                var table = $('<table>');
                var tr = $('<tr>');
                table.append(tr);
                var td1 = $('<td class="tdInput">');
                var td2 = $('<td class="tdImg">');
                tr.append(td1);
                tr.append(td2);

                this._contentFilter.append(table);

                this._filterInputElem = $('<input id="' + NextId() + '" type="text" value="" />');
                td1.append(this._filterInputElem);
                AttachCue({ directBind: true, element: this._filterInputElem, cueText: S_MEMBERSHIP_FILTER_CUE });

                this._filterInputElem.bind('keyup', { fullSearch: true }, $.proxy(function (event) {
                    if (event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                        this._searchOperation(event);
                        return false;
                    }
                }, this));

                var searchStart = $('<div tabIndex="0" class="searchStart"/>');
                var imgStartNormal = $('<img class="imageNormal" src="' + IMG_PATH + IMG_M2G_SEARCHSTART + '" />');
                var imgStartDark = $('<img class="imageDark" src="' + IMG_PATH + IMG_M2G_SEARCHSTART_DARK + '" />');
                searchStart.append(imgStartNormal);
                searchStart.append(imgStartDark);
                td2.append(searchStart);
                searchStart
                    .bind('click', { fullSearch: true }, $.proxy(function (event) {
                        this._searchOperation(event);
                        return false;
                    }, this))
                    .bind('keyup', { fullSearch: true }, $.proxy(function (event) {
                        if (event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                            this._searchOperation(event);
                            return false;
                        }
                    }, this))
                    // .bind('mouseenter', function () {
                    //     $(this).attr('src', IMG_PATH + IMG_M2G_SEARCHSTART_OVER);
                    // })
                    // .bind('mouseleave', function () {
                    //     $(this).attr('src', IMG_PATH + IMG_M2G_SEARCHSTART);
                    // })
                    // .bind('mousedown', function () {
                    //     $(this).attr('src', IMG_PATH + IMG_M2G_SEARCHSTART_CLICKED);
                    // })
                    // .bind('mouseup', function () {
                    //     $(this).attr('src', IMG_PATH + IMG_M2G_SEARCHSTART);
                    // })

                var searchStop = $('<div tabIndex="0" class="searchStop"/>');
                var imgStopNormal = $('<img class="imageNormal" src="' + IMG_PATH + IMG_M2G_SEARCHSTOP + '" />');
                var imgStopDark = $('<img class="imageDark" src="' + IMG_PATH + IMG_M2G_SEARCHSTOP_DARK + '" />');
                searchStop.append(imgStopNormal);
                searchStop.append(imgStopDark);
                td2.append(searchStop);
                searchStop
                    .bind('click', $.proxy(function (event) {
                        this._stopOperation(event);
                        return false;
                    }, this))
                    .bind('keyup', $.proxy(function (event) {
                        if (event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                            this._stopOperation(event);
                            return false;
                        }
                    }, this))
            }

            if (opts.element.state != opts.element.prevState) {
                if (opts.element.state == 'waiting') {
                    this._contentFilter.find('div.searchStart').hide();
                    this._contentFilter.find('div.searchStop').show();
                }
                else {
                    this._contentFilter.find('div.searchStart').show();
                    this._contentFilter.find('div.searchStop').hide();
                }
            }
        },

        _generateNElementsFetchedView: function (opts) {
            if (opts.element.displayedCount >= opts.element.fetchedObjects.length) { return; }
            this._createPage(opts.element.pageIndex);
        },

        _generatePagination: function (opts) {
            var bProcessedCountChanged =
                    (opts.operation.processedCount != opts.element.prevProcessedCount);

            if (opts.element.pagesCount <= 1) {
                this._paginationView.hide();
            }
            if (opts.element.pagesCount > 1) {
                if (!bProcessedCountChanged) { return; }

                // create pagination
                this._paginationView.empty().show();
                this._paginationView.pagination(opts.element.pagesCount, {
                    callback: $.proxy(this._pageSelectCallback, this),
                    items_per_page: 1, // Show only one item per page
                    num_edge_entries: 1,
                    num_display_entries: 5,
                    prev_text: S_PREV,
                    next_text: S_NEXT,
                    current_page: opts.element.pageIndex
                });
            }
            else {
                if (Softerra.Func.GetBool(opts.element.resObj.uResultsCut)) {
                    if (!$('div.pagination').length) {
                        // create fake pagination
                        this._paginationView.show();
                        // generate div for pagination control
                        this._paginationView.empty().data('element', opts.element);
                        // create fake pagination elements
                        var fakePaginElem = $('<div class="pagination clearfix"></div>');
                        this._paginationView.append(fakePaginElem);

                        fakePaginElem.append('<span class="current prev">Prev</span>');
                        fakePaginElem.append('<span class="current">1</span>');

                        var aFetchAll = $('<a tabIndex="0" href="#">' + S_FETCH_ALL_OBJECTS + '</a>').addClass('next');
                        fakePaginElem.append(aFetchAll);

                        aFetchAll.bind('click', { fullSearch: true }, $.proxy(this._searchOperation, this));
                    }
                }
            }
        },

        _generateStatus: function (opts) {
            var bStateChanged = opts.element.state != opts.element.prevState;
            if (opts.element.state == 'waiting') {
                var bProcessedCountChanged =
                    (opts.operation.processedCount != opts.element.prevProcessedCount);
                if (bProcessedCountChanged) {
                    this._statusView.empty();
                    this._statusView.append('<img class="wait imageNormal" src="' + IMG_PATH + IMG_WAIT_SMALL + '" />')
                    this._statusView.append('<img class="wait imageDark" src="' + IMG_PATH + IMG_WAIT_SMALL_DARK + '" />&nbsp;')
                    this._statusView.append(Softerra.Class.StringMgr.Format(S_FETCHED_N_ELEMENTS, opts.operation.processedCount || 0));
                    this._statusView.append('&nbsp;&nbsp;&nbsp;&nbsp;');

                    var stopBtn = $('<a tabIndex="0" href="#">' + S_STOP + '</a>');
                    this._statusView.append(stopBtn);
                    stopBtn.mousedown($.proxy(this._stopOperation, this));
                }
            }
            else if (bStateChanged && opts.element.state == 'generated') {
                this._statusView.empty();
                if (Softerra.Func.GetBool(opts.element.resObj.uResultsCut)) { return; }
                var str = '';
                var procCount = opts.operation.processedCount || 0;
                if (procCount == 1) {
                    str = opts.operation.objectsType == 'members' ? S_ONE_MEMBER_FOUND : S_ONE_GROUP_FOUND;
                }
                else {
                    str = Softerra.Class.StringMgr.Format(
                    opts.operation.objectsType == 'members' ? S_N_MEMBERS_FOUND : S_N_GROUPS_FOUND,
                    procCount);
                }
                this._statusView.append(str);
            }
            else if (bStateChanged && opts.element.state == 'stopped') {
                this._statusView.empty();
                this._statusView.append(S_SEARCH_ABORTED);
            }
        },

        _generateSelectedStatus: function () {
            if (this._isProfileReadonly) {
                return;
            }
            
            // TODO: for new HTML look we need to implement this code or delete it
            return;

            this._selectedStatus.empty();
            if (this._checkedDNs.length <= 0) {
                this._selectedStatus.hide();
            }
            else if (this._checkedDNs.length == 1) {
                this._selectedStatus.append(S_ONE_OBJECT_SELECTED);
                this._selectedStatus.show();
            }
            else {
                this._selectedStatus.append(Softerra.Class.StringMgr.Format(S_N_OBJECTS_SELECTED, this._checkedDNs.length));
                this._selectedStatus.show();
            }
        },

        _generateHeaderCheckboxState: function () {
            if (this._isProfileReadonly) {
                return;
            }

            var checkboxes = this._searchResView.find('.checkObject input:checkbox');
            var lenAll = checkboxes.length;
            var lenChecked = 0;
            var lenDisabled = 0;
            checkboxes.each(function () {
                if ($(this).attr('checked')) { ++lenChecked; }
                if ($(this).attr('disabled')) { ++lenDisabled; }
            });

            if (lenAll != 0 && lenChecked != 0 && lenAll == lenChecked + lenDisabled) {
                this._headerCheckbox.attr('checked', true);
                customCheckSync(this._headerCheckbox);
            }
            else {
                this._headerCheckbox.removeAttr('checked');
                customCheckSync(this._headerCheckbox);
            }
        },

        //////////////////////////////////////////////////////////////////////////
        // event handlers

        _pageSelectCallback: function (page_index, jq) {
            if (this.processingElement.pageIndex == page_index) { return; }

            this.processingElement.pageIndex = page_index;
            this.processingElement.displayedCount = 0;
            this.processingElement.fetchedObjects = [];
            this._searchResView.empty();

            var operation = this._getOperationByElement(this.processingElement);
            this._generateView({ operation: operation, element: this.processingElement });

            return false;
        },

        _stopOperation: function (event) {
            var operation = this._getOperationByElement(this.processingElement);
            if (!operation) { return; }
            try {
                window.external.ContextNode.StopAsyncOperation(operation.operId);
            }
            catch (e) { }
            this.processingElement.state = 'stopped';
            operation.state = 'finished';
            this._enableButtons();
            return false;
        },

        _hideShowTableColumn: function(table, index)
        {
            var rows = table.rows;
            for (var row = 0; row < rows.length; row++) {
                var cols = rows[row].cells;
                if (index >= 0 && index < cols.length) {
                    cols[index].style.display = this._getTypeColumnStyle();
                }
            }
        },

        _getTypeColumnDisaplyStyle: function()
        {
            var style = 'style="display:' + this._getTypeColumnStyle() + '"';
            return style;
        },

        _getTypeColumnStyle: function()
        {
            return !this._typeColumnHidden ? '' : 'none';
        },

        _showTypeColumn: function (show) {
            show = true;
            if (this._typeColumnHidden != show) { return; }
            this._typeColumnHidden = !show;
            var tableContent = document.getElementById(this._getTableContentId());
            var tableHeader = document.getElementById(this._getTableHeaderId());
            var typeColNum = this._getTypeColumnNum(); 
            this._hideShowTableColumn(tableContent, typeColNum);
            this._hideShowTableColumn(tableHeader, typeColNum);
        },

        _searchOperation: function (event) {
            this._stopOperation(event);
            this.processingElement.state = 'idle';
            this.processingElement.prevState = 'idle';
            this.processingElement.displayedCount = 0;
            this.processingElement.pageIndex = 0;
            this.processingElement.fetchedObjects = [];

            this._checkedDNs = [];

            this._removeOperation(this.processingElement.objectsType);
            this._searchResView.empty();
            this._processOneElement(event.data.fullSearch);

            return false;
        },

        _addObjects: function () {
            var operationName = this.processingElement.objectsType == 'members' ?
                'AddMembers' : 'AddGroups';
            var operation = this._getOperationByElement(this.processingElement);

            var params = {};
            params.uOperationId = operation.operId;

            var addOperState = '';

            try {
                window.external.ContextNode.SyncOperation(operationName, $.toJSON(params), 0);
              
               }
            catch (e) { return; }

        },

        _removeObjects: function () {
            if (!this._checkedDNs || !this._checkedDNs.length) {
                return;
            }

            var params = {};
            var operation = this._getOperationByElement(this.processingElement);
            params.uOperationId = operation.operId;
            params.uDirectMode = true;
            params.uDNs = this._checkedDNs;

            var operationName = this.processingElement.objectsType == 'members' ?
                'RemoveMembers' : 'RemoveGroups';

            try {
                window.external.ContextNode.SyncOperation(operationName, $.toJSON(params), 0);
            }
            catch (e) { return; }
        },

        _exportObjects: function () {
            var params = {};
            var operationName = this.processingElement.objectsType == 'members' ?
                'ExportMembers' : 'ExportGroups';

            var exportOperId = 0;
            try {
                window.external.ContextNode.SyncOperation(operationName, $.toJSON(params), 0);
            }
            catch (e) { return; }

        },

        _modifyDynamicMembership: function() {
            var params = {};
            var operationName = 'ModifyDynamicMembership';
            try {
                window.external.ContextNode.SyncOperation(operationName, $.toJSON(params), 0);
            }
            catch (e) { return; }
        },        

        _importObjects: function () {
            var params = {};
            var operationName = this.processingElement.objectsType == 'members' ?
                'ImportMembers' : 'ImportGroups';

            try {
                window.external.ContextNode.SyncOperation(operationName, $.toJSON(params), 0);
            }
            catch (e) { return; }
        },

        _headerCheckboxClick: function (event) {
            var self = this;
            var checkAllState = $(event.target).attr('checked');
            customCheckSync($(event.target));
            this._searchResView.find('.checkObject input[type=checkbox]').each(function () {
                if ($(this).attr('checked') != checkAllState && $(this).attr('disabled') != true) {
                    if (checkAllState) {
                        $(this).attr('checked', true);
                        self._checkDN($(this).val());
                        customCheckSync($(this));
                    }
                    else {
                        $(this).removeAttr('checked');
                        self._uncheckDN($(this).val());
                        customCheckSync($(this));
                    }
                }
            });
            this._generateSelectedStatus();
        },

        //////////////////////////////////////////////////////////////////////////
        // Other

        _appendManageButton: function (elemAppendTo, opts) {
            elemAppendTo.empty();

            // append add/remove button if profile isn't readonly
            if (this._isProfileReadonly == false && this._canShowAddRemoveButtons(opts.operation.objectsType)) {
                this.addObjectsButton = $('<button tabIndex="0">').text(S_ADD).click($.proxy(this._addObjects, this));
                this.addObjectsButton.wrap('<span class="themedButton"></span>');
                this.addObjectsButton.parent().prepend($('<span class="themedButtonText"></span>').text(S_ADD));

                this.removeObjectsButton = $('<button tabIndex="0">').text(S_REMOVE).click($.proxy(this._removeObjects, this));
                this.removeObjectsButton.wrap('<span class="themedButton"></span>');
                this.removeObjectsButton.parent().prepend($('<span class="themedButtonText"></span>').text(S_REMOVE));

                this.addObjectsButton.addClass('m2gManageBtn_' + uiManager.Lang());
                this.addObjectsButton.addClass('m2gAddRemoveButton');
                this.addObjectsButton.parent().css("float","left");

                this.removeObjectsButton.addClass('m2gManageBtn_' + uiManager.Lang());
                this.removeObjectsButton.addClass('m2gAddRemoveButton');
                this.removeObjectsButton.parent().css("float","left");

                elemAppendTo.append(this.addObjectsButton.parent());
                elemAppendTo.append(this.removeObjectsButton.parent());
                this.removeObjectsButton.attr('disabled', 'disabled');
                customButtonSync(this.removeObjectsButton);
            }

            // Add modify dynamic membership button
            if (this._isDynamicGroup && this._isProfileReadonly == false && opts.operation.objectsType == 'members')
            {
                this.modifyDynamicMembership = $('<button tabIndex="0">').text(S_MODIFY_DYNAMIC_MEMBERSHIP).click($.proxy(this._modifyDynamicMembership, this));
                this.modifyDynamicMembership.wrap('<span class="themedButton"></span>');
                this.modifyDynamicMembership.parent().prepend($('<span class="themedButtonText"></span>').text(S_MODIFY_DYNAMIC_MEMBERSHIP));

                this.modifyDynamicMembership.addClass('m2gManageBtn_' + uiManager.Lang());
                this.modifyDynamicMembership.addClass('m2gAddRemoveButton');
                this.modifyDynamicMembership.parent().css("float","left");
                this.modifyDynamicMembership.css("width",(uiManager.Lang() == 'deu') ? '165pt' : '150pt');
                elemAppendTo.append(this.modifyDynamicMembership.parent());
            }

            // Add import button
            if (this._isProfileReadonly == false && this._canShowAddRemoveButtons(opts.operation.objectsType)) 
            {
                this.importObjectsButton = $('<button tabIndex="0">').text(S_IMPORT).click($.proxy(this._importObjects, this));
                this.importObjectsButton.wrap('<span class="themedButton"></span>');
                this.importObjectsButton.parent().prepend($('<span class="themedButtonText"></span>').text(S_IMPORT));

                this.importObjectsButton.addClass('m2gManageBtn_' + uiManager.Lang());
                this.importObjectsButton.addClass('m2gImportExport');
                this.importObjectsButton.parent().css("float","right");
                this.importObjectsButton.css("margin-right","0pt");
                elemAppendTo.append(this.importObjectsButton.parent());
            }
            
            this.exportObjectsButton = $('<button tabIndex="0">').text(S_EXPORT).click($.proxy(this._exportObjects, this));
            this.exportObjectsButton.wrap('<span class="themedButton"></span>');
            this.exportObjectsButton.parent().prepend($('<span class="themedButtonText"></span>').text(S_EXPORT));

            this.exportObjectsButton.addClass('m2gManageBtn_' + uiManager.Lang());
            this.exportObjectsButton.addClass('m2gImportExport');
            this.exportObjectsButton.parent().css("float","right");
            elemAppendTo.append(this.exportObjectsButton.parent());

        },

        _removeOperation: function (objectsType) {
            for (var i = 0; i < $.fn.groupmembership._startedOperations.length; ++i) {
                if ($.fn.groupmembership._startedOperations[i].objectsType != objectsType) { continue; }
                $.fn.groupmembership._startedOperations.splice(i, 1);
                break;
            }
        },

        _createPage: function (pageIndex) {
            var operation = this._getOperationByElement(this.processingElement);
            if (!operation) { return; }

            var OnClickFindDN = function (event) {
                try {
                    var dn = $(event.target).data("clickData");
                    window.external.ContextNode.SyncOperation("FindDN", dn, 0);
                }
                catch (e) { }

                return false;
            }

            var tableContent = this._searchResView.find('table.content');
            if (!tableContent.length) {
                // create table with data
                tableContent = $('<table id="' + this._getTableContentId() + '" class="content">');
                this._searchResView.append(tableContent);
            }

            for (var i = this.processingElement.displayedCount;
                i < this.processingElement.fetchedObjects.length; ++i) {

                var tr = $('<tr>');
                tableContent.append(tr);

                // checkbox
                if (!this._isProfileReadonly) {
                    var tdRemIcon = $('<td>').addClass('checkObject');
                    tr.append(tdRemIcon);               
                    var chbxRem = $('<input type="checkbox" name="" value="">');
                    chbxRem.wrap("<span class='themedCheckbox'></span>");
                    chbxRem.val(this.processingElement.fetchedObjects[i].uDN);
                    if (this._isDNChecked(this.processingElement.fetchedObjects[i].uDN)) {
                        chbxRem.attr('checked', 'checked');
                        chbxRem.parent().addClass("selected");
                    }
                    if (!Softerra.Func.GetBool(this.processingElement.fetchedObjects[i].uRemovable)) {
                        chbxRem.attr('disabled', 'true');
                        chbxRem.parent().addClass("disabled");
                    }
                    
                    tdRemIcon.append(chbxRem.parent());
                    chbxRem.bind('click', $.proxy(function (event) {
                        customCheckSync($(event.target));
                        if ($(event.target).attr('checked')) {
                            this._checkDN($(event.target).val());
                        }
                        else {
                            this._uncheckDN($(event.target).val());
                        }
                        this._generateSelectedStatus();
                        this._generateHeaderCheckboxState();
                    }, this));
                }

                // object icon
                var tdIcon = $('<td>').addClass('objectIcon');
                tr.append(tdIcon);
                var imgClass = '';
                if (dpiScaleFactor * 16 >= 24) { imgClass = 'class="dpiScaleHalf" '; }
                if (this.processingElement.fetchedObjects[i].uIcon) {
                    tdIcon.append('<img ' + imgClass + 'src="' + this.processingElement.fetchedObjects[i].uIcon + '"/>');
                }

                // object name
                var tdName = $('<td>').addClass('name');
                tr.append(tdName);
                var a = $('<a tabIndex="0" href="#">' + Softerra.Class.StringMgr.EscapeForHtml(this.processingElement.fetchedObjects[i].uDispVal) + '</a>').attr('title', this.processingElement.fetchedObjects[i].uDispVal);
                a.addClass(this.processingElement.fetchedObjects[i].uMemberType);
                tdName.append(a);
                a.data("clickData", this.processingElement.fetchedObjects[i].uDN);
                a.click(OnClickFindDN);

                // object type, if it is a dynamic group object
                var tdType = $('<td ' + this._getTypeColumnDisaplyStyle() + '>').addClass('type');
                tr.append(tdType);
                var s = $('<span tabIndex="0">' + Softerra.Class.StringMgr.EscapeForHtml(this.processingElement.fetchedObjects[i].uMemberType) + '</span>').attr('title', this.processingElement.fetchedObjects[i].uMemberType);
                tdType.append(s);
                
                
                // object's parent DN
                var tdParent = $('<td>').addClass('parent');
                tr.append(tdParent);
                var a = $('<a tabIndex="0" href="#">' + this.processingElement.fetchedObjects[i].uParentDN + '</a>').attr('title', this.processingElement.fetchedObjects[i].uParentDN);
                tdParent.append(a);
                a.data("clickData", this.processingElement.fetchedObjects[i].uParentDN);
                a.click(OnClickFindDN);
            }

            this.processingElement.displayedCount = this.processingElement.fetchedObjects.length;
        },

        _getOperationByElement: function (elem) {
            for (var i = 0; i < $.fn.groupmembership._startedOperations.length; ++i) {
                var oper = $.fn.groupmembership._startedOperations[i];
                if (this.processingElement.objectsType == oper.objectsType) {
                    return oper;
                }
            }
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });

    $.fn.groupmembership._startedOperations = [];
    $.fn.groupmembership._checkEnumOperTimeout = 300;
    $.fn.groupmembership._waitBeforeShowTimeout = 0;
    $.fn.groupmembership._staticInited = true;

})(jQuery);