/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {
    $.widget("ui.photo", {
        options: {
            maxWidth: 112,
            maxHeight: 112,
            defaultPhoto: "",
            useDefaultPhoto: true
        },

        _create: function () {
            this._initPhoto();
        },

        // initialize widget depend on element's type. If image - simply restricts width and height.
        // if input element - then parse attribute information, show image, create manage buttons
        _initPhoto: function () {
            var nodeName = this.element[0].nodeName.toLowerCase();

            if (nodeName == 'img') {
                this.imageElem = this.element;
                this._processImageElem();
            }
            else if (nodeName == 'input') {
                //For modifyable user icon set width = 90
                this.options.maxWidth = 90;
                // fetch jsonObject
                if (!this.options.jsonObject) {
                    try {
                        this.options.jsonObject = $.parseJSON(this.element.attr("value"));
                    }
                    catch (e) { this.options.jsonObject = {}; }
                    if (!this.options.jsonObject) { return; }
                }

                // wrap
                var wrapId = NextId();
                var wrapContentStr = '<div id="' + wrapId + '" class="ldapPhotoDiv"></div>';
                this.element.before(wrapContentStr);

                this.wrapContent = $('#' + wrapId);
                var _thisElem = this.element.detach();
                this.wrapContent.append(_thisElem);

                // use only first value
                var photoPath = '';
                if (this.options.jsonObject.uValsCount) {
                    photoPath = this.options.jsonObject.uLinkValues[0];
                }

                var imgWrapId = NextId();
                var imgId = NextId();

                // table is used for correct vertical image alignment
                this.wrapContent.append('<table class="imgWrapTable" id="' + imgWrapId + '"><tr><td><img class="imageNormal" id="' + imgId + '" src="' + photoPath + '" /><img class="imageDark" id="' + imgId + 'Dark" src="' + photoPath + '" /></td></tr></table>');
                this.imageElem = $('#' + imgId);
                this.imageElemDark = $('#' + imgId + "Dark");
                // restrict container's width and height
                $('#' + imgWrapId).height(this.options.maxHeight).width(this.options.maxWidth);
                this._processImageElem();

                if (uiManager.IsProfileReadonly()) {
                    return;
                }
                // create buttons for managing photo
                this._createChangeableModeControls();
                this.wrapContent
                    .bind('mouseenter', $.proxy(this._hoverOn, this))
                    .bind('mouseleave', $.proxy(this._hoverOff, this));
                this._initAddChangeRemoveButtons();
                this.switchedMode = 'ViewMode';
            }
            else {
                // do nothing
            }
        },

        reinit: function () {
            this._initPhoto();
        },

        // shows or hides manage buttons
        turnMode: function (requiredMode) {
            if (requiredMode == this.switchedMode) { return; }

            this.switchedMode = requiredMode;

            if (requiredMode == 'ViewMode') {
                if (this.editMode) { this._cancelChanges(); }
                this.divAddChangeRemoveBtns.hide();
            }
            else if (requiredMode == 'EditMode') {
                if (this.editMode) { return; }
                this.divAddChangeRemoveBtns.show();
            }
            else {
                // do nothing
            }
        },

        // sets default photo if no photo presents, loads photo and call resizing method after 
        // load is finished
        _processImageElem: function () {
            if (!this.imageElem) { return; }
            this.imageElem.removeAttr('height');
            this.imageElem.removeAttr('width');
            if (this.imageElemDark) {
                this.imageElemDark.removeAttr('height');
                this.imageElemDark.removeAttr('width');
            }

            if (this.options.useDefaultPhoto) {
                if (!this.options.defaultImage) {
                    this.options.defaultImage = (IMG_PATH && IMG_PERSON_DEFAULT_PHOTO) ?
                        IMG_PATH + IMG_PERSON_DEFAULT_PHOTO : "";
                }
                if (!this.options.defaultImageDark) {
                    this.options.defaultImageDark = (IMG_PATH && IMG_PERSON_DEFAULT_PHOTO_DARK) ?
                        IMG_PATH + IMG_PERSON_DEFAULT_PHOTO_DARK : "";
                }

                if (this.imageElem.attr("src") == '') {
                    this.imageElem.attr('src', this.options.defaultImage);
                }
                if (this.imageElemDark && this.imageElemDark.attr("src") == '') {
                    this.imageElemDark.attr('src', this.options.defaultImageDark);
                }
            }

            var self = this;

            var rawElement = this.imageElem.first().get(0);
            // if photo is already loaded call resize
            if (this.imageElem.attr("src") != '' && rawElement.readyState == 'complete') {
                this._resize(true);
                return;
            }
            // else load it and call resize onload event
            else {
                var src = this.imageElem.attr('src');
                this.imageElem.removeAttr("src");

                var objImage = $('<img src="' + src + '">');
                objImage.bind('load', $.proxy(function () {
                    this.imageElem.attr('src', objImage.attr('src'));
                    this._resize();
                }, this));
            }
        },

        _createChangeableModeControls: function () {
            if (!this.divBelowPhoto) {
                this.divBelowPhoto = $('<div></div>');
                this.wrapContent.append(this.divBelowPhoto);
            }

            if (!this.divAddChangeRemoveBtns) {
                this.divAddChangeRemoveBtns = $('<div class="handlePhotoBtns handlePhotoBtns_' + LANGUAGE + '"></div>');
                this.divAddChangeRemoveBtns.hide();
                this.divBelowPhoto.append(this.divAddChangeRemoveBtns);
            }

            if (!this.saveCancelBtns) {
                this.saveCancelBtns = $('<div class="saveCancelBtns saveCancelBtns_' + LANGUAGE + '"></div>');
                this.saveCancelBtns.hide();
                this.divBelowPhoto.append(this.saveCancelBtns);
            }

            return;
        },

        _initAddChangeRemoveButtons: function () {
            this.divAddChangeRemoveBtns.empty();
            if (!this.options.jsonObject.uValsCount) {
                // add button
                this.addPhotoBtn = $('<a class="button addPhotoBtn addPhotoBtn_' + LANGUAGE + '">' + S_ADD_PHOTO + '</a>').click($.proxy(this._addPhoto, this));
                this.divAddChangeRemoveBtns.append(this.addPhotoBtn);
            }
            else {
                // change button
                this.changePhotoBtn = $('<a class="button changePhotoBtn">' + S_CHANGE + '</a>').click($.proxy(this._changePhoto, this));
                this.divAddChangeRemoveBtns.append(this.changePhotoBtn);

                // remove button
                this.removePhotoBtn = $('<a class="button removePhotoBtn">' + S_DELETE + '</a>').click($.proxy(this._removePhoto, this));
                this.divAddChangeRemoveBtns.append(this.removePhotoBtn);
            }
        },

        _resize: function () {
            if (this.imageElem.attr("width") > this.options.maxWidth) {
                this.imageElem.attr("width", this.options.maxWidth);
            }

            if (this.imageElem.attr("height") > this.options.maxHeight) {
                var ratio = this.options.maxHeight / this.imageElem.attr("height");
                var oldW = this.imageElem.attr("width");
                this.imageElem.attr("height", this.options.maxHeight);
                this.imageElem.attr("width", oldW * ratio);
            }

            if (this.imageElemDark)
            {
                if (this.imageElemDark.attr("width") > this.options.maxWidth) {
                    this.imageElemDark.attr("width", this.options.maxWidth);
                }

                if (this.imageElemDark.attr("height") > this.options.maxHeight) {
                    var ratio = this.options.maxHeight / this.imageElemDark.attr("height");
                    var oldW = this.imageElemDark.attr("width");
                    this.imageElemDark.attr("height", this.options.maxHeight);
                    this.imageElemDark.attr("width", oldW * ratio);
                }
            }
        },

        _selectFile: function () {
            var inputFile = $('<input type="file" />');
            inputFile.click();
            return inputFile.val();
        },

        _showSaveCancelBtns: function () {
            this.divAddChangeRemoveBtns.hide();
            this.saveCancelBtns.show();

            if (!this.saveBtn) {
                this.saveBtn = $('<a class="button changePhotoSave">' + S_ABUTTON_SAVE_ABBR + '</a>').click($.proxy(this._saveChanges, this));
                this.saveCancelBtns.append(this.saveBtn);
            }

            if (!this.cancelBtn) {
                this.cancelBtn = $('<a class="button changePhotoCancel">' + S_ABUTTON_CANCEL_ABBR + '</a>').click($.proxy(this._cancelChanges, this));
                this.saveCancelBtns.append(this.cancelBtn);
            }

            this.editMode = true;
        },

        _hideSaveCancelBtns: function () {
            this.saveCancelBtns.hide();
            if (this.isHovered || this.switchedMode == 'EditMode') {
                this.divAddChangeRemoveBtns.show();
            }
            this.editMode = false;
        },

        //////////////////////////////////////////////////////////////////////////
        // event handlers

        _hoverOn: function (e) {
            this.isHovered = true;
            if (this.editMode || this.switchedMode == 'EditMode') {
                return;
            }
            this.divAddChangeRemoveBtns.show();
        },

        _hoverOff: function (e) {
            this.isHovered = false;
            if (this.editMode || this.switchedMode == 'EditMode') {
                return;
            }
            this.divAddChangeRemoveBtns.hide();
        },

        _addPhoto: function (e) {
            this._changePhoto(e);
        },

        _changePhoto: function (e) {
            var newFileName = this._selectFile();
            if (!newFileName) { return; }

            var croppedImgFile;
            var fCropFinished = function (croppedImg) {
                // set cropped image 
                this.previousImg = this.imageElem.attr('src');
                if (this.imageElemDark) { this.previousImgDark = this.imageElemDark.attr('src'); }
                this.imageElem.attr('src', croppedImg || newFileName);
                if (this.imageElemDark) { this.imageElem.attr('src', croppedImg || newFileName); }
                this.newFileName = croppedImg || newFileName;
                // resize selected photo
                this._processImageElem();
                this._saveChanges();
            }

            // here could be implemented cropping image mechanism

            fCropFinished.call(this);
        },

        _removePhoto: function (e) {
            this.previousImg = this.imageElem.attr('src');
            if (this.imageElemDark) { this.previousImgDark = this.imageElemDark.attr('src'); }
            this.imageElem.attr('src', this.options.defaultImage);
            if (this.imageElemDark) { this.imageElemDark.attr('src', this.options.defaultImageDark); }
            // resize default image
            this._processImageElem();
            this.photoRemoved = true;

            this._showSaveCancelBtns();
        },

        // 2 modes - photo could be changed(or added) or removed
        _saveChanges: function () {
            var uValues = [];
            if (!this.photoRemoved) {
                var filePath = this.newFileName;
                if (filePath.substring(0, 'file://'.length) != 'file://') {
                    filePath = 'file://' + filePath;
                }
                uValues.push(filePath);
            }

            if (this.options.jsonObject.uValsCount > 1) {
                for (var i = 1; i < this.options.jsonObject.uValsCount; ++i) {
                    uValues.push(this.options.jsonObject.uLinkValues[i]);
                }
            }

            var proc = Softerra.Class.ProcessorsMgr.GetProcessor(this.options.jsonObject);
            var outObj = { uValues: uValues, uEncFlags: proc.GetEncodingFlag() };
            outObj.uType = this.options.jsonObject.uType;

            var modifications = [];
            modifications.push(outObj);

            var modifyRequest = { refreshNode: false, uModifications: modifications };

            var operId;
            try {
                var operId = window.external.ContextNode.BeginAsyncOperation("Modify", $.toJSON(modifyRequest), 0);
            }
            catch (e) { }

            var SaveFinished = function () {
                try {
                    return window.external.ContextNode.FinishedAsyncOperation(operId);
                }
                catch (e) { return false; }
            }

            if (!operId) {
                alert(S_OPERATION_FAILED);
                return;
            }

            // unblocking means that operation had been failed or finished
            var fOnUnblock = function () {
                var operationResult = window.external.ContextNode.EndAsyncOperation(operId, null);
                if (operationResult == 0) {
                    // success
                    this.options.jsonObject.uLinkValues = uValues;
                    this.options.jsonObject.uValsCount = uValues.length;
                    var newSrc = '';
                    if (this.options.jsonObject.uLinkValues.length) {
                        newSrc = this.options.jsonObject.uLinkValues[0];
                    }
                    this.imageElem.removeAttr('height');
                    this.imageElem.removeAttr('width');
                    this.imageElem.attr('src', newSrc);
                    if (this.imageElemDark)
                    {
                        this.imageElemDark.removeAttr('height');
                        this.imageElemDark.removeAttr('width');
                        this.imageElemDark.attr('src', newSrc);
                    }

                    this._processImageElem();
                    this._createChangeableModeControls();
                }
                else {
                    this._cancelChanges();
                }

                this._hideSaveCancelBtns();
                this._initAddChangeRemoveButtons();
                this.photoRemoved = false;
            }
            // block UI and show saving text
            var bgColor = $("html").css("background-color");
            if ('transparent' == bgColor) { bgColor = 'White'; }
            Softerra.Func.ShowWaitingPage({ backgroundColor: bgColor, interval: 100, fCond: SaveFinished,
                text: S_SAVING, unblockFunc: fOnUnblock, unblockFuncContext: this
            });
        },

        _cancelChanges: function () {
            this.imageElem.attr('src', this.previousImg);
            if (this.imageElemDark) { this.imageElemDark.attr('src', this.previousImgDark); }
            this._processImageElem();
            this._hideSaveCancelBtns();
            this.photoRemoved = false;
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);