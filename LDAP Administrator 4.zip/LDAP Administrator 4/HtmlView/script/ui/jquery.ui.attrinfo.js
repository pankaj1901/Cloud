/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {

    $.widget("ui.attrinfo", {
        options: {
            uiManager: null,
            jsonObject: null, // information about attribute
            wrapContent: null,
            saveCancelButtons: null,
            generatedContent: {
                ViewMode: null,
                EditMode: null,
                ViewModeTable: null, // table with attribute's values
                EditModeTable: null
            },
            isModeGenerated: {
                ViewMode: false,
                EditMode: false
            },
            isInlineModifyTurnedOn: false,
            displayedMode: undefined,
            switchedMode: undefined,
            isVisible: true,
            ViewModeEventHandler: null,
            EditModeEventHandler: null,
            inited: false
        },

        _create: function () {
            var self = this;

            // wrap
            var wrapId = NextId();
            var viewModeContentId = NextId();
            var editModeContentId = NextId();

            var wrapContent = new StringBuilder();
            wrapContent.append('<div id="' + wrapId + '" class="ldapAttrInfoDiv">');

            wrapContent.append('<div id="' + viewModeContentId + '"></div>');
            wrapContent.append('<div id="' + editModeContentId + '"></div>');

            wrapContent.append('</div>');

            var _parent = this.element.parent();
            var _thisElem = this.element.detach();
            _parent.html(wrapContent.toString());

            self.options.wrapContent = $('#' + wrapId);
            self.options.wrapContent.append(_thisElem);
            self.options.generatedContent['ViewMode'] = $('#' + viewModeContentId);
            self.options.generatedContent['EditMode'] = $('#' + editModeContentId);

            // fetch jsonObject
            if (!this.options.jsonObject) {
                try {
                    this.options.jsonObject =
                    DataStoreManager.Data(this.element.attr('id'), 'jsonObject') ||
                    $.parseJSON(this.element.attr("value"));
                }
                catch (e) { this.options.jsonObject = {}; }
                if (!this.options.jsonObject) { return; }
                this._genAttrAdditionalFields(this.options.jsonObject);
                this.proc = Softerra.Class.ProcessorsMgr.GetProcessor(this.options.jsonObject);
                if (!this.proc) { return; }
            }

            // create common handlers that will bind to all events in widget and call handlers 
            // that are subscribed for concrete event types.
            this.options.ViewModeEventHandler = new CommonEventHandler();
            this.options.EditModeEventHandler = new CommonEventHandler();

            this.options.inited = true;
        },

        switchMode: function (opts) {
            if (!this.options.inited) { return; }
            if (this.options.switchedMode == "ViewMode") {
                this.turnMode('EditMode', opts);
                return;
            }
            if (this.options.switchedMode == "EditMode") {
                this.turnMode('ViewMode', opts);
                return;
            }
        },

        turnMode: function (requiredMode, opts) {
            if (!this.options.inited) { return; }
            var self = this;

            var turnModeImplFunc = function () {
                // set default options if not set by caller
                opts = (opts && opts.constructor == Object) ? opts : {};
                opts.clearEditModeContent = (opts.clearEditModeContent != undefined) ? opts.clearEditModeContent : true;
                opts.clearViewModeContent = (opts.clearViewModeContent != undefined) ? opts.clearViewModeContent : true;
                opts.turnDisplayedMode = (opts.turnDisplayedMode != undefined) ? opts.turnDisplayedMode : true;
                opts.operation = opts.operation || '';
                opts.globalSwitchMode = (opts.globalSwitchMode != undefined) ? opts.globalSwitchMode : false;

                if (!self.options.jsonObject.readonly && self.element.parent().parents('.shortInfo2').length > 0) {
                    self.options.jsonObject.readonly = true;
                }

                // clear view mode and edit mode content
                if (opts.clearEditModeContent) {
                    self.clearGeneratedMode('EditMode');
                }
                if (opts.clearViewModeContent) {
                    if (self.options.jsonObject.readonly && self.options.switchedMode == 'ViewMode') {
                        return;
                    }
                    self.clearGeneratedMode('ViewMode');
                }

                // generate and show required mode and hide another one
                var hiddenElement;
                if (requiredMode == 'ViewMode') {
                    hiddenElement = self.options.generatedContent['EditMode'];
                    hiddenElement.css('visibility', 'hidden');

                    self.options.generatedContent['ViewMode'].show();
                    self._generateElement('ViewMode');
                    self.options.displayedMode = 'ViewMode';
                    self._hideSaveCancelButtons();
                }
                else {
                    if (self.options.jsonObject.readonly) { return; }

                    if (opts.turnDisplayedMode) {
                        self._selectAttributeOnEdit();

                        hiddenElement = self.options.generatedContent['ViewMode'];
                        hiddenElement.css('visibility', 'hidden');

                        self.options.generatedContent['EditMode'].show();
                        self._generateElement('EditMode');
                        self.options.displayedMode = 'EditMode';
                    }
                    else {
                        // here we need to generate both view and edit modes. We show view mode
                        // but show also save/cancel buttons and synchronize view and edit mode tables
                        // (because modified values are gotten from edit mode)

                        self._generateElement('EditMode');
                        self._generateElement('ViewMode');

                        hiddenElement = self.options.generatedContent['EditMode'];
                        hiddenElement.css('visibility', 'hidden');
                        
                        self.options.generatedContent['ViewMode'].show();
                        self.options.displayedMode = 'ViewMode';
                    }

                    // delete button can be invisible only if values count == 1 and value is empty
                    if (self.options.jsonObject.uValsCount <= 1) {
                        self._manageDeleteButtonsVisibility();
                    }

                    // hide or show inline save/cancel buttons depend on global edit state
                    if (self.options.uiManager.IsGlobalEditTurnedOn()) {
                        self._hideSaveCancelButtons();
                    }
                    else {
                        self._showSaveCancelButtons();
                    }
                }

                self.options.switchedMode = requiredMode;

                // change element's state and notify event handler about this
                if (!opts.globalSwitchMode && self.options.uiManager.IsPageInited()) {
                    var oldVal = self.options.isInlineModifyTurnedOn;
                    self.options.isInlineModifyTurnedOn = (requiredMode == 'EditMode');
                    if (oldVal != self.options.isInlineModifyTurnedOn) {
                        self._trigger('inlineModifyTurned', null,
                            { notifier: 'attrinfo', state: self.options.isInlineModifyTurnedOn, element: self.element });
                    }
                }

                if (hiddenElement) {
                   hiddenElement.hide().css('visibility', 'visible');
                }
            }

            this.proc.BeforeSwitchingModes(requiredMode, this.options.displayedMode, this.options.generatedContent[this.options.displayedMode]);
            turnModeImplFunc();
            this.proc.AfterSwitchingModes(this.options.displayedMode,this.options.generatedContent[requiredMode]);
            return;
        },

        _updateShortInfoUnorderedListsStyles: function(unorderedList) {
            var unorderedLists = unorderedList.parent().find('ul');
            var bFirstVisibleFound = false;
            for (var i = 0; i < unorderedLists.length; i++) {
                var ul = $(unorderedLists[i]);
                if (!bFirstVisibleFound) {
                    if (ul.is(':visible')) {
                        bFirstVisibleFound = true;
                        ul.addClass('first');
                        ul.removeClass('notfirst');
                    }   
                    else {
                        continue;
                    }
                } 
                else {
                    ul.removeClass('first');
                    ul.addClass('notfirst');
                }
            }
        },

       _generateViewMode: function (elemAppendTo) {
            var currAttr = this.options.jsonObject;
            var iterCount = currAttr.uValsCount || 0;
            var self = this;

            var resultContent = new StringBuilder();

            var unprocessedCount = 0;

            var fGenerateTDModifControls = function () {
                // generate TD with add, edit, delete buttons
                var tdModifControls = new StringBuilder();
                tdModifControls.append('<td class="');
                tdModifControls.append('valModifButtonsAddEditDel_' + uiManager.Lang());
                if (currAttr.firstonly) {
                    tdModifControls.append(' valModifButtonsEdit_' + uiManager.Lang());
                }
                tdModifControls.append('">');
                tdModifControls.append(self._generateViewModeButtons(elemAppendTo));
                tdModifControls.append('</td>');
                return tdModifControls.toString();
            }

            var currentTH = elemAppendTo.parents('tr').find('th');
            if (iterCount > 1) {
                currentTH.addClass('multivalued');
            }

            var tableId = NextId();

            if (iterCount == 0) {
                // view mode table with empty row
                resultContent.append('<table cellspacing="0" id="' + tableId + '" class="viewValues valsTable">');
                var trId = NextId();
                resultContent.append('<tr id="' + trId + '" class="val lastVal">');

                var tdId = NextId();
                resultContent.append('<td class="valSpacing"></td>');
                resultContent.append('<td id="' + tdId + '" class="val" valign="top"');
                if (currAttr.firstonly) {
                    resultContent.append('title="' + currAttr.uFriendName ? currAttr.uFriendName : currAttr.uType + '"');
                }
                resultContent.append('>'); //td
                resultContent.append('&nbsp;');
                resultContent.append('</td>');
                resultContent.append(fGenerateTDModifControls());
                resultContent.append('</tr>');
                resultContent.append('</table>');

                if (elemAppendTo.parents(".shortInfo2").length > 0) {
                    elemAppendTo.parents("li").hide();
                    var ulElement = elemAppendTo.parents("ul");
                    var listItems = ulElement.find('li');
                    var bAllHidden = true;
                    for (var i = listItems.length - 1; i >= 0; i--) {
                        if ($(listItems[i]).is(':visible')) {
                            bAllHidden = false;
                            break;
                        }
                    }
                    if (bAllHidden && ulElement.is(':visible')) {
                        ulElement.hide();
                        this._updateShortInfoUnorderedListsStyles(ulElement);
                    }
                }
            }
            else {
                resultContent.append('<table cellspacing="0" id="' + tableId + '" class="viewValues valsTable">');
                var iEnd = currAttr.firstonly ? 1 : iterCount;

                var fGenTR = function (_from, _to) {
                    var result = new StringBuilder();
                    for (var i = _from; i < _to; i++) {
                        var trId = NextId();
                        if (i == (iterCount - 1)) {
                            result.append('<tr id="' + trId + '" valign="bottom" class="val lastVal lastRow ' + 'valModifButtonsAddEditDel_' + uiManager.Lang() + '">');
                        }
                        else {
                            result.append('<tr id="' + trId + '" class="val" valueIndex="' + i + '">');
                        }
                        result.append('<td class="valSpacing"></td>');
                        result.append('<td class="val"');

                        //add title
                        if (currAttr.firstonly) {
                            result.append(' title="' + Softerra.Class.StringMgr.EscapeForAttrValue(currAttr.uFriendName ?
                                currAttr.uFriendName : currAttr.uType) + '"');
                        }
                        else {
                            result.append(' title="' + Softerra.Class.StringMgr.EscapeForAttrValue(self.proc.GetViewValue(currAttr, i)) + '"');
                        }
                        result.append('>');
                        result.append(self.proc.GenViewElem(self.element, i));
                        result.append('</td>');

                        // add TD with inline buttons
                        if (!currAttr.readonly) {
                            result.append(fGenerateTDModifControls());
                        }
                        else {
                            result.append('<td class="valModifButtonsAddEditDel_' + uiManager.Lang() + '"></td>');
                        }
                        result.append('</tr>');
                    }
                    return result.toString();
                }

                resultContent.append(fGenTR(0, iEnd));
                resultContent.append('</table>');

                if (elemAppendTo.parents(".shortInfo2").length > 0) {
                    var ulElement = elemAppendTo.parents("ul");
                    var isUlVisible = ulElement.is(':visible');
                    if (!isUlVisible) {
                        ulElement.show();
                    }
                    if (!isUlVisible || ulElement.find('li').length == 1) {
                        this._updateShortInfoUnorderedListsStyles(ulElement);
                    }

                    if (ulElement) {
                        ulElement.addClass('leftBorder');    
                    }
                }
            }

            elemAppendTo.html(resultContent.toString());
            this.options.generatedContent.ViewModeTable = $(document.getElementById(tableId));
            
            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
            PostponedBindsManager.PerformBinds();
            this.options.ViewModeEventHandler.bindHandlers(elemAppendTo);

            if (elemAppendTo.find('div.flagSet').length > 0) {
                currentTH.addClass('multivalued');                
            }

            // bind hoverOn and hoverOff handlers
            if (!this.options.uiManager.IsProfileReadonly()) {
                elemAppendTo.find('table.viewValues')
                .bind('mouseleave', $.proxy(this._viewValuesTableHoverOff, this))
                .bind('mousemove', $.proxy(this._onViewValueMouseMove, this));
            }

            this.options.isModeGenerated['ViewMode'] = true;
        },

        _generateEditMode: function (elemAppendTo) {
            var currAttr = this.options.jsonObject;
            var elem = this.element;

            // do nothing if attribute is readonly
            if (currAttr.readonly) { return; }

            var valsCount = currAttr.uValsCount || 0;
           
            // create table for edit values
            var resultContent = new StringBuilder();

            var tableId = NextId();

            resultContent.append('<table cellspacing="0" id="' + tableId + '" class="editValues valsTable">');
            if (valsCount) {
                // if values count != 0 - add them to table
                var iEnd = currAttr.firstonly ? 1 : valsCount;
                for (var i = 0; i < iEnd; i++) {
                    resultContent.append(this._addEditRowTemplate(i));
                }
            }
            else {
                if (this.proc.AddValueAfterLastDeleted()) {
                    // if no values present - create edit mode element by default or get value from custom editor
                    resultContent.append(this._addValueImpl(false));
                }                                                                                                       
                else {
                    resultContent.append(this._generateEmptyRow());
                }
            }

            resultContent.append('</table>');
            elemAppendTo.html(resultContent.toString());
            if (elemAppendTo.find('.valModifButtonsAddDel_eng').length > 1) {
                var div = elemAppendTo.find('.inputWrapDiv');
                if (div) {
                    div.addClass('noPadding');
                }
            }

            this.options.generatedContent.EditModeTable = $(document.getElementById(tableId));
            this.options.isModeGenerated['EditMode'] = true;

            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
            PostponedBindsManager.PerformBinds();
            this.options.EditModeEventHandler.bindHandlers(elemAppendTo);

            return;
        },

        _generateEmptyRow: function () {
            var res = new StringBuilder();
            res.append('<tr class="val lastRow emptyRow"><td></td><td class="valCustEditor"></td><td class="valModifButtonsAddDel_' + uiManager.Lang() + '">');
            res.append(this._generateEditModeButtons(true, -1));
            res.append('</td></tr>');
            return res.toString();
        },

        _addEditRowTemplate: function (i, newVal) {
            var currAttr = this.options.jsonObject;

            // create row for 1 value
            var trId = NextId();
            var tr = new StringBuilder();
            tr.append('<tr id="' + trId + '"');
            var trClasses = ['val'];
            if (currAttr.uValsCount - 1 == i || i == -1) {
                trClasses.push('lastRow');
                if (currAttr.uValsCount - 1 == i) {
                    trClasses.push('lastVal');
                }
            }
            tr.append(' class="' + trClasses.join(' ') + '"');
            tr.append(' valueIndex="' + i + '"');

            // if i == -1 then store value in DataStoreManager
            if (i == -1 && newVal) {
                DataStoreManager.Data(trId, 'preSaveData', newVal);
            }

            //add title        
            if (currAttr.firstonly) {
                tr.append('title="' + Softerra.Class.StringMgr.EscapeForAttrValue(currAttr.uFriendName ?
                    currAttr.uFriendName : currAttr.uType) + '"');
            }
            tr.append('>');

            tr.append('<td class="valSpacing"></td>');

            // generate edit mode element
            if (i == -1 && newVal) {
                tr.append(this.proc.GenEditElem(this.element, i, this.proc.GetCustomEditorViewValue(newVal),
                    this.proc.GetCustomEditorEditValue(newVal)));
            }
            else {
                tr.append(this.proc.GenEditElem(this.element, i));
            }

            // generate container for custom editor button and add button (if neccessary)
            if (!currAttr.firstonly && currAttr.hasCustomEditor && !this.proc.PreventCustomEditor()) {
                tr.append('<td class="valCustEditor">');
                var custEditorBtnId = NextId();
                tr.append('<a tabIndex="0" class="aCustomEditor">');

                var imgNormal = new StringBuilder('img', false);
                imgNormal.append('<img id="' + custEditorBtnId + '" class="customEditor imageNormal"');
                imgNormal.append(' src="' + IMG_PATH + IMG_EDIT_WITH_CUSTOM_EDITOR + '"');
                imgNormal.append(' title="' + S_CUSTOMEDITOR + '"');
                imgNormal.append(' valueIndex="' + i + '" />');

                var imgDark = new StringBuilder('img', false);
                imgDark.append('<img id="' + custEditorBtnId + '" class="imageDark"');
                imgDark.append(' src="' + IMG_PATH + IMG_EDIT_WITH_CUSTOM_EDITOR_DARK + '"');
                imgDark.append(' title="' + S_CUSTOMEDITOR + '"');
                imgDark.append(' valueIndex="' + i + '" />');

                tr.append(imgNormal.toString());
                tr.append(imgDark.toString());
                tr.append('</a>');
                tr.append('</td>');

                this.options.EditModeEventHandler.addHandler('customEditor', 'click', { func: function (e, params) {
                    attrinfoEventHandler('editWithCustomEditor', e, params);
                    return false;
                }});

                this.options.EditModeEventHandler.addHandler('aCustomEditor', 'keyup', { func: function (e, params) {
                    if (e.keyCode == Softerra.Const.KEYCODE_ENTER) {
                        attrinfoEventHandler('editWithCustomEditor', e, params);
                    }
                    return false;
                }});
            }

            if (currAttr.firstonly) {
                // generate td without edit controls
                tr.append('<td class="valModifButtonsAddDel_' + uiManager.Lang() + '">&nbsp;</td>');
            }
            else if (uiManager.IsGlobalEditTurnedOn()) {
                // generate container for inline buttons
                tr.append('<td class="valModifButtonsAddDel_' + uiManager.Lang() + '">');
                tr.append(this._generateEditModeButtons(false, i));
                tr.append('</td>');
            }
            else {
                var genEditModeButtons = true;
                if (genEditModeButtons) {
                    if (!currAttr.hasCustomEditor &&
                        currAttr.singleValue &&
                        this.proc.HasSimpleInputEditor()) {
                        genEditModeButtons = false;
                }
            }
            if (genEditModeButtons) {
                if (currAttr.singleValue &&
                    currAttr.hasCustomEditor &&
                    this.proc.PreventCustomEditor() &&
                    this.proc.AddValueAfterLastDeleted()) {
                    genEditModeButtons = false;
            }
        }

                // generate container for inline buttons
                if (genEditModeButtons) {           
                    tr.append('<td class="valModifButtonsAddDel_' + uiManager.Lang() + '">');
                    tr.append(this._generateEditModeButtons(false, i));
                    tr.append('</td>');
                } else {
                    // generate td without edit controls
                    tr.append('<td class="valModifButtonsAddDel_' + uiManager.Lang() + '">&nbsp;</td>');
                }
            }

            tr.append('</tr>');

            return tr.toString();
        },

        addValue: function (manual) {
            var currAttr = this.options.jsonObject;
            var table = this.options.generatedContent.EditModeTable;
            var trs = table.children().first().children();

            if (trs.last().hasClass('emptyRow')) {
                trs.last().remove();
            }
            table.append(this._addValueImpl(manual));

            // set focus to the input editor
            if (this.proc.HasSimpleInputEditor() && manual) {
                var trs = table.children().first().children();

                // setting focus to the input element works very slow on the big amount of the data
                if (trs.length <= 50) {
                    trs.last().find('input.editVal').focus().select();
                }
            }

            return true;
        },

        _addValueImpl: function (manual) {
            var currAttr = this.options.jsonObject;

            // newVal by default
            var newVal = { uDispViewVal: '', uDispEditVal: this.proc.GetDefVal(), uLinkValue: '' };
            if (currAttr.hasCustomEditor && !this.proc.PreventCustomEditor() && manual) {
                // reassign newVal
                newVal = Softerra.Func.GetCustomEditorVal(currAttr, this.element);
            }

            return this._addEditRowTemplate(-1, newVal);
        },

        // Only for edit mode.
        // Works only for the last row. Binds handlers on blur, keyup and paste events.
        // If event fired and field contains a value - delete button must be shown
        _manageDeleteButtonsVisibility: function () {
            if (!this.options.isModeGenerated.EditMode) { return; }
            if (this.options.jsonObject.firstonly) { return; }
            var table = this.options.generatedContent.EditModeTable;
            var trs = table.children().first().children();
            if (trs.length != 1) { return; }

            var elems = table.find('input.editVal');
            if (!elems.length) { return; }

            var oneElem = elems.first();

            var classInputDeleteBtnVisibility = 'inputDeleteBtnVisibility';

            if (oneElem.hasClass(classInputDeleteBtnVisibility)) {
                oneElem.trigger('keyup');
                return;
            }
            
            var fBindFunc = function (event) {
                var elemInput = $(event.target);
                // cache tr
                var tr = elemInput.data('tr');
                if (!tr) {
                    tr = elemInput.parents('tr.val').first();
                    elemInput.data('tr', tr);
                }
                if (!tr) { return false; }

                var valRowCount = tr.parent().find('tr.val').length;
                if (valRowCount == 1) {
                    if (elemInput.val() != '' || event.type == 'paste') {
                        tr.find('a.delete').show();
                        tr.find('a.add').removeClass('showRightBorder');
                    }
                    else {
                        tr.find('a.delete').hide();
                        tr.find('a.add').addClass('showRightBorder');
                    }
                }
            }

            oneElem
            .bind('keyup', fBindFunc)
            .bind('blur', fBindFunc)
            .bind('paste', fBindFunc);

            oneElem.trigger('keyup');
        },

        _showSaveCancelButtons: function () {
            this._initSaveCancelButtons();
            if (this.options.saveCancelButtons) { this.options.saveCancelButtons.show(); }
        },

        _hideSaveCancelButtons: function () {
            if (this.options.saveCancelButtons) { this.options.saveCancelButtons.hide(); }
        },

        _initSaveCancelButtons: function () {
            // remove save/cancel controls
            if (this.options.saveCancelButtons) {
                if (this.options.jsonObject.firstonly) {
                    this.options.generatedContent['EditMode'].find('table.editValues ' + '.saveCancelControls_' + uiManager.Lang()).remove();
                }
                else {
                    this.options.saveCancelButtons.remove();
                }
                this.options.saveCancelButtons = null;
            }
            if (!this.options.saveCancelButtons) {
                if (!this.options.jsonObject) { return; }

                if (this.options.jsonObject.firstonly) {
                    if (this.options.isModeGenerated['EditMode']) {
                        var td = $('<td>').addClass('saveCancelControls_' + uiManager.Lang());
                        this.options.generatedContent['EditMode'].find('table.editValues tr').append(td);
                        this.options.saveCancelButtons = $('<div>').addClass('clearfix saveCancelControls_' + uiManager.Lang());
                        td.append(this.options.saveCancelButtons);
                    }
                }
                else {
                    this.options.saveCancelButtons = $('<div>').addClass('clearfix saveCancelControls_' + uiManager.Lang());
                    this.options.wrapContent.append(this.options.saveCancelButtons);
                }

                // get extra class for advanced appearance save/cancel buttons for some attributes such as logonHours
                var extraClass = this.proc.GetSaveCancelControlsExtraClass(this.element);
                if (extraClass) {
                    this.options.saveCancelButtons.addClass(extraClass);
                }

                // append "Cancel" button
                var elemCancel = $('<a tabIndex="0" href="#">' + S_ABUTTON_CANCEL + '</a>').addClass("button cancel").click($.proxy(this.cancelInlineModify, this));
                this.options.saveCancelButtons.append(elemCancel);

                // append "Save" button
                var elemSave = $('<a tabIndex="0" href="#">' + S_ABUTTON_SAVE + '</a>').addClass("button save").click($.proxy(this._onSaveBtn, this));
                this.options.saveCancelButtons.append(elemSave);
            }
        },

        clearGeneratedMode: function (mode) {
            if (!this.options.inited) { return; }
            // clear generated content
            if (mode == 'ViewMode') {
                this.options.generatedContent.ViewMode.empty();
                this.options.isModeGenerated.ViewMode = false;
                this.options.ViewModeEventHandler.clear();
            }
            else if (mode == 'EditMode') {
                this.options.generatedContent.EditMode.empty();
                this.options.isModeGenerated.EditMode = false;
                this.options.EditModeEventHandler.clear();
            }
            else {
                // do nothing
            }
        },

        jsonObject: function () {
            if (!this.options.inited) { return; }
            return this.options.jsonObject;
        },

        _generateElement: function (requiredMode) {
            // check input values and state
            if (!Softerra.Func.StringInArray(['ViewMode', 'EditMode'], requiredMode, true)) { return; }
            if (this.options.isModeGenerated[requiredMode]) { return; }
            if (!this.options.jsonObject.uType) { return; }

            var self = this;

            if (requiredMode == 'ViewMode') {
                this._generateViewMode(this.options.generatedContent['ViewMode']);
            }
            else if (requiredMode == 'EditMode') {
                this._generateEditMode(this.options.generatedContent[requiredMode]);
            }
            else {
                return;
            }

            return true;
        },

        // generates inline buttons that appears on hover event
        _generateViewModeButtons: function (elemAppendTo) {
            var jsonObject = this.options.jsonObject;
            if (jsonObject && jsonObject.readonly) { return; }
            var strContent = new StringBuilder();
            var self = this;

            // if there are no values then Edit handler perform add operation in the end.
            var editTypeIsAdd = false;
            if (jsonObject.firstonly) {
                // generate only edit button
                // strContent.append('<a class="button edit inlineedit" href="#" style="display: none;">' + S_ABUTTON_EDIT + '</a>');
            }
            else {
                // generate delete and edit buttons if valuesCount != 0
                var bAdd = !(jsonObject.singleValue && jsonObject.uValsCount > 0);

                if (jsonObject.uValsCount) {
                    strContent.append('<a id="' + NextId() + '" class="button delete inlinedelete" href="#" style="display: none;">' + S_ABUTTON_DELETE + '</a>');
                    
                    var extraEditButtonClass = !bAdd ? ' withoutLeftBorder ' : '';
                    strContent.append('<a class="button edit inlineedit'+ extraEditButtonClass +'" href="#" style="display: none;">' + S_ABUTTON_EDIT + '</a>');
                }
                
                if (bAdd) {
                    // generate add button with behavior of Edit or Add button
                    if (jsonObject.uValsCount) {
                        strContent.append('<a class="button add inlineadd withoutLeftBorder" href="#" style="display: none;">' + S_ABUTTON_ADD + '</a>');
                    }
                    else {
                        strContent.append('<a class="button add inlineedit" href="#" style="display: none;">' + S_ABUTTON_ADD + '</a>');
                        editTypeIsAdd = true;
                    }
                }
            }

            // bind inline edit clicks
            var obj = { func: this._onInlineEditBtnClick, context: this };
            if (editTypeIsAdd) {
                obj.data = { type: 'AddValue' };
            }
            // bind handler to the edit button (or add button with edit behavior)
            this.options.ViewModeEventHandler.addHandler('inlineedit', 'click', obj);

            // bind inline add clicks
            this.options.ViewModeEventHandler.addHandler('inlineadd', 'click', { func: this.OnAddValueBtnClick, context: this });

            // bind inline add clicks
            this.options.ViewModeEventHandler.addHandler('inlinedelete', 'click', { func: this.OnDeleteValueBtnClick, context: this });

            return strContent.toString();
        },

        _generateEditModeButtons: function (emptyRow, currIndex) {
            var addBtnStyle = '';
            var delBtnStyle = '';

            // determine add and delete buttons visibility and set style accordingly
            if (this.options.jsonObject.firstonly) {
                return '';
            }
            else if (emptyRow) {
                delBtnStyle = 'style="display: none;"';
                if (this.options.jsonObject.singleValue && this.proc.HasSimpleInputEditor()) {
                    addBtnStyle = 'style="display: none;"';
                }
            }
            else if (currIndex == 0 && this.options.jsonObject.singleValue) {
                addBtnStyle = 'style="display: none;"';
            }
            else if (currIndex == -1) {
                // in this case button Add was pressed so function _initAttributeEditModeButtons will 
                // handle buttons visibility
                if (this.options.jsonObject.singleValue) {
                    addBtnStyle = 'style="display: none;"';
                }
            }
            else {
                if (currIndex != this.options.jsonObject.uValsCount - 1) {
                    addBtnStyle = 'style="display: none;"';
                }
            }

            var addBtnClass = 'class="button add inlineadd';
            var delBtnClass = 'class="button delete inlinedelete';
            if (delBtnStyle.length > 0) {
                addBtnClass += ' showRightBorder ';
            }
            if (addBtnStyle.length > 0) {
                delBtnClass += ' hideLeftBorder ';
            }

            addBtnClass += '"';
            delBtnClass += '"';

            var resultContent = new StringBuilder();
            
            resultContent.append('<a tabIndex="0" ' + delBtnClass + ' ' + delBtnStyle + ' href="#">' + S_ABUTTON_DELETE + '</a>');
            this.options.EditModeEventHandler.addHandler('inlinedelete', 'click', { func: function (e) {
                attrinfoEventHandler('OnDeleteValueBtnClick', e);
                return false;
            }
        });
            
            resultContent.append('<a tabIndex="0" ' + addBtnClass + ' ' + addBtnStyle + ' href="#">' + S_ABUTTON_ADD + '</a>');

            this.options.EditModeEventHandler.addHandler('inlineadd', 'click', { func: function (e) {
                attrinfoEventHandler('OnAddValueBtnClick', e);
                return false;
            }
        });

            return resultContent.toString();
        },

        // called every time when vals table content's structure changes (add value, delete value)
        _initAttributeEditModeButtons: function () {
            requiredMode = 'EditMode';
            var self = this;
            var jsonObject = this.options.jsonObject;

            // append Save/Cancel buttons if global edit isn't turned
            if (!uiManager.IsGlobalEditTurnedOn()) {
                this._showSaveCancelButtons();
            }

            var editTable = this.options.generatedContent.EditModeTable;
            var trs = editTable.children().first().children();
            if (!trs.length) { return; }

            // determine values count
            valsCount = trs.length;
            if (trs.length == 1 && trs.first().hasClass('emptyRow')) {
                valsCount = 0;
            }

            // manage add and delete buttons visibility
            var oneValued = jsonObject.singleValue || jsonObject.firstonly;
            if (valsCount == 0) {
                trs.find('a.delete').hide();
                if (!oneValued) {
                    trs.find('a.add').addClass('showRightBorder').show();
                }
            }
            else if (valsCount == 1) {
                if (oneValued) {
                    trs.find('a.add').hide();
                }
                else {
                    trs.find('a.add').addClass('showRightBorder').show();
                }
                trs.find('a.delete').show().removeClass('hideLeftBorder');;
            }
            else {
                $(trs[valsCount - 1]).find('a.delete').show().removeClass('hideLeftBorder');;
                $(trs[valsCount - 2]).find('a.delete').show().addClass('hideLeftBorder');
                $(trs[valsCount - 2]).find('a.add').hide();

                if (!oneValued) {
                    $(trs[valsCount - 1]).find('a.add').show();
                }
                else {
                    $(trs[valsCount - 1]).find('a.add').hide();
                }
            }

            this._manageDeleteButtonsVisibility();
        },

        // post-process jsonObject, set necessary fields' default values if they aren't exist, 
        // create fields depended on the attribute's flags
        _genAttrAdditionalFields: function (currObj) {
            if (currObj.uValsCount == undefined) {
                currObj.uValsCount = 0;
            }

            // set set or reset "readonly" flag depend on the user specified flag.
            if (currObj.readonly == undefined) {
                currObj.readonly = Softerra.Class.AttrInfoMgr.IsReadonly(currObj.uAttrInfoFlags);
            }
            else {
                if (currObj.readonly && !Softerra.Class.AttrInfoMgr.IsReadonly(currObj.uAttrInfoFlags)) {
                    currObj.uAttrInfoFlags |= Softerra.Class.AttrInfoMgr.ReadonlyFlag();
                }
                else if (!currObj.readonly && Softerra.Class.AttrInfoMgr.IsReadonly(currObj.uAttrInfoFlags)) {
                    currObj.uAttrInfoFlags &= Softerra.Class.AttrInfoMgr.ReadonlyFlag();
                }
            }

            if (currObj.showcue == undefined) {
                currObj.showcue = false;
            }
            else {
                currObj.showcue = Softerra.Func.GetBool(currObj.showcue);
            }

            if (currObj.firstonly == undefined) {
                currObj.firstonly = false;
            }
            else {
                currObj.firstonly = Softerra.Func.GetBool(currObj.firstonly);
            }

            // set set or reset "singleValue" flag depend on the user specified flag.
            if (currObj.singleValue == undefined) {
                currObj.singleValue = Softerra.Class.AttrInfoMgr.IsSingleValue(currObj.uAttrInfoFlags);
            }
            else {
                if (currObj.singleValue && !Softerra.Class.AttrInfoMgr.IsSingleValue(currObj.uAttrInfoFlags)) {
                    currObj.uAttrInfoFlags |= Softerra.Class.AttrInfoMgr.SingleValueFlag();
                }
                else if (!currObj.singleValue && Softerra.Class.AttrInfoMgr.IsSingleValue(currObj.uAttrInfoFlags)) {
                    currObj.uAttrInfoFlags &= Softerra.Class.AttrInfoMgr.SingleValueFlag();
                }
            }

            if (currObj.firstonly == true) {
                currObj.singleValue = true;
            }

            currObj.hasCustomEditor = Softerra.Class.ValProcFeaturesMgr.HasCustomEditor(currObj.uValProcFeatures);
        },

        // shows inline buttons if view mode is displayed. (if switchedMode is EditMode then only delete buttons are displayed)
        _viewValueHoverOn: function (trVal) {
            if (this.options.displayedMode == 'EditMode') { return; }

            if (trVal.find('.logonHoursTable').length > 0 || trVal.find('.flagSet').length > 0)
            {
                trVal.find('td.valModifButtonsAddEditDel_' + uiManager.Lang()).addClass('borderedButton');
            }

            var showButtons = function () {
                if (this.options.switchedMode == 'EditMode') {
                    trVal.find('td.valModifButtonsAddEditDel_' + uiManager.Lang()).find('a.delete').show();
                }
                else {
                    trVal.find('td.valModifButtonsAddEditDel_' + uiManager.Lang()).find('*').show();
                }
            }

            if (this.options.isInlineModifyTurnedOn) {
                showButtons.call(this);
            }
            else {
                if (uiManager.IsGlobalEditTurnedOn()) { return; }
                if (uiManager.IsInlineModifyTurnedOn()) { return; }
                showButtons.call(this);
            }
            
            this._setSelectionForViewAttribute(trVal);
        },

        // hides all inline buttons for ViewMode
        _viewValueHoverOff: function (trVal, uiManagerTriggered) {
            trVal.find('td.valModifButtonsAddEditDel_' + uiManager.Lang()).find('*').hide();
            this._removeSelectionFromViewAttribute(trVal);
        },

        _setSelectionForViewAttribute: function (trVal) {
            trVal.find('td').addClass('hovered');
            this.tdValHovered = trVal.find('td.val').addClass('unbordered');
            var tdVals = trVal.parents('table.data').find('table.viewValues td.val');
            var index = tdVals.index(this.tdValHovered); 
            if (index > 0) 
            {
               this.tdValPrevHovered = $(tdVals[index - 1]).addClass('unbordered');
           }
       },

       _removeSelectionFromViewAttribute: function(trVal) {
        trVal.find('td').removeClass('hovered');
        if (this.tdValHovered) {
            this.tdValHovered.removeClass('unbordered');
        }

        if (this.tdValPrevHovered) {
            this.tdValPrevHovered.removeClass('unbordered');   
        }

        this.tdValHovered = null;
        this.tdValPrevHovered = null;
    },

    _setSelectionForEditAttribute: function (trVal) {
        this.tdPrevEditVal = trVal.prev().find('td.val:last').addClass('unbordered');
        trVal.find('td.val').removeClass('unbordered');
        this.tdEditVal = trVal.find('td.val:last').addClass('unbordered');
    },

    _removeSelectionFromEditAttribute: function(trVal) {
        if (this.tdPrevEditVal) {
            this.tdPrevEditVal.removeClass('unbordered');
        }

        if (this.tdEditVal) {
            this.tdEditVal.removeClass('unbordered');   
        }

        this.tdEditVal = null;
        this.tdPrevEditVal = null;
    },

        // manages inline buttons visibility in ViewMode
        _onViewValueMouseMove: function (e) {
            if (e.target == this.LastMouseMoveElem) { return; }
            this.LastMouseMoveElem = e.target;

            // getting current tr.val
            var currTrTarget;
            currTrTarget = $(e.target).parents('tr.val').first();
            if (!currTrTarget || !currTrTarget.length) { return; }
            if (this.LastHoveredTr == currTrTarget) { return; }

            // hovered tr.val changed
            if (this.LastHoveredTr) {
                this._viewValueHoverOff(this.LastHoveredTr);
                this.LastHoveredTr = null;
            }
            
            this.LastHoveredTr = currTrTarget;
            this._viewValueHoverOn(currTrTarget);
        },

        // this function acts only if is triggered by uiManager and hoverOn was previously triggered by uiManager(parentHoverOn method)
        // or none of the conditions happens
        _viewValuesTableHoverOff: function (e, triggeredByParent) {
            if ((this._hoverTriggeredByParent && !triggeredByParent) ||
                (!this._hoverTriggeredByParent && triggeredByParent)) {
                return;
        }

        if (this.LastHoveredTr) {
            this._viewValueHoverOff(this.LastHoveredTr);
            this.LastHoveredTr = null;
        }
        this.LastMouseMoveElem = null;
    },

        // is called by uiManager when mouse enters TR with an attribute, but attribute isn't hovered yet
        // In this case we need notify the attribute when mouse leaves TR (parentHoverOff)
        parentHoverOn: function (e) {
            if (!this.options.inited) { return; }
            // restriction for the performance reasons.
            var EXTRAHOVER_MAX_VALUES_COUNT = 10;
            if (this.options.jsonObject.uValsCount > EXTRAHOVER_MAX_VALUES_COUNT) { return; }

            var trs = this.options.generatedContent.ViewModeTable.children().first().children();

            // calculate middle points of attribute values' TRs to determine which TR is nearest to the mouse pointer
            // and trigger hoverOn event for corresponding TR
            var trMiddlePoints = [];
            trs.each(function () {
                trMiddlePoints.push(parseInt($(this).offset().top + $(this).height() / 2));
            });

            var nearestIndex = -1;
            var minWay = -1.0;
            for (var i = 0; i < trMiddlePoints.length; ++i) {
                if (minWay == -1 || Math.abs(e.pageY - trMiddlePoints[i]) < minWay) {
                    minWay = Math.abs(e.pageY - trMiddlePoints[i]);
                    nearestIndex = i;
                }
            }

            if (nearestIndex >= 0) {
                this.LastHoveredTr = $(trs[nearestIndex]);
                this._viewValueHoverOn(this.LastHoveredTr);
                this._hoverTriggeredByParent = true;
            }
        },

        parentHoverOff: function () {
            if (!this.options.inited) { return; }
            this._viewValuesTableHoverOff(null, true);
        },

        // add value handler for both view and edit modes
        OnAddValueBtnClick: function (e) {
            var res = this._addValueBtnClickImpl(true);

            this._selectAttributeOnEdit();
            this._updateMultivaluedAttributeNameStyle();

            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
            PostponedBindsManager.PerformBinds();

            return res;
        },

        _addValueBtnClickImpl: function (manual) {
            // get jsonObject
            var jsonObject = this.options.jsonObject;

            var prevMode = this.options.switchedMode;
            // change mode to 'EditMode' if it isn't done
            if (this.options.switchedMode == 'ViewMode') {
                this.switchMode({ operation: "AddValue" });
            }

            // perform add operation (modify DOM)
            var res = this.addValue(manual);
            this._initAttributeEditModeButtons();
            // if attribute has custom editor (host's dialog appeared) and is single valued then 
            // trigger save or cancel after add operation
            if (prevMode == 'ViewMode' &&
                jsonObject.hasCustomEditor &&
                !this.proc.PreventCustomEditor() &&
                !this.options.uiManager.IsGlobalEditTurnedOn()) {
                if (res && jsonObject.singleValue) {
                    this.options.saveCancelButtons.find('a.save').click();
                }
                else if (!res) {
                    this.options.saveCancelButtons.find('a.cancel').click();
                }
            }

            return false;
        },

        // delete handler for both view and edit modes
        OnDeleteValueBtnClick: function (e) {
            var uiManager = this.options.uiManager;
            var jsonObject = this.options.jsonObject;

            var currTR = $($(e.target).parents('tr.val')[0]);
            var currIndex = -1;

            // determine current TR index
            if (this.options.switchedMode == 'ViewMode') {
                currIndex = this.options.generatedContent.ViewModeTable.children().first().children().index(currTR);
            }
            else {
                currIndex = this.options.generatedContent.EditModeTable.children().first().children().index(currTR);
            }

            // if didn't determine try it by means of comparing delete button's id with so in other TR's
            if (currIndex == -1) {
                var currBtnIndex = $(e.target).attr('id');
                var trs = this.options.generatedContent.ViewModeTable.children().first().children();
                var trsLen = trs.length;
                for (var i = 0; i < trsLen; ++i) {
                    if ($(trs[i]).find('a.delete').attr('id') == currBtnIndex) {
                        currIndex = i;
                        break;
                    }
                }
            }

            assert(currIndex != -1);

            // if displayed mode is ViewMode and last row is being deleted then turn displayed mode to EditMode, 
            // but don't clear EditMode (for the reason to make ADD button visible)
            if (this.options.displayedMode == 'ViewMode') {
                var table = this.options.generatedContent.ViewModeTable;
                var rowsRemain = table.children().first().children().length;
                if (rowsRemain == 1) {
                    this.turnMode('EditMode',
                    {
                        clearViewModeContent: true,
                        clearEditModeContent: false
                    });
                }
            }

            // if we were in ViewMode then turn to EditMode, but leave dislpayMode in ViewMode
            if (this.options.switchedMode == 'ViewMode') {
                this.switchMode({
                    turnDisplayedMode: true,
                    clearViewModeContent: false,
                    clearEditModeContent: false
                });
            }

            if (this.options.displayedMode == 'ViewMode') {
                // view and edit mode must be synchronized
                $(this.options.generatedContent.ViewModeTable.children().first().children()[currIndex]).remove();
                $(this.options.generatedContent.EditModeTable.children().first().children()[currIndex]).remove();
            }
            else {
                var table = this.options.generatedContent.EditModeTable;

                //hide "add" button
                trs = table.children().first().children();
                var rowsRemain = trs.length;
                $(trs[rowsRemain - 1]).find('a.add').hide();

                $(trs[currIndex]).remove();

                // if no rows remains perform add value operation or generate empty row
                if (rowsRemain == 1) {
                    if (this.proc.AddValueAfterLastDeleted()) {
                        var res = this.addValue(false);
                        this._initAttributeEditModeButtons();
                        table.find('tr.val input[type=text]').focus().select();
                    }
                    else {
                        table.append(this._generateEmptyRow());
                    }
                }

                trs = table.children().first().children();
                $(trs[trs.length - 1]).addClass('lastRow');

                this._initAttributeEditModeButtons();
            }

            this._selectAttributeOnEdit();
            this._updateMultivaluedAttributeNameStyle();

            TimersHolder.addFunction(function () {
                PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
                PostponedBindsManager.PerformBinds();
            });

            return false;
        },

        _updateFoldPaneLastTDVal: function () {
            var _parent = this.element.parent();
            var divFoldPane = _parent.parents('div.foldPane');
            if (divFoldPane) {
                divFoldPane.find('td.val').removeClass('last');
                divFoldPane.find('td.val:last').addClass('last');
            } 
        },

        _selectAttributeOnEdit: function() {
            if (!uiManager.IsGlobalEditTurnedOn()) {
                var _parent = this.element.parent();
                this.inlineAttributeEditTR =  _parent.parents('tr');
                this.inlineAttributeEditTR.addClass('attributeEditSelection');    
                this._setSelectionForEditAttribute(this.inlineAttributeEditTR);
            } 
            else {
                this._updateFoldPaneLastTDVal();
            }
            
        },

        _unselectAttributeOnEdit: function() {
            if (this.inlineAttributeEditTR) {
                this.inlineAttributeEditTR.removeClass('attributeEditSelection');
                this._removeSelectionFromEditAttribute(this.inlineAttributeEditTR);   
                this.inlineAttributeEditTR = null;
            }

            this._updateFoldPaneLastTDVal();
        },

        _updateMultivaluedAttributeNameStyle: function() {
            var attributeTR = this.element.parent().parents('tr');
            var attributeTH =  attributeTR.find('th');
            var attributeValues =  attributeTR.find('table.valsTable td.val').length;
            if (attributeValues > 1 &&  !attributeTH.hasClass('multivalued')) {
                attributeTH.addClass('multivalued');
            } else if (attributeValues == 1 &&  attributeTH.hasClass('multivalued') && attributeTR.find('div.flagSet').length == 0) {
                attributeTH.removeClass('multivalued');
            }
        },

        _onInlineEditBtnClick: function (event) {

            var uiManager = this.options.uiManager;
            if (uiManager.IsInlineModifyTurnedOn()) { return false; }

            var currTR = $($(event.target).parents('tr.val')[0]);

            /////////////////////////////////////////////////

            var currIndex = this.options.wrapContent.find('table.viewValues tr.val').index(currTR);

            //set focus or trigger custom editor
            if (this.options.jsonObject.hasCustomEditor && !this.proc.PreventCustomEditor()) {
                // switch mode and show custom editor dialog. 
                // Set prevMode=ViewMode for distinguishing whether custom editor button was clicked in EditMode or not
                this.switchMode();
                this._selectAttributeOnEdit();
                var currTREdit = $(this.options.generatedContent.EditMode.find('table.editValues tr.val')[currIndex]);
                currTREdit.find('img.customEditor').trigger('click', { prevMode: 'ViewMode' });
            }
            else {
                this.switchMode(true);
                this._selectAttributeOnEdit();
                var currTREdit = $(this.options.generatedContent.EditMode.find('table.editValues tr.val')[currIndex]);
                if (currTREdit.find('div.flagSet').length == 0) {
                    currTREdit.find('input').focus().select();    
                } 
            }

            if (event.data && event.data.type == 'AddValue') {
                if (!this.proc.AddValueAfterLastDeleted()) {
                    this.addValue(true);
                    this._showSaveCancelButtons();
                }
            }

            this._updateMultivaluedAttributeNameStyle();

            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
            PostponedBindsManager.PerformBinds();

            return false;
        },

        _onSaveBtn: function (e) {
            if (this.options.uiManager.IsGlobalEditTurnedOn()) { return; }
            var modifications = [];

            // get attached attribute object
            var jsonObject = this.options.jsonObject;

            // if current attribute is readonly - return
            if (jsonObject.readonly == true) { return false; }

            this._unselectAttributeOnEdit();

            // find 
            var valsTable = this.options.generatedContent.EditModeTable;
            if (this.proc.GetModifiedValues) {
                var resultObj = this.proc.GetModifiedValues.call(this.proc, jsonObject, valsTable);
                if (resultObj !== undefined) {
                    resultObj.uType = jsonObject.uType;
                    modifications.push(resultObj);
                }
                else {
                    // if no modifications - switch back to ViewMode
                    this.switchMode();

                    PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
                    PostponedBindsManager.PerformBinds();

                    return false;
                }

                if (modifications.length) {
                    var modifyRequest = { refreshNode: true, uModifications: modifications };
                    var jsonResultObj = $.toJSON(modifyRequest);

                    if (jsonResultObj) {
                        this.options.uiManager.ManualSaveInitiated();
                        if (jsonResultObj) {
                            var operId;
                            try {
                                operId = window.external.ContextNode.SyncOperation("ModifyEntry", jsonResultObj, 0);
                            }
                            catch (e) { }
                        }
                    }
                }
                else {
                    // if no modifications - switch back to ViewMode
                    this.switchMode();

                    PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
                    PostponedBindsManager.PerformBinds();
                }
            }
            return false;
        },

        cancelInlineModify: function () {
            if (!this.options.inited) { return; }
            if (this.options.uiManager.IsGlobalEditTurnedOn()) { return; }
            if (this.options.uiManager.IsInlineModifyTurnedOn()) {
                this.turnMode('ViewMode');
            }
            
            this._unselectAttributeOnEdit();

            PostponedOperationsManager.Execute(PostponedOperationsManager.OperationGroups.attrinfoProcessing);
            PostponedBindsManager.PerformBinds();

            return false;
        },

        // hook ENTER and ESCAPE buttons and trigger Save and Cancel operations accordingly
        onKeyUp: function (event) {
            //TRICK for IE. It prevents event double-firing.
            if (!this.keyUpTrickData) {
                this.keyUpTrickData = { event: event };
            }
            else {
                if (this.keyUpTrickData.event.keyCode != event.keyCode) {
                    this.keyUpTrickData = { event: event };
                }
                else {
                    this.keyUpTrickData = null;
                    return;
                }
            }

            if (event.keyCode == Softerra.Const.KEYCODE_ESC) {
                this.cancelInlineModify();
                $('body').focus().select();
            }
            else if (event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                this._onSaveBtn();
            }
        },

        editWithCustomEditor: function (event, data) {
            var jsonObject = this.options.jsonObject;

            var valIndex = $(event.target).attr('valueIndex');

            var newVal = Softerra.Func.GetCustomEditorVal.call(this, jsonObject, event.target, valIndex);
            if (newVal) {
                // set value by the index
                this.proc.SetValByIndex.call(this.proc, jsonObject, event.target, valIndex, newVal);
            }

            if (this.options.uiManager.IsGlobalEditTurnedOn()) { return false; }

            // Save or Cancel if necessary
            if (newVal) {
                if (data && data.prevMode == 'ViewMode' && jsonObject.singleValue) {
                    this._onSaveBtn();
                }
            }
            else {
                if (data && data.prevMode == 'ViewMode' && jsonObject.singleValue) {
                    this.cancelInlineModify();
                }
            }

            return false;
        },

        defaultAction: function (e, valIndex) {
            if (valIndex === undefined) { return; }
            var jsonObject = this.options.jsonObject;

            var encFlags = this.proc.GetEncodingFlag.call(this.proc);

            var editVal = this.proc.GetEditValue.call(this.proc, jsonObject, valIndex);
            if (!editVal) { return; }

            try {
                var params = { uType: jsonObject.uType, uDispEditVal: editVal, uEncFlags: encFlags };
                window.external.ContextNode.SyncOperation("DefaultAction", $.toJSON(params), 0);
            }
            catch (e) { }
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);

// getting attrinfo element by event's target if event has happened inside the widget
function getElementByTarget(target) {
    var wrapDivElems = $(target).parents('.ldapAttrInfoDiv').first().children();
    var inputElem;
    for (var i = 0; i < wrapDivElems.length; ++i) {
        var currElem = $(wrapDivElems[i]);
        if (wrapDivElems[i].nodeName.toLowerCase() == 'input' && currElem.hasClass('ldapAttrInfo')) {
            inputElem = $(wrapDivElems[i]);
            break;
        }
    }
    if (!inputElem) { return; }

    return inputElem.attrinfo('option', 'element');
};

// common event handler to proxy calls to widget's methods.
function attrinfoEventHandler(funcName, e, p1, p2, p3, p4, p5) {
    var elem = getElementByTarget(e.target);
    if (!elem) { return; }
    elem.attrinfo(funcName, e, p1, p2, p3, p4, p5);
}