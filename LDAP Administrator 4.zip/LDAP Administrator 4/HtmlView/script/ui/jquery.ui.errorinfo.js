/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {
    $.widget("ui.errorinfo", {
        options: {
        },

        _create: function () {
            if (!this.jsonObject) {
                try {
                    this.jsonObject = $.parseJSON(this.element.attr("value"));
                }
                catch (e) { return; }
            }

            if (!this.jsonObject) { return; }

            this.wrapContent = this.element.wrap(function () {
                return $('<div>');
            }).parent();

            this._generateErrorInfoView();
        },

        _generateErrorInfoView: function () {
            var resultContent = new StringBuilder();
            var titleString = new StringBuilder();
            titleString = Softerra.Class.StringMgr.EscapeForHtml(this.jsonObject.uTitle);

            while (titleString.length > 0 && titleString.charAt(titleString.length-1) === ".") {
                titleString = titleString.slice(0,-1);
            }

            resultContent.append('<div class="errorDiv">');
            resultContent.append('<img class="imageNormal" src="' + IMG_PATH + 'misc/error.png"></img>');
            resultContent.append('<img class="imageDark" src="' + IMG_PATH + 'misc/error_dark.png"></img>');

            resultContent.append('<div class="errorDetails">');
            resultContent.append('<h1>' + titleString + '</h1>');
            resultContent.append('<p>' + Softerra.Class.StringMgr.EscapeForHtml(this.jsonObject.uDescription, true));

            var helpExists = !!this.jsonObject.uHelp;
            var aId = NextId();
            if (helpExists) {
                resultContent.append('&nbsp;&#65073;&nbsp;' +'<a href="#" id="' + aId + '" title="' + Softerra.Class.StringMgr.EscapeForHtml(this.jsonObject.uHelp) + '">' + S_HELP + '</a>');
                
            }

            resultContent.append('</div>');
            resultContent.append('</p>');
            resultContent.append('</div>');
         
            this.wrapContent.append(resultContent.toString());

            if (helpExists) {
                // bind onClick event handler
                $('#' + aId).click($.proxy(function () {
                    try {
                        window.external.ContextNode.SyncOperation("ShellExecute", this.jsonObject.uHelp, 0);
                    }
                    catch (e) {
                        alert(S_FAILED_LAUNCH_HELP);
                    }

                    return false;
                }, this));
            }
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);