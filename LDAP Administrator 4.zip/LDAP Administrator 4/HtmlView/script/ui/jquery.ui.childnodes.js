/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

/*
* Depends:
*   jquery.pagination.js
*/


(function ($, undefined) {
    $.widget("ui.childnodes", {
        options: {
            childrenPerPage: 100,
            descriptiveAttributes: ['description']
        },

        _create: function () {
            // this widget depends on the pagination plugin.
            if (!$.fn.pagination) { return; }

            this.created = false;
            try {
                this.jsonObject = jQuery.parseJSON(this.element.attr("value"));
            }
            catch (e) { return; }

            if (!this.jsonObject) { return; }
            var obj = this.jsonObject;

            // wrap             
            this.wrapContent = $(this.element).wrap(function () {
                return $('<div>').addClass('childNodesWrapDiv');
            }).parent();

            this.wrapContent.parent().prepend();

            obj.uChildNodes = obj.uChildNodes || [];
            obj.uChildItems = obj.uChildItems || [];

            obj.summaryLength = obj.uChildNodes.length + obj.uChildItems.length;
            if (obj.summaryLength == 0) {
                if (Softerra.Func.GetBool(obj.hideEmptyMsg) != true) {
                    this.wrapContent.append('<p>' + S_NO_CHILDREN + '</p>');
                    this.wrapContent.parents('div.children').addClass('noLeftPadding');
                }
                return;
            }

            // calculate pages count
            obj.pagesCount = Math.ceil(obj.summaryLength / this.options.childrenPerPage);

            // append text that's the name of displayed information
            if (obj.pagesCount && obj.groupName) {
                this.wrapContent.append($('<div>').addClass('childNodesGroupName').append('<span>' + Softerra.Class.StringMgr.EscapeForHtml(obj.groupName) + '</span>'));
            }

            // generate DIV where the page will be located
            this.searchResultDiv = $('<div></div>').addClass('childNodes');
            this.wrapContent.append(this.searchResultDiv);

            // if we have more than one page, generate DIV element 
            // where the pagination element will be located
            if (obj.pagesCount != 1) {
                this.paginationDiv = $('<div></div>').addClass('paginationDiv');
                this.wrapContent.append(this.paginationDiv);
                this.wrapContent.append('<br style="clear: both;">');
                this.wrapContent.append('<br>');
            }

            // if pages count more then one - make pagination and attach callback function.
            // else simply generate one page
            if (obj.pagesCount != 1) {
                this.paginationDiv.pagination(
                    obj.pagesCount, {
                        callback: $.proxy(this._createPage, this),
                        items_per_page: 1, // Show only one item per page
                        num_edge_entries: 2,
                        num_display_entries: 5,
                        prev_text: S_PREV,
                        next_text: S_NEXT
                    });
            }
            else {
                this._createPage(0);
            }
        },

        _gatherContextNodeElements: function (elementsType) {
            // gather context node elements
            if (elementsType == Softerra.Const.CHILDTYPE_NODE && !this.contextNodes) {
                this.contextNodes = [];
                var contextObjNodes = window.external.ContextNode.ChildNodes;
                for (var objEnum = new Enumerator(contextObjNodes); !objEnum.atEnd(); objEnum.moveNext()) {
                    this.contextNodes.push(objEnum.item());
                }
                delete objEnum;
            }

            if (elementsType == Softerra.Const.CHILDTYPE_ITEM && !this.contextItems) {
                this.contextItems = [];
                var contextObjItems = window.external.ContextNode.ChildItems;
                for (var objEnum = new Enumerator(contextObjItems); !objEnum.atEnd(); objEnum.moveNext()) {
                    this.contextItems.push(objEnum.item());
                }
                delete objEnum;
            }
        },

        _createPage: function (pageIndex) {
            this.searchResultDiv.empty();
            this.pageIndex = pageIndex;
            var obj = this.jsonObject;

            var elemTable = $('<table></table>').addClass('childNodesTable');
            this.searchResultDiv.append(elemTable);

            // calculate indexes
            var indexStart = pageIndex * this.options.childrenPerPage;
            var indexEnd = pageIndex == (obj.pagesCount - 1) ?
                            obj.summaryLength - 1 :
                            indexStart + this.options.childrenPerPage - 1;

            var currChildrenType = 0;

            var searchRequest = {};
            searchRequest.uReqAttrs = this.options.descriptiveAttributes;
            searchRequest.uChildren = [];

            for (var i = indexStart; i <= indexEnd; i++) {
                var currChildrenEntity;
                var currItemIndex;

                if (i < obj.uChildNodes.length) {
                    currChildrenEntity = obj.uChildNodes;
                    currItemIndex = i;
                    currChildrenType = Softerra.Const.CHILDTYPE_NODE;
                }
                else {
                    currChildrenEntity = obj.uChildItems;
                    currItemIndex = i - obj.uChildNodes.length;
                    currChildrenType = Softerra.Const.CHILDTYPE_ITEM;
                }

                var tr = $('<tr>');
                elemTable.append(tr);

                //icon
                var td = $('<td>').addClass('childIcon');
                tr.append(td);
                var imgClass = '';
                if (dpiScaleFactor * 16 >= 24) { imgClass = 'class="dpiScaleHalf" '; }
                td.append('<img ' + imgClass + 'src="' + currChildrenEntity[currItemIndex].uNormIcon + '"/>');

                //name
                td = $('<td>').addClass('childName');
                tr.append(td);
                var bTitleNeed = currChildrenEntity[currItemIndex].uName.length > Softerra.Class.StringMgr.Constants.STR_MAX_LENGTH;
                var a = $('<a tabIndex="0" href="#">' + Softerra.Class.StringMgr.EscapeForHtml(currChildrenEntity[currItemIndex].uName) + '</a>');
                td.append(a);
                if (bTitleNeed) { a.attr('title', Softerra.Class.StringMgr.StringToTitle(currChildrenEntity[currItemIndex].uName)); }
                a.bind('click', { index: currItemIndex, elementType: currChildrenType }, $.proxy(this._onItemClick, this));

                // description
                td = $('<td>').addClass('childDescription');
                tr.append(td);

                var entityType = currChildrenEntity[currItemIndex].uType;
                if (entityType != S_ENTRY && entityType != S_SEARCH_RESULT) {
                    this._gatherContextNodeElements(currChildrenType);
                    var descr = currChildrenType == Softerra.Const.CHILDTYPE_NODE ?
                        this.contextNodes[currItemIndex].Value :
                        this.contextItems[currItemIndex].Value;
                    currChildrenEntity[currItemIndex].uDescription = descr;
                }

                if (currChildrenEntity[currItemIndex].uDescription != undefined) {
                    if (entityType == S_SERVER_PROFILE || entityType == S_LDAP_REFERRAL) {
                        var a = $('<a tabIndex="0" href="#">' + Softerra.Class.StringMgr.EscapeForHtml(currChildrenEntity[currItemIndex].uDescription) + '</a>');
                        td.append(a);
                        if (bTitleNeed) { a.attr('title', Softerra.Class.StringMgr.StringToTitle(currChildrenEntity[currItemIndex].uName)); }
                        a.bind('click', { index: currItemIndex, elementType: currChildrenType }, $.proxy(this._onItemClick, this));
                    }
                    else {
                        var str = currChildrenEntity[currItemIndex].uDescription;
                        str = Softerra.Class.StringMgr.EscapeForHtml(str);
                        td.append(str);
                    }
                    a.bind('click', { index: currItemIndex, elementType: currChildrenType }, $.proxy(this._onItemClick, this));


                }
                else {
                    td.append('&nbsp;');
                    if (!currChildrenEntity[currItemIndex].uSearchComplete) {
                        searchRequest.uChildren.push({ uChildType: currChildrenType, uChildNumber: currItemIndex });
                        currChildrenEntity[currItemIndex].uSearchComplete = true;
                    }
                }
            }

            if (searchRequest.uChildren.length) {
                // start search
                var requestObj = $.toJSON(searchRequest);
                var operId = window.external.ContextNode.BeginAsyncOperation("SearchChildAttributes", requestObj, 0);
                TimersHolder.addFunction($.proxy(function () {
                    this._waitAttributes(operId);
                }, this), null, 200);
            }
            else if (this.paginationDiv) {
                this.paginationDiv.find('a').attr('tabIndex', '0');
            }
        },

        _waitAttributes: function (operId) {
            var operFinished;
            try {
                operFinished = window.external.ContextNode.FinishedAsyncOperation(operId);
            }
            catch (e) { }

            if (operFinished == undefined) { return; }

            if (operFinished) {
                var res = window.external.ContextNode.EndAsyncOperation(operId, null);
                this._addDescriptions(res);
                // generate page
                this._createPage(this.pageIndex);
            }
            else {
                TimersHolder.addFunction($.proxy(function () {
                    this._waitAttributes(operId);
                }, this), null, 200);
            }
        },

        _addDescriptions: function (searchResponse) {
            var responseObj;
            try {
                responseObj = jQuery.parseJSON(searchResponse);
            }
            catch (e) { return; }

            if (!responseObj) { return; }

            var obj = this.jsonObject;

            for (var i = 0; i < responseObj.uChildren.length; ++i) {
                var currResponseChild = responseObj.uChildren[i];
                var currChild =
                    currResponseChild.uChildType == Softerra.Const.CHILDTYPE_NODE ?
                    obj.uChildNodes[currResponseChild.uChildNumber] :
                    obj.uChildItems[currResponseChild.uChildNumber];

                var bFound = false;
                outer:
                for (var iReq = 0; iReq < this.options.descriptiveAttributes.length; ++iReq) {
                    for (var iAvailable = 0; iAvailable < currResponseChild.uAttributes.length; ++iAvailable) {
                        if (
                            this.options.descriptiveAttributes[iReq] == currResponseChild.uAttributes[iAvailable].uType &&
                            currResponseChild.uAttributes[iAvailable].uValues &&
                            currResponseChild.uAttributes[iAvailable].uValues.length) {
                            currChild.uDescription = currResponseChild.uAttributes[iAvailable].uValues[0];
                            bFound = true;
                            break outer;
                        }
                    }
                }

                if (!bFound) {
                    currChild.uDescription = ' ';
                }
            }
        },

        _onItemClick: function (event) {
            event.stopImmediatePropagation();
            this._gatherContextNodeElements(event.data.elementType);
            event.data.elementType == Softerra.Const.CHILDTYPE_NODE ?
                this.contextNodes[event.data.index].DefaultAction() :
                this.contextItems[event.data.index].DefaultAction();

            return false;
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);