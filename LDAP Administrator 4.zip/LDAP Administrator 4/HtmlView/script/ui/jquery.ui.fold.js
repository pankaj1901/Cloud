/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {
    $.widget("ui.fold", {
        options: {
            viewName: '',
            cookie: null
        },

        _create: function () {
            this.folded = false;

            this.elementId = this.element.attr('id');

            this.foldBtn = this.element.find('.foldButton');
            this.foldPane = this.element.find('.foldPane');
            if (!(this.foldBtn && this.foldPane)) { return; }

            this.wrapContent = $(this.foldBtn.parent()).wrapInner('<span class="foldButtonSpan"></span>');
            this.wrapContent.prepend('<span class="spacing"></span>');

            if (this.options.viewName && this.elementId) {
                this.cookie = this.options.cookie || {};
                this.cookie.name = 'ui-fold-' + this.options.viewName + '-' + this.elementId;
                this.cookie.expires = this.cookie.expires || 30;
            }
            var initialFolded = Softerra.Func.GetBool(this._cookie(), false);

            this.foldBtn.click($.proxy(this._changeState, this));
            if (initialFolded) {
                this._fold();
            }
            else {
                this._unfold();
            }
        },

        _changeState: function () {
            if (this.folded) {
                this._unfold();
            }
            else {
                this._fold()
            }

            return false;
        },

        _unfold: function () {
            this.folded = false;
            this.foldBtn.removeClass('unfolded').addClass('folded');
            this.foldPane.show();

            this._cookie(this.folded, this.cookie);
            this._trigger('show');
        },

        _fold: function () {
            this.folded = true;
            this.foldBtn.removeClass('folded').addClass('unfolded');
            this.foldPane.hide();

            this._cookie(this.folded, this.cookie);
        },

        _cookie: function () {
            if (!this.cookie) { return; }
            var cookie = this.cookie.name;
            return $.cookie.apply(null, [cookie].concat($.makeArray(arguments)));
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);