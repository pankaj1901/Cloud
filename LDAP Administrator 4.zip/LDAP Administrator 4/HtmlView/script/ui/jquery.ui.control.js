/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {

    $.widget("ui.control", {
        options: {
            tabbed: null,
            isVisible: null,
            isDirty: false,
            inited: false,
            currentMode: null,
            isInlineModifyTurnedOn: false,
            controlName: null,
            Content: null,
            SaveCancelButtons: null,
            ViewModeEventHandler: null,
            EditModeEventHandler: null
        },

        _create: function () {
            // get control name
            this.options.controlName = this.element.attr('controlName');
            if (!this.options.controlName) { return; }

            // create event handlers
            this.options.ViewModeEventHandler = new CommonEventHandler();
            this.options.EditModeEventHandler = new CommonEventHandler();

            // generate common content structure
            this.options.Content = $('<div class="controlContent"></div>');
            var _controlElements = this.element.children().detach();
            this.element.append(this.options.Content);
            this.options.Content.append(_controlElements);

            // create Save/Cancel buttons
            this.options.SaveCancelButtons = $('<div class="saveCancelControls_' + LANGUAGE + '"></div>').css('display', 'none');
            this.genSaveCancelButtons();
            this.element.append(this.options.SaveCancelButtons);

            // find processor for control and init it with processor
            this.proc = Softerra.Class.ControlProcessorsMgr.GetProcessor(this.options.controlName);
            if (!this.proc) { return; }
            this.options.inited = this.proc.Init(this.element);
        },

        //////////////////////////////////////////////////////////////////////////
        // public methods

        turnMode: function (requiredMode, opts) {
            opts = opts || {};
            this.proc.TurnMode(this.element, requiredMode);
            if (requiredMode == 'ViewMode') {
                this.hideSaveCancelButtons();
            }
            else {
                if (!opts.globalSwitchMode) {
                    this.showSaveCancelButtons();
                }
            }
            this.options.ViewModeEventHandler.bindHandlers(this.element);
            PostponedBindsManager.PerformBinds();

            this.options.currentMode = requiredMode;

            // change control's state and notify event handler about this
            if (!opts.globalSwitchMode && uiManager.IsPageInited()) {
                var oldVal = this.options.isInlineModifyTurnedOn;
                this.options.isInlineModifyTurnedOn = (requiredMode == 'EditMode');
                if (oldVal != this.options.isInlineModifyTurnedOn) {
                    this._trigger('inlineModifyTurned', null,
                        { notifier: 'control', state: this.options.isInlineModifyTurnedOn, element: this.element });
                }
            }
        },

        setDirty: function (dirty) {
            this.options.isDirty = dirty;
        },

        // calls attached processor's method
        procMethod: function (funcName, par1, par2, par3, par4, par5) {
            if (!this.proc[funcName]) { return; }
            return this.proc[funcName].call(this.proc, par1, par2, par3, par4, par5);
        },

        getModifications: function () {
            if (this.options.currentMode == 'ViewMode' || !this.options.isDirty) { return null; }
            return this.proc.GetModifiedValues(this.element);
        },

        showSaveCancelButtons: function () {
            this.options.SaveCancelButtons.show();
        },

        hideSaveCancelButtons: function () {
            this.options.SaveCancelButtons.hide();
        },

        genSaveCancelButtons: function () {
            // append "Cancel" button
            var elemCancel = $('<a tabIndex="0" href="#">' + S_ABUTTON_CANCEL + '</a>').addClass("button cancel").click($.proxy(this.cancel, this));
            this.options.SaveCancelButtons.append(elemCancel);

            // append "Save" button
            var elemSave = $('<a tabIndex="0" href="#">' + S_ABUTTON_SAVE + '</a>').addClass("button save").click($.proxy(this.save, this));
            this.options.SaveCancelButtons.append(elemSave);
        },

        save: function () {
            if (uiManager.IsGlobalEditTurnedOn()) { return; }
            var modifications = this.proc.GetModifiedValues.call(this.proc, this.element);
            if (modifications === undefined) {
                this.turnMode('ViewMode');
                return false;
            }

            var modifyRequest = { refreshNode: true, uModifications: modifications };
            var jsonResultObj = $.toJSON(modifyRequest);

            if (jsonResultObj) {
                // prevents asking about need to save modifications
                uiManager.ManualSaveInitiated();
                if (jsonResultObj) {
                    var operId;
                    try {
                        operId = window.external.ContextNode.SyncOperation("ModifyEntry", jsonResultObj, 0);
                    }
                    catch (e) { }
                }
            }

            return false;
        },

        cancel: function () {
            this.turnMode('ViewMode');
            return false;
        },

        optionExists: function (optionName) {
            return !!this.options[optionName];
        },

        //////////////////////////////////////////////////////////////////////////
        // event handlers

        //////////////////////////////////////////////////////////////////////////
        // private methods

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);

function getCtrlElementByTarget(target) {
    return $(target).parents('.control').first();
};

// common event handler that proxy handling to control
function controlEventHandler(funcName, e, p1, p2, p3, p4, p5) {
    var elem = getCtrlElementByTarget(e.target);
    if (!elem) { return; }
    elem.control(funcName, e, p1, p2, p3, p4, p5);
}