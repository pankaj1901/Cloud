/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

(function ($, undefined) {
    $.widget("ui.allattrsinfo", {
        options: {},

        _create: function () {
            // wrap             
            this.wrapContent = $(this.element).wrap(function () {
                return $('<div>').addClass('ldapAllAttrsInfoDiv');
            }).parent();

            var jsonObject = {};
            try {
                jsonObject = $.parseJSON(this.element.attr("value"));
            }
            catch (e) { jsonObject = null; }

            if (jsonObject) {
                this._createElements(jsonObject);
            }
        },

        _createElements: function (obj) {
            var elemTable = $('<table class="data">');
            this.wrapContent.append(elemTable);

            if (!(obj.uAttributes && obj.uAttributes.constructor == Array)) { return; }

            for (var i = 0; i < obj.uAttributes.length; i++) {
                if (!obj.uAttributes[i].uType) {
                    break;
                }

                var currTR = $('<tr>').addClass('attr');
                elemTable.append(currTR);

                var currTH = $('<th>');
                $(currTR).append(currTH);

                var attrDescr = obj.uAttributes[i].uFriendName ?
                            obj.uAttributes[i].uFriendName :
                            obj.uAttributes[i].uType;

                currTH.append(attrDescr);

                var currTD = $('<td>').addClass('attr').addClass('generatedData');
                currTR.append(currTD);

                var inputId = NextId();
                currINPUT = $('<input>').attr('id', inputId).attr('type', 'hidden').addClass('ldapAttrInfo');
                currTD.append(currINPUT);
                DataStoreManager.Data(inputId, 'jsonObject', obj.uAttributes[i]);
            }
        },

        destroy: function () {
            $.Widget.prototype.destroy.apply(this, arguments);
        }
    });
})(jQuery);