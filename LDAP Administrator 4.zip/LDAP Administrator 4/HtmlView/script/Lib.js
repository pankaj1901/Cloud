﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

//////////////////////////////////////////////////////////////////////////
// Constants

Softerra.Const.KEYCODE_ENTER = 13;
Softerra.Const.KEYCODE_ESC = 27;

Softerra.Const.CHILDTYPE_NODE = 1;
Softerra.Const.CHILDTYPE_ITEM = 2;

//////////////////////////////////////////////////////////////////////////
// Variables

//////////////////////////////////////////////////////////////////////////
// Functions

// Change img inside the link
Softerra.Func.ChangeImg = function (imgName, imgSrc) {
    document.images[imgName].src = imgSrc;
}

Softerra.Func.GetBool = function (strVal, defVal) {
    if (strVal) {
        return (strVal == 'true') ? true : false;
    }
    else {
        return (defVal != undefined) ? defVal : false;
    }
}

//
// other stuff
//

Softerra.Func.message = function (msg) {
    alert(msg);
}

Softerra.Func._CheckArgsImpl = function (args, restrictions) {
    var len = restrictions.length;
    for (var i = 0; i < len; i++) {
        if (!(args[i] !== undefined && args[i] != undefined && args[i] != null)) {
            //TODO
            alert('error occured!');
            //throw Softerra.Class.StringMgr.Format(S_ARG_LIST_TYPE_ERROR, i);
            return;
        }
        if (args[i].constructor != restrictions[i]) {
            //TODO
            alert('error occured!');
            //throw Softerra.Class.StringMgr.Format(S_ARG_LIST_TYPE_ERROR, i);
            return;
        }
    }
}

Softerra.Func.CheckTypesWeak = function (args, restrictions) {
    if (!(args && args.length && restrictions && restrictions.length &&
        (args.length >= restrictions.length))) {
        throw S_ARG_LIST_SIZE_ERROR;
    }
    Softerra.Func._CheckArgsImpl(args, restrictions);
}

Softerra.Func.CheckTypes = function (args, restrictions) {
    if (!(args && args.length && restrictions && restrictions.length &&
        (args.length == restrictions.length))) {
        throw S_ARG_LIST_SIZE_ERROR;
    }
    Softerra.Func._CheckArgsImpl(args, restrictions);
}

//check arguments correctness and throw exception if one of arguments isn't valid
Softerra.Func.Check = function () {
    var argsLen = arguments.length;
    for (var i = 0; i < argsLen; i++) {
        if (!(typeof arguments[i] !== undefined &&
            arguments[i] !== undefined && arguments[i] !== null)) {
            var tmpObj = arguments[i];
            throw Softerra.Class.StringMgr.Format(S_ARG_LIST_TYPE_ERROR, i);
        }
    }
}

Softerra.Func.CompareArraysNoOrder = function (arr1, arr2, caseSensitive) {
    Softerra.Func.CheckTypesWeak(arguments, [Array, Array]);
    if (arr1.length != arr2.length) { return false; }

    tmpArr1 = arr1.slice().sort();
    tmpArr2 = arr2.slice().sort();

    var sensit = caseSensitive || false;

    for (var i = 0; i < tmpArr1.length; i++) {
        if (sensit) {
            if (tmpArr1[i].toLowerCase() != tmpArr2[i].toLowerCase()) {
                return false;
            }
        }
        else {
            if (tmpArr1[i] != tmpArr2[i]) {
                return false;
            }
        }
    }
    return true;
}

Softerra.Func.ShowWaitingPage = function (params) {
    //interval, fCond, text
    params = (typeof params != 'undefined') ? params : {};
    params.interval = (typeof params.interval != 'undefined') ? params.interval : null;
    params.fCond = (typeof params.fCond != 'undefined') ? params.fCond : null;
    params.text = (typeof params.text != 'undefined') ? params.text : null;

    params.opacity = (typeof params.opacity != 'undefined') ? params.opacity : 0.75;
    params.backgroundColor = (typeof params.backgroundColor != 'undefined') ? params.backgroundColor : '#FFF';    

    if (!$.blockUI) { return; }

    var blockUIDefaults = cloneObj($.blockUI.defaults);

    var fTimeout = null;
    if (params.fCond && params.interval) {
        fTimeout = function () {
            if (params.fCond()) {
                $.unblockUI({ onUnblock: params.unblockFuncContext ? $.proxy(params.unblockFunc, params.unblockFuncContext) : params.unblockFunc });
                $.blockUI.defaults = blockUIDefaults;
            }
            else {
                setTimeout(fTimeout, params.interval);
            }
        }
    }

    $.blockUI.defaults.overlayCSS.backgroundColor = params.backgroundColor;
    $.blockUI.defaults.overlayCSS.opacity = params.opacity;
    $.blockUI.defaults.css.border = 0;
    $.blockUI.defaults.css.top = 15 + 'pt';
    $.blockUI.defaults.css.backgroundColor = params.backgroundColor;
    $.blockUI.defaults.fadeIn = 0;
    $.blockUI.defaults.fadeOut = 0;
    $.blockUI.defaults.centerY = typeof params.centerY != 'undefined' ? params.centerY : false;
    $.blockUI.defaults.centerYTopMargin = params.centerYTopMargin || '0pt';

    var content = null;
    if (params.text) {
         content = Softerra.Func.GenLoadingContent(params.text);
    }

    $.blockUI({
        message: content
    });

    if (fTimeout) {
        setTimeout(fTimeout, params.interval);
    }
}

//////////////////////////////////////////////////////////////////////////
// Classes

//
// cookies manager
//

Softerra.Class.CookiesMgr = (function () {
    return {
        GetCookie: function (name) {
            if (document.cookie.length > 0) {
                var start = document.cookie.indexOf(name + "=");
                if (start != -1) {
                    start = start + name.length + 1;
                    var end = document.cookie.indexOf(";", start);
                    if (end == -1) { end = document.cookie.length; }
                    return unescape(document.cookie.substring(start, end));
                }
            }
            return "";
        },
        SetCookie: function (name, value, expireDays) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expireDays);
            document.cookie = name + "=" + escape(value) + ((expireDays == null) ? "" : ";expires=" + exdate.toUTCString());
        }
    }
})();

//
// String Manager
//

Softerra.Class.StringMgr = (function () {
    //private:
    var _STR_MAX_LENGTH = 50;
    var _STR_CHILDNODE_NAME_MAXLEN = 30;
    var _STR_CHILDNODE_TYPE_MAXLEN = 25;
    var _STR_TITLE_LENGTH = 80;

    String.prototype.wordWrap = function (m, b, c) {
        var i, j, s, r = this.split("\n");
        if (m > 0) for (i in r) {
            for (s = r[i], r[i] = ""; s.length > m;
                j = c ? m : (j = s.substr(0, m).match(/\S*$/)).input.length - j[0].length
                || m,
                r[i] += s.substr(0, j) + ((s = s.substr(j)).length ? b : "")
            );
            r[i] += s;
        }
        return r.join("\n");
    };

    //public:
    return {
        Constants: {
            STR_MAX_LENGTH: _STR_MAX_LENGTH,
            STR_CHILDNODE_NAME_MAXLEN: _STR_CHILDNODE_NAME_MAXLEN,
            STR_CHILDNODE_TYPE_MAXLEN: _STR_CHILDNODE_TYPE_MAXLEN,
            STR_TITLE_LENGTH: _STR_TITLE_LENGTH
        },

        TruncateLongString: function (str, maxLen) {
            var currMaxLen = maxLen ? maxLen : _STR_MAX_LENGTH;
            return str.length > currMaxLen ? str.substring(0, currMaxLen) + "..." : str;
        },
        StringToTitle: function (str) {
            return str.wordWrap(_STR_TITLE_LENGTH, " ", true);
        },
        Escape: function (str) {
            if (str) {
                var encodedHtml = escape(str);
                encodedHtml = encodedHtml.replace(/\//g, "%2F");
                encodedHtml = encodedHtml.replace(/\?/g, "%3F");
                encodedHtml = encodedHtml.replace(/=/g, "%3D");
                encodedHtml = encodedHtml.replace(/&/g, "%26");
                encodedHtml = encodedHtml.replace(/@/g, "%40");
                return encodedHtml;
            }
            else {
                return '';
            }
        },
        UnescApos: function (str) {
            return str.replace(/&apos;/g, '\'');
        },
        EscapeForHtml: function (str, spacesNot) {
            if (!str) { return ''; }
            if (spacesNot) {
                return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            }
            else {
                return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')/*.replace(/ /g, '&nbsp;')*/;
            }
        },
        EscapeForAttrValue: function (str) {
            if (typeof str !== 'string') { return; }
            return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
        },
        //TODO: review
        Format: function () {
            // http://kevin.vanzonneveld.net
            // +   original by: Ash Searle (http://hexmen.com/blog/)
            // + namespaced by: Michael White (http://getsprink.com)
            // +    tweaked by: Jack
            // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
            // +      input by: Paulo Freitas
            // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
            // +      input by: Brett Zamir (http://brett-zamir.me)
            // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
            // *     example 1: sprintf("%01.2f", 123.1);
            // *     returns 1: 123.10
            // *     example 2: sprintf("[%10s]", 'monkey');
            // *     returns 2: '[    monkey]'
            // *     example 3: sprintf("[%'#10s]", 'monkey');
            // *     returns 3: '[####monkey]'

            var regex = /%%|%(\d+\$)?([-+\'#0 ]*)(\*\d+\$|\*|\d+)?(\.(\*\d+\$|\*|\d+))?([scboxXuidfegEG])/g;
            var a = arguments, i = 0, format = a[i++];

            // pad()
            var pad = function (str, len, chr, leftJustify) {
                if (!chr) { chr = ' '; }
                var padding = (str.length >= len) ? '' : Array(1 + len - str.length >>> 0).join(chr);
                return leftJustify ? str + padding : padding + str;
            };

            // justify()
            var justify = function (value, prefix, leftJustify, minWidth, zeroPad, customPadChar) {
                var diff = minWidth - value.length;
                if (diff > 0) {
                    if (leftJustify || !zeroPad) {
                        value = pad(value, minWidth, customPadChar, leftJustify);
                    } else {
                        value = value.slice(0, prefix.length) + pad('', diff, '0', true) + value.slice(prefix.length);
                    }
                }
                return value;
            };

            // formatBaseX()
            var formatBaseX = function (value, base, prefix, leftJustify, minWidth, precision, zeroPad) {
                // Note: casts negative numbers to positive ones
                var number = value >>> 0;
                prefix = prefix && number && { '2': '0b', '8': '0', '16': '0x'}[base] || '';
                value = prefix + pad(number.toString(base), precision || 0, '0', false);
                return justify(value, prefix, leftJustify, minWidth, zeroPad);
            };

            // formatString()
            var formatString = function (value, leftJustify, minWidth, precision, zeroPad, customPadChar) {
                if (precision != null) {
                    value = value.slice(0, precision);
                }
                return justify(value, '', leftJustify, minWidth, zeroPad, customPadChar);
            };

            // doFormat()
            var doFormat = function (substring, valueIndex, flags, minWidth, _, precision, type) {
                var number;
                var prefix;
                var method;
                var textTransform;
                var value;

                if (substring == '%%') { return '%'; }

                // parse flags
                var leftJustify = false, positivePrefix = '', zeroPad = false, prefixBaseX = false, customPadChar = ' ';
                var flagsl = flags.length;
                for (var j = 0; flags && j < flagsl; j++) {
                    switch (flags.charAt(j)) {
                        case ' ': positivePrefix = ' '; break;
                        case '+': positivePrefix = '+'; break;
                        case '-': leftJustify = true; break;
                        case "'": customPadChar = flags.charAt(j + 1); break;
                        case '0': zeroPad = true; break;
                        case '#': prefixBaseX = true; break;
                    }
                }

                // parameters may be null, undefined, empty-string or real valued
                // we want to ignore null, undefined and empty-string values
                if (!minWidth) {
                    minWidth = 0;
                } else if (minWidth == '*') {
                    minWidth = +a[i++];
                } else if (minWidth.charAt(0) == '*') {
                    minWidth = +a[minWidth.slice(1, -1)];
                } else {
                    minWidth = +minWidth;
                }

                // Note: undocumented perl feature:
                if (minWidth < 0) {
                    minWidth = -minWidth;
                    leftJustify = true;
                }

                if (!isFinite(minWidth)) {
                    throw new Error('sprintf: (minimum-)width must be finite');
                }

                if (!precision) {
                    precision = 'fFeE'.indexOf(type) > -1 ? 6 : (type == 'd') ? 0 : undefined;
                } else if (precision == '*') {
                    precision = +a[i++];
                } else if (precision.charAt(0) == '*') {
                    precision = +a[precision.slice(1, -1)];
                } else {
                    precision = +precision;
                }

                // grab value using valueIndex if required?
                value = valueIndex ? a[valueIndex.slice(0, -1)] : a[i++];

                switch (type) {
                    case 's': return formatString(String(value), leftJustify, minWidth, precision, zeroPad, customPadChar);
                    case 'c': return formatString(String.fromCharCode(+value), leftJustify, minWidth, precision, zeroPad);
                    case 'b': return formatBaseX(value, 2, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
                    case 'o': return formatBaseX(value, 8, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
                    case 'x': return formatBaseX(value, 16, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
                    case 'X': return formatBaseX(value, 16, prefixBaseX, leftJustify, minWidth, precision, zeroPad).toUpperCase();
                    case 'u': return formatBaseX(value, 10, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
                    case 'i':
                    case 'd':
                        number = parseInt(+value, 10);
                        prefix = number < 0 ? '-' : positivePrefix;
                        value = prefix + pad(String(Math.abs(number)), precision, '0', false);
                        return justify(value, prefix, leftJustify, minWidth, zeroPad);
                    case 'e':
                    case 'E':
                    case 'f':
                    case 'F':
                    case 'g':
                    case 'G':
                        number = +value;
                        prefix = number < 0 ? '-' : positivePrefix;
                        method = ['toExponential', 'toFixed', 'toPrecision']['efg'.indexOf(type.toLowerCase())];
                        textTransform = ['toString', 'toUpperCase']['eEfFgG'.indexOf(type) % 2];
                        value = prefix + Math.abs(number)[method](precision);
                        return justify(value, prefix, leftJustify, minWidth, zeroPad)[textTransform]();
                    default: return substring;
                }
            };

            return format.replace(regex, doFormat);
        }

    }
})();

//
// base64 class
//

Softerra.Class.Base64 = (function () {
    //private:
    var keyStr = "ABCDEFGHIJKLMNOP" +
                "QRSTUVWXYZabcdef" +
                "ghijklmnopqrstuv" +
                "wxyz0123456789+/" +
                "=";

    return {
        //public:
        Encode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;

            do {
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);

                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;

                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }

                output += keyStr.charAt(enc1);
                output += keyStr.charAt(enc2);
                output += keyStr.charAt(enc3);
                output += keyStr.charAt(enc4);
                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
            } while (i < input.length);

            return output;
        },

        Decode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;

            // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
            var base64test = /[^A-Za-z0-9\+\/\=]/g;
            if (base64test.exec(input)) {
                //TODO: change to exception
                alert("There were invalid base64 characters in the input text.\n" +
                       "Valid base64 characters are A-Z, a-z, 0-9, �+�, �/�, and �=�\n" +
                       "Expect errors in decoding.");
            }
            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

            do {
                enc1 = keyStr.indexOf(input.charAt(i++));
                enc2 = keyStr.indexOf(input.charAt(i++));
                enc3 = keyStr.indexOf(input.charAt(i++));
                enc4 = keyStr.indexOf(input.charAt(i++));

                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;

                output = output + String.fromCharCode(chr1);

                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }

                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
            } while (i < input.length);

            return output;
        }
    };
})();

//
// Encoding flags class
//

Softerra.Class.EncodingFlags = (function () {
    return {
        VALUE_ENCODING_FLAG_NONE: 0xC0000000,
        VALUE_ENCODING_FLAG_BASE64: 0xC0010000,
        VALUE_ENCODING_FLAG_URI: 0x80020000,
        VALUE_ENCODING_FLAG_NEEDDISPVALUE: 0xC0040000
    };
})();

//
// CSS Manager
//

Softerra.Class.CssMgr = (function () {
    var setCssFunc = function (fileName) {
        $(".pageCSS").remove();
        $("head").each(function () {
            jQuery(this).append('<link class="pageCSS" rel="StyleSheet" href="' + fileName + '" type="text/css" />');
        });
    }

    return {
        SetCSS: setCssFunc,
        SetCSSEdit: function () {
            setCssFunc($("input.editCSS").attr("value"));
        },
        SetCSSView: function () {
            setCssFunc($("input.viewCSS").attr("value"));
        }
    }
})();


Softerra.Class.StateFlagsMgr = (function () {
    var viewMode = 0x1;
    var editMode = 0x2;
    var inputsGen = 0x4; //only for allAttrsInfo

    return {
        IsModeGen: function (mode, flags) {
            try {
                Softerra.Func.CheckTypes(arguments, [String, Number])
            } 
            catch (e) 
            { 
                return false; 
            }
            return flags & editMode;
        },
        GetModeFlag: function (currMode) {
            try { Softerra.Func.CheckTypes(arguments, [String]) } catch (e) { return 0; }

            if (currMode == 'ViewMode') {
                return viewMode;
            }
            else if (currMode == 'EditMode') {
                return editMode;
            }
            else {
                return 0;
            }
        },
        AreInputsGen: function (flags) {
            try { Softerra.Func.CheckTypes(arguments, [Number]) } catch (e) { return false; }
            return flags & inputsGen;
        },
        StateFlagsStr: 'stateFlags',
        InputsGenFlag: inputsGen,
        EmptyFlags: 0
    };
})();

Softerra.Class.Window = (function () {
    var onloadFunctions = [];

    return {
        addLoadEvent: function (func, param) {
            onloadFunctions.push({ func: func, param: param });
        },
        onLoad: function () {
            for (var i = 0; i < onloadFunctions.length; ++i) {
                var obj = onloadFunctions[i];
                obj.func(obj.param);
            }
        }
    }
})();

window.onload = Softerra.Class.Window.onLoad;

window.currUID = 0;
window.UIDPrefix = 'elemUID';
NextId = function () {
    return String(UIDPrefix + ++window.currUID);
}

Softerra.Func.StringInArray = function (arr, elem, nocase) {
    Softerra.Func.CheckTypesWeak(arguments, [Array, String]);
    for (var i = 0; i < arr.length; ++i) {
        if (nocase) {
            if (elem.toLowerCase() == arr[i].toLowerCase()) {
                return true;
            }
        }
        else {
            if (elem == arr[i]) {
                return true;
            }
        }
    }

    return false;
}

Softerra.Func.GetCustomEditorVal = function (attrObj, targ, valIndex) {
    var procGetFlags = Softerra.Class.ProcessorsMgr.GetProcessor(attrObj);
    var encFlags = Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NONE;
    if (procGetFlags && procGetFlags.GetEncodingFlag) {
        var encFlags = procGetFlags.GetEncodingFlag.call(procGetFlags);
    }

    var procGetVal = Softerra.Class.ProcessorsMgr.GetProcessor(attrObj);

    var params;
    var result;
    
    if (valIndex != undefined) {
        if (!(procGetVal && procGetVal.GetValForCustEditor)) { return undefined; }
        var valForEditor;
        var valForEditor = procGetVal.GetValForCustEditor.call(procGetVal, attrObj, targ, valIndex);

        if (valForEditor) {
            params = { uType: attrObj.uType, uDispEditVal: valForEditor, uEncFlags: encFlags };
        }
        else {
            params = { uType: attrObj.uType, uEncFlags: encFlags };
        }
    }
    else {
        params = { uType: attrObj.uType, uEncFlags: encFlags };
    }

    try {
        result = window.external.ContextNode.SyncOperation("EditWithCustomEditor", $.toJSON(params), 0);
    }
    catch (e) { }

    if (!result) { return; }

    var parseRes;
    try {
        parseRes = $.parseJSON(Softerra.Class.StringMgr.UnescApos(result));
    } catch (e) { }

    return parseRes;
}

Softerra.Func.GetCurrTRIndex = function (elementOnCurrTR, classTR, classTable) {
    if (!elementOnCurrTR) { return -1; }
    var trSelector = (classTR && classTR.length) ? ('tr.' + classTR) : ('tr');
    var tableSelector = (classTable && classTable.length) ? ('table.' + classTable) : ('table');

    var currTR = $($(elementOnCurrTR).parents(trSelector)[0]);
    var currIndex = $(currInput).parent().find(tableSelector + ' ' + trSelector).index(currTR);
    return currIndex;
}

Softerra.Func.GenLoadingContent = function (msg) {
    msg = msg ? msg : '';
    var divWait = $('<div id="waitingPage" class="bordered">');
    divWait.append('<div class="waiting">');
    divWait.append('<h1>' + msg + '</h1>');
    divWait.append('</div>');
    return divWait;
}

StringBuilder = function () {
    this._s = [];
    this._i = 0;
    this.append = function (str) {
        this._s[this._i++] = str;
    }
    this.toString = function (separator) {
        if (separator) {
            return this._s.join(separator);
        }
        else {
            return this._s.join('');
        }
    }
}

TagBuilder = function (tagName, useCloseTag) {
    this._tagName = tagName;
    this._classes = [];
    this._attrs = [];
    this.content = new StringBuilder();
    this._useCloseTag = typeof useCloseTag == 'undefined' ? true : useCloseTag;

    this.addAttr = function (name, value) {
        this._attrs.push({ 'n': name, 'v': value });
    }
    this.addAttrEscaped = function (name, value) {
        this._attrs.push({ 'n': name, 'v': Softerra.Class.StringMgr.EscapeForAttrValue(value) });
    }
    this.addClass = function (className) {
        this._classes.push(className);
    }
    this.addContent = function (content) {
        this.content.append(content);
    }
    this.toString = function () {
        var s = new StringBuilder();
        s.append(this.openTag());
        if (this._useCloseTag) {
            s.append(this.content.toString());
            s.append(this.closeTag());
        }
        return s.toString();
    }
    this.openTag = function () {
        var s = new StringBuilder();
        s.append('<' + this._tagName);

        if (this._classes.length) {
            s.append('class="' + this._classes.join(' ') + '"');
        }

        if (this._attrs.length) {
            var len = this._attrs.length;
            for (var i = 0; i < len; ++i) {
                s.append(this._attrs[i].n + '=' + '"' + this._attrs[i].v + '"')
            }
        }

        if (this._useCloseTag) {
            s.append('>');
        }
        else {
            s.append('/>');
        }
        
        return s.toString(' ');
    }
    this.closeTag = function () {
        return '</' + this._tagName + '>';
    }
}

PostponedBindsManager = (function () {
    var _binds = [];
    var _bindsByClass = {};

    return {
        AddBind: function (params) {
            _binds.push(params);
        },
        AddBindByClass: function (className, params) {
            if (!_bindsByClass[className] ||
                (_bindsByClass[className] && !_bindsByClass[className][params.eventType])) {
                if (!_bindsByClass[className]) {
                    _bindsByClass[className] = {}
                }

                _bindsByClass[className][params.eventType] = params;
            }
        },
        PerformBinds: function () {
            var fPerformBind = function (params) {
                if (params.data) {
                    $(document.getElementById(params.elemId)).bind(params.eventType, params.data, params.context ?
                        $.proxy(params.func, params.context) : params.func);
                }
                else {
                    $(document.getElementById(params.elemId)).bind(params.eventType, params.context ?
                        $.proxy(params.func, params.context) : params.func);
                }
            }

            // perform simple binds
            var bindsLen = _binds.length;
            for (var i = 0; i < bindsLen; ++i) {
                fPerformBind(_binds[i]);
            }
            _binds = [];

            // perform binds by class
            for (var className in _bindsByClass) {
                for (var eventType in _bindsByClass[className]) {
                    var params = _bindsByClass[className][eventType];
                    var elems;
                    if (params.searchFrom) {
                        elems = params.searchFrom.find('.' + className);
                    }
                    else {
                        elems = $('.' + className);
                    }

                    if (params.data) {
                        elems.bind(params.eventType, params.data, params.context ?
                            $.proxy(params.func, params.context) : params.func);
                    }
                    else {
                        elems.bind(params.eventType, params.context ?
                            $.proxy(params.func, params.context) : params.func);
                    }
                }
            }
            _bindsByClass = {};
        }
    }
})();

PostponedOperationsManager = (function () {
    var _operationGroups = [];

    return {
        AddOperation: function (groupName, isSync, func /*, parameters */) {
            var newOper = { isSync: isSync, func: func, params: [].slice.call(arguments, 3) };
            for (var i = 0; i < _operationGroups.length; ++i) {
                if (_operationGroups[i].groupName == groupName) {
                    _operationGroups[i].operations.push(newOper);
                    return;
                }
            }
            var operations = [];
            operations.push(newOper);
            _operationGroups.push({ groupName: groupName, operations: operations });
        },
        Execute: function (groupName) {
            for (var i = 0; i < _operationGroups.length; ++i) {
                if (_operationGroups[i].groupName == groupName) {
                    var operationsGroup = _operationGroups[i];
                    _operationGroups.splice(i--, 1);
                    for (var j = 0; j < operationsGroup.operations.length; ++j) {
                        var oper = operationsGroup.operations[j];
                        
                        if (oper.isSync) {
                            oper.func(oper.params);
                        }
                        else {
                            TimersHolder.addFunction(function () {
                                oper.func(oper.params);
                            });
                        }
                    }
                }
            }
        },
        OperationGroups: {
            attrinfoProcessing: 'attrinfoProcessing',
            attrinfoTurnMode: 'attrinfoTurnMode',
            controlProcessing: 'controlProcessing',
            controlTurnMode: 'controlTurnMode'
        }
    }
})();

DataStoreManager = (function () {
    //private:
    var _data = [/*uid, data*/];
    var _dataManagerCallCount = 0;

    var _saveData = function (uid, dataName, data) {
        var uidNumber = 0;
        var currData = null;
        for (var i = 0; i < _data.length; ++i) {
            if (_data[i].uid == uid) {
                currData = _data[i].uidData;
                break;
            }
        }
        if (!currData) {
            _data.push({ uid: uid });
            currData = _data[_data.length - 1].uidData = [];
        }

        for (var i = 0; i < currData.length; ++i) {
            if (currData[i].dataName == dataName) {
                currData[i].dataValue = data;
                return;
            }
        }

        currData.push({ dataName: dataName, dataValue: data });
    };

    var _loadData = function (uid, dataName) {
        if (!uid || !dataName) { return; }
        var uidNumber = 0;
        var currData = null;
        for (var i = 0; i < _data.length; ++i) {
            if (_data[i].uid == uid) {
                currData = _data[i].uidData;
                break;
            }
        }
        if (!currData) {
            return;
        }

        for (var j = 0; j < currData.length; ++j) {
            if (currData[j].dataName == dataName) {
                return currData[j].dataValue;
            }
        }
    };

    var _checkStatus = 'idle';
    var _checkNonExistIds = function () {
        var i = 0;
        while (i < _data.length) {
            if (_data[i] && !document.getElementById(_data[i].uid)) {
                _data.splice(i, 1);
            }
            else {
                ++i;
            }
        }

        _checkStatus = 'idle';
    }

    //public:
    return {
        Data: function () {
            switch (arguments.length) {
                case 2:
                    return _loadData(arguments[0], arguments[1]);
                    break;
                case 3:
                    _saveData(arguments[0], arguments[1], arguments[2]);
                    ++_dataManagerCallCount;
                    if (_dataManagerCallCount % 50 == 0) {
                        if (_checkStatus == 'idle') {
                            _checkStatus = 'waiting';
                            TimersHolder.addFunction(_checkNonExistIds, null, 5000);
                        }
                    }
                    break;
                default:
                    alert('DataStoreManager error: Wrong arguments count');
            }
        },
        RemoveData: function () {
            _saveData(arguments[0], arguments[1], null);
        }
    }
})();

TimersHolder = (function () {
    var _timers = [];
    return {
        addFunction: function (func, context, timeout) {
            var t = timeout || 0;
            var timerId = setTimeout(function () {
                TimersHolder.removeTimer(timerId);
                if (context) {
                    func.call(context);
                }
                else {
                    func();
                }
            }, t);
            TimersHolder.addTimer(timerId);
        },
        addTimer: function (timerId) {
            var exists = false;
            for (var i = 0; i < _timers.length; ++i) {
                if (_timers[i] == timerId) {
                    exists = true;
                }
            }

            if (!exists) {
                _timers.push(timerId);
            }
        },
        removeTimer: function (timerId) {
            var removed = false;

            for (var i = 0; i < _timers.length; ++i) {
                if (_timers[i] == timerId) {
                    _timers.splice(i, 1);
                    removed = true;
                    break;
                }
            }
        },
        killTimers: function () {
            for (var i = 0; i < _timers.length; ++i) {
                clearTimeout(_timers[i]);
            }
            _timers = [];
        }
    }
})();

var AttachCue = function (opts) {
    if (!opts || typeof opts != 'object') {
        return;
    }

    var inputElemId;
    if (opts.directBind) {
        if (!opts.element) {
            return;
        }
        inputElemId = opts.element.attr('id');
    }
    else {
        if (!(opts.elementId && PostponedBindsManager && PostponedOperationsManager)) {
            return;
        }
        inputElemId = opts.elementId;
    }

    var fCueOff = function () {
        var elemInput = $('#' + inputElemId).first();
        if (!elemInput) { return; }

        if (elemInput.hasClass('cueMode')) {
            elemInput.removeClass('cueMode');
            elemInput.val('');
        }
    }

    var fCueOn = function () {
        var elemInput = $('#' + inputElemId).first();
        if (!elemInput) { return; }

        if (elemInput.val() == '') {
            valForInsert = opts.cueText;
            elemInput.val(valForInsert).addClass('cueMode');
        }
    }

    var setCaretPosition = function (ctrl, pos) {
        if (ctrl.setSelectionRange) {
            ctrl.focus();
            ctrl.setSelectionRange(pos, pos);
        }
        else if (ctrl.createTextRange) {
            var range = ctrl.createTextRange();
            range.collapse(true);
            range.moveEnd('character', pos);
            range.moveStart('character', pos);
            range.select();
        }
    }

    if (opts.directBind) {
        opts.element
            .bind('focus', function () {
                var elemInput = $('#' + inputElemId);
                if (elemInput.hasClass('cueMode')) {
                    setCaretPosition(this, 0);
                }
            })
            .bind('keydown', function (event) {
                if (event.keyCode == Softerra.Const.KEYCODE_ESC || event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                    return;
                }
                fCueOff();
            })
            .bind('keyup', function (event) {
                var elemInput = $('#' + inputElemId).first();
                if (event.keyCode == Softerra.Const.KEYCODE_ESC || event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                    return;
                }
                if (elemInput.val() == '') {
                    fCueOn();
                    setCaretPosition(this, 0);
                }
            })
            .bind('paste', function () {
                fCueOff();
            })
            .bind('blur', function () {
                fCueOn();
            });

        fCueOn();
    }
    else {
        // focus
        PostponedBindsManager.AddBind(
            { elemId: inputElemId, eventType: 'focus', func: function () {
                if ($('#' + inputElemId).hasClass('cueMode')) {
                    setCaretPosition(this, 0);
                }
            }
            });
        // keydown
        PostponedBindsManager.AddBind(
            { elemId: inputElemId, eventType: 'keydown', func: function (event) {
                if (event.keyCode == Softerra.Const.KEYCODE_ESC || event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                    return;
                }
                fCueOff();
            }
            });
        // keyup
        PostponedBindsManager.AddBind(
            { elemId: inputElemId, eventType: 'keyup', func: function (event) {
                if (event.keyCode == Softerra.Const.KEYCODE_ESC || event.keyCode == Softerra.Const.KEYCODE_ENTER) {
                    return;
                }

                var elemInput = $('#' + inputElemId).first();
                if (!elemInput) { return; }

                if (elemInput.val() == '') {
                    fCueOn();
                    setCaretPosition(this, 0);
                }
            }
            });
        // paste
        PostponedBindsManager.AddBind(
            { elemId: inputElemId, eventType: 'paste', func: function () {
                fCueOff();
            }
            });
        // blur
        PostponedBindsManager.AddBind(
            { elemId: inputElemId, eventType: 'blur', func: function () {
                fCueOn();
            }
            });

        var operGroup = PostponedOperationsManager.OperationGroups.attrinfoProcessing;
        PostponedOperationsManager.AddOperation(operGroup, true, function (params) {
            fCueOn();
        });
    }
}

CommonEventHandler = function () {
    this._handlers = {};
    this._elemBindTo = null;
    this._lastEvent = null;

    this.addHandler = function (className, eventType, opts) {
        if (!this._handlers[className]) {
            this._handlers[className] = {};
        }
        if (!this._handlers[className][eventType]) {
            this._handlers[className][eventType] = opts;
        }
    }

    this.clear = function () {
        var alreadyUnbindedEventTypes = [];
        for (var currClass in this._handlers) {
            var currClassData = this._handlers[currClass];
            for (var currEvent in currClassData) {
                if (!Softerra.Func.StringInArray(alreadyUnbindedEventTypes, currEvent, false)) {
                    alreadyUnbindedEventTypes.push(currEvent);
                    this._elemBindTo.unbind(currEvent, this.onEvent);
                }
            }
        }

        this._handlers = [];
        this._elemBindTo = null;
    }

    this.bindHandlers = function (elemBindTo) {
        this._elemBindTo = elemBindTo;
        var alreadyBindedEventTypes = [];
        for (var currClass in this._handlers) {
            alreadyBindedEventTypes = [];
            var currClassData = this._handlers[currClass];
            for (var currEvent in currClassData) {
                if (!Softerra.Func.StringInArray(alreadyBindedEventTypes, currEvent, false)) {
                    alreadyBindedEventTypes.push(currEvent);
                    this._elemBindTo.bind(currEvent, $.proxy(this.onEvent, this));
                }
            }
        }
    }

    this.onEvent = function (e, params) {
        e.stopImmediatePropagation();

        var handleRes = undefined;
        var iHandled = 0;
        var target = $(e.target);
        for (var currClass in this._handlers) {
            if (!target.hasClass(currClass)) {
                continue;
            }

            var currClassData = this._handlers[currClass];
            for (var currEvent in currClassData) {
                if (currEvent != e.type) { continue; }

                var currEventData = currClassData[currEvent];

                if (currEventData.data) {
                    e.data = currEventData.data;
                }

                if (currEventData.context) {
                    handleRes = currEventData.func.call(currEventData.context, e, params);
                }
                else {
                    handleRes = currEventData.func(e, params);
                }
                ++iHandled;
            }
        }

        if (iHandled == 1) { return handleRes; }
        else { return !iHandled; }
    }
};

 function cloneObj(o) {
    if (!o || "object" !== typeof o) {
        return o;
    }
    var c = "function" === typeof o.pop ? [] : {};
    var p, v;
    for (p in o) {
        if (o.hasOwnProperty(p)) {
            v = o[p];
            if (v && "object" === typeof v) {
                c[p] = cloneObj(v);
            }
            else c[p] = v;
        }
    }
    return c;
}

ValuesMerger = (function () {
    var userParamsMerger = function () {
        this.merge = function (flags, valuesFirst, valuesSecond) {
            if (flags != (Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NONE |
                Softerra.Class.EncodingFlags.VALUE_ENCODING_FLAG_NEEDDISPVALUE)) {
                return false;
            }
            var firstObj;
            var secondObj;
            try {
                firstObj = $.parseJSON(valuesFirst[0]);
                secondObj = $.parseJSON(valuesSecond[0]);
            }
            catch (e) { return false; }

            for (var i in firstObj) {
                for (var j in secondObj) {
                    if (i == j) { return false; }
                }
            }

            var mergedVal = {};
            $.extend(mergedVal, firstObj, secondObj);
            var res = [];
            res.push($.toJSON(mergedVal));
            return res;
        }
    }

    var _mergers = {};
    _mergers['userParameters'] = new userParamsMerger();

    return {
        merge: function (attrType, flags, valuesFirst, valuesSecond) {
            var merger = _mergers[attrType];
            if (!merger) { return false; }
            return merger.merge(flags, valuesFirst, valuesSecond);
        }
    }
})();

function disableElements(elems, disable) {
    for (var i = 0; i < elems.length; ++i) {
        if (disable) {
            if (!$(elems[i]).attr("disabled")) {
                $(elems[i]).attr("disabled", 'disabled');
                if ($(elems[i]).parent().hasClass("themedCheckbox")) {
                    customCheckSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedRadio")) {
                    customRadioSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedSelect")) {
                    customSelectSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedInput")) {
                    customInputSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedButton")) {
                    customButtonSync($(elems[i]));
                }
            }
        }
        else {
            if ($(elems[i]).attr("disabled")) {
                $(elems[i]).removeAttr("disabled");
                if ($(elems[i]).parent().hasClass("themedCheckbox")) {
                    customCheckSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedRadio")) {
                    customRadioSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedSelect")) {
                    customSelectSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedInput")) {
                    customInputSync($(elems[i]));
                }
                if ($(elems[i]).parent().hasClass("themedButton")) {
                    customButtonSync($(elems[i]));
                }
            }
        }
    }
}

function customCheckCreate(elem) {
    var checkButton = elem.find('input[type="checkbox"]');
    $(checkButton).each(function() {
        if ($(this).parent().hasClass("themedCheckbox")) {
            return;
        }

        $(this).wrap('<span class="themedCheckbox"></span>');

        customCheckSync($(this));

        $(this).bind("change", function() {
            if ($(this).is(':checked')) {
                if (!$(this).parent().hasClass("selected")) {
                    $(this).parent().addClass("selected");
                }
            }
            else {
                if ($(this).parent().hasClass("selected")) {
                    $(this).parent().removeClass("selected");
                }
            };

            if ($(this).is(':disabled')) {
                if (!$(this).parent().hasClass("disabled")) {
                    $(this).parent().addClass("disabled");
                }
            }
            else {
                if ($(this).parent().hasClass("disabled")) {
                    $(this).parent().removeClass("disabled");
                }
            }
        });
    });
}

function customRadioCreate(elem) {
    var radioButton = elem.find('input[type="radio"]');
    $(radioButton).each(function() {
        if ($(this).parent().hasClass("themedRadio")) {
            return;
        }

        $(this).wrap("<span class='themedRadio'></span>");
 
        customRadioSync($(this));
        
        $(this).bind("change", function() {
            if ($(this).is(":checked")) {
                if (!$(this).parent().hasClass("selected")) {
                    $(this).parent().addClass("selected");
                    customRadioSync(radioButton.not(this));
                }
            }
            else {
                if ($(this).parent().hasClass("selected")) {
                    $(this).parent().removeClass("selected");
                }
            };

            if ($(this).is(":disabled")) {
                if (!$(this).parent().hasClass("disabled")) {
                    $(this).parent().addClass("disabled");
                }
            }
            else {
                if ($(this).parent().hasClass("disabled")) {
                    $(this).parent().removeClass("disabled");
                }
            }
        });
    });
}

function customCheckSync(elements) {
    elements.each(function() {
        var _this = $(this);
        var _parent = _this.parent();

        if (!_parent.hasClass("themedCheckbox")) {
            return;
        }

        if (_this.is(":checked")) {
           if (!_parent.hasClass("selected")) {
               _parent.addClass("selected");
           }
        }
        else {
           if (_parent.hasClass("selected")) {
               _parent.removeClass("selected");
           }
        }

        if (_this.is(":disabled")) {
           if (!_parent.hasClass("disabled")) {
                _parent.addClass("disabled");
           }
        }
        else {
           if (_parent.hasClass("disabled")) {
               _parent.removeClass("disabled");
           }
        }
    });
}

function customRadioSync(elements) {
    elements.each(function() {
        var _this = $(this);
        var _parent = _this.parent();

        if (!_parent.hasClass("themedRadio")) {
            return;
        }

        if (_this.is(":checked")) {
           if (!_parent.hasClass("selected")) {
               _parent.addClass("selected");
           }
        }
        else {
           if (_parent.hasClass("selected")) {
               _parent.removeClass("selected");
           }
        }

        if (_this.is(":disabled")) {
           if (!_parent.hasClass("disabled")) {
                _parent.addClass("disabled");
           }
        }
        else {
           if (_parent.hasClass("disabled")) {
               _parent.removeClass("disabled");
           }
        }
    });
}

function customSelectSync(element)
{
    var _parent = element.parent();

    if (!_parent.hasClass("themedSelect")) {
        return;
    }

    if (element.is(":disabled")) {
       if (!_parent.hasClass("disabled")) {
            _parent.addClass("disabled");
        }
     }
     else {
        if (_parent.hasClass("disabled")) {
            _parent.removeClass("disabled");
        }
     }

    if (element.get(0) === document.activeElement) {
       if (!_parent.hasClass("focused")) {
            _parent.addClass("focused");
       }
    }
    else {
       if (_parent.hasClass("focused")) {
           _parent.removeClass("focused");
       }
    }

    var _textElement = _parent.find(".themedSelectText");
    var _selectedOption = element.children("option:selected");
    var _changed = _textElement.text() != _selectedOption.text();

    if (_changed) {
        _textElement.text(_selectedOption.text());
    }

    return _changed;
}

function customInputSync(element)
{
   var _parent = element.parent();

   if (!_parent.hasClass("themedInput")) {
        return;
    }

    if (element.is(":disabled")) {
       if (!_parent.hasClass("disabled")) {
            _parent.addClass("disabled");
        }
     }
     else {
        if (_parent.hasClass("disabled")) {
            _parent.removeClass("disabled");
        }
     }

    var _textElement = _parent.find(".themedInputText");
    var _changed = _textElement.text() != element.val();

    if (_changed) {
        _textElement.text(element.val());
    }

    return _changed;
}

function customButtonSync(element)
{
   var _parent = element.parent();

   if (!_parent.hasClass("themedButton")) {
        return;
    }

    if (element.is(":disabled")) {
       if (!_parent.hasClass("disabled")) {
            _parent.addClass("disabled");
        }
     }
     else {
        if (_parent.hasClass("disabled")) {
            _parent.removeClass("disabled");
        }
     }

    var _textElement = _parent.find(".themedButtonText");
    var _changed = _textElement.text() != element.text();

    if (_changed) {
        _textElement.text(element.text());
    }

    return _changed;
}
