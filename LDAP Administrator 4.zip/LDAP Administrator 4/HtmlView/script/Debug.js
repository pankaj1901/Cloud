﻿/*
* Softerra LDAP Administrator
* Copyright (c) Softerra, Ltd. All Rights Reserved.
*/

// DEBUG functions
function trace(msg) {
    var divTrace = $('div.trace');
    if (!divTrace.length) {
        divTrace = $('<div>').addClass('trace');
        $('body').append(divTrace);
    }
    divTrace.append('<br>' + '<span class="trace">' + msg + '</span>');
}

function traceClear() {
    $('div.trace').remove();
}

function assert(expr) {
    if (!expr) {
        alert("Expression isn't TRUE");
    }
}

function json(obj) {
    try {
        alert($.toJSON(obj));
    }
    catch (e) { alert('json error'); }
}

function showObject(obj, maxLevel, filter) {
    var res = '';
    res = ObjectToString(obj, maxLevel || 1, filter || []);
    alert(res);
}

stringInArray = function (arr, elem, nocase) {
    for (var i = 0; i < arr.length; ++i) {
        if (nocase) {
            if (elem.toLowerCase() == arr[i].toLowerCase()) {
                return true;
            }
        }
        else {
            if (elem == arr[i]) {
                return true;
            }
        }
    }

    return false;
}

function ObjectToString(obj, maxLevel, filter, tabbing, level) {
    tabbing = tabbing || '';
    level = level || 0;
    var result = "";

    for (var i in obj) {
        if (typeof obj[i] == 'function') {
            if (!stringInArray(filter, typeof obj[i], true)) {
                result += tabbing + '--' + i + ' : ' + 'Function' + '\n';
            }
        }
        else if (typeof obj[i] == 'object' && level < (maxLevel - 1)) {
            if (!stringInArray(filter, typeof obj[i], true)) {
                result += tabbing + i + ' : ' + obj[i] + '\n';
                result += ObjectToString(obj[i], maxLevel, filter, tabbing + '  ', ++level);
            }
        }
        else {
            if (!stringInArray(filter, typeof obj[i], true)) {
                result += tabbing + i + ' : ' + obj[i] + '\n';
            }
        }
    }

    return result;
}

function html(obj) {
    try {
        alert($(obj).html());
    }
    catch (e) {
        alert('html error');
    }
}

function TickCounter() {
    this._ticks = (new Date()).getTime();

    this.Elapsed = function () {
        return (new Date()).getTime() - this._ticks;
    }
}